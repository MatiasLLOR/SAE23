import pymysql
import cherrypy
import datetime


# Fonction pour l'affichage des adherents
def afficher_adherent(adherents):
    adherents_data = []
    for i in adherents:
        value1 = i['numAdherent']
        value2 = i['prenom']
        value3 = i['nom']
        value4 = i['dateNaissance']
        value5 = i['tel']
        value6 = i['typeAdhesion']
        value7 = i['classement']
        value8 = i['datePaiement']
        adherents_data.append({'numAdherent': value1, 'prenom': value2, 'nom': value3, 'dateNaissance': value4, 'tel': value5, 'typeAdhesion': value6, 'classement': value7, 'datePaiement': value8})
    return adherents_data
    
    
def afficher_reservation(reservations):
    reservations_data = []
    for i in reservations:
        value1 = i['numResa']
        value2 = i['numAdherent']
        value3 = i['dateResa']
        value4 = i['hDebut']
        value5 = i['hFin']
        value6= i['numTerrain']
        reservations_data.append({'numReservation': value1, 'numAdherent': value2, 'dateReservation': value3, 'heureDebut': value4, 'heureFin': value5, 'numTerrain': value6})
    return reservations_data

def afficher_terrain(terrains):
    terrains_data = []
    for i in terrains:
        value1 = i['numTerrain']
        terrains_data.append({'numTerrain': value1})
    return terrains_data

# Fonction pour l'affichage des adhérents
def afficher_adherent2(adherents):
    adherents_data = []
    for i in adherents:
        adherent = {
            'numAdherent': i.get('numAdherent'),
            'prenom': i.get('prenom'),
            'nom': i.get('nom'),
            'dateNaissance': i.get('dateNaissance'),
            'tel': i.get('tel'),
            'typeAdhesion': i.get('typeAdhesion'),
            'classement': i.get('classement'),
            'datePaiement': i.get('datePaiement'),
            'is_empty': False  # Par défaut, les valeurs ne sont pas toutes None
        }
        if all(value is None for value in adherent.values()):
            adherent['is_empty'] = True
        adherents_data.append(adherent)
    return adherents_data


    