import pymysql
import cherrypy
import datetime


# Fonction pour l'affichage des adherents
def afficher_adherent(adherents):
    adherents_data = []
    for i in adherents:
        value1 = i['numAdherent']
        value2 = i['prenom']
        value3 = i['nom']
        value4 = i['dateNaissance']
        value5 = i['tel']
        value6 = i['typeAdhesion']
        value7 = i['classement']
        value8 = i['datePaiement']
        adherents_data.append({'numAdherent': value1, 'prenom': value2, 'nom': value3, 'dateNaissance': value4, 'tel': value5, 'typeAdhesion': value6, 'classement': value7, 'datePaiement': value8})
    return adherents_data
    
    

    
