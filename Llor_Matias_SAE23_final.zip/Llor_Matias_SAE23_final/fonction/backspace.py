from tkinter.messagebox import NO
import pymysql
import datetime

# Lecture du fichier de configuration
config = {}
with open('config.txt', 'r') as file:
        for line in file:
            key, value = line.strip().split(':')
            config[key] = value
        host = config['host']
        user = config['user']
        password = config['password']
        database = config['database']

# Fonction pour se connecter à la base de données
def connect():
    config1 = {
        'host': host,
        'user': user,
        'password': password,
        'database': database
    }
    return pymysql.connect(**config1)

# Fonction pour récupérer les données des adhérents depuis la base de données SQL
def get_adherents():
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    cursor.execute("SELECT * FROM " + table)
    adherents = cursor.fetchall()
    cursor.close()
    cnx.close()
    return adherents

# Fonction pour récupérer les données de la table terrains depuis la base de données SQL
def get_terrains():
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='terrains'
    cursor.execute("SELECT * FROM " + table)
    terrains = cursor.fetchall()
    cursor.close()
    cnx.close()
    return terrains

# Fonction pour récupérer les données de la table réservations depuis la base de données SQL
def get_reservations():
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    cursor.execute("SELECT * FROM " + table)
    reservations = cursor.fetchall()
    cursor.close()
    cnx.close()
    return reservations

# Fonction pour créer un nouvel adhérent dans la base de données SQL
def create_adherent(adherent):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    query = "INSERT INTO adherents (prenom, nom, dateNaissance, tel, typeAdhesion, classement, datePaiement) VALUES (%s, %s, %s, %s, %s, %s, %s)"
    values = (adherent['prenom'], adherent['nom'], adherent['dateNaissance'], adherent['telephone'], adherent['typeAdhesion'], None, adherent['datePaiement'])
    cursor.execute(query, values)

    cnx.commit()
    cursor.close()
    cnx.close()

    

    
    


# Fonction pour créer une nouvelle réservation dans la base de données SQL
def create_reservation(numAdherent, numTerrain, hDebut, dateResa, ):
    hDebut_dt_combined = datetime.datetime.combine(datetime.date.today(), hDebut)
    hFin_dt_combined = hDebut_dt_combined + datetime.timedelta(hours=1)
    hFin_dt = hFin_dt_combined.time()
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    cursor.execute("INSERT INTO " + table + " (numAdherent, numTerrain, hDebut, hFin, dateResa) VALUES (%s, %s, %s, %s, %s)", (numAdherent, numTerrain, hDebut, hFin_dt, dateResa))
    cnx.commit()
    cursor.close()
    cnx.close()

# Fonction pour ajouter un terrain dans la base de données SQL
def create_terrain(numTerrain):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='terrains'
    cursor.execute("INSERT INTO " + table + " (numTerrain) VALUES (%s)", (numTerrain))
    cnx.commit()
    cursor.close()
    cnx.close()

# Fonction pour supprimer un adhérent de la base de données SQL
def delete_adherent(numAdherent):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    cursor.execute("DELETE FROM " + table + " WHERE numAdherent = %s", (numAdherent))
    cnx.commit()
    cursor.close()
    cnx.close()

# Fonction pour supprimer une réservation de la base de données SQL
def delete_reservation(numReservation):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    cursor.execute("DELETE FROM " + table + " WHERE numResa = %s", (numReservation))
    cnx.commit()
    cursor.close()
    cnx.close()

# Fonction pour supprimer un terrain de la base de données SQL
def delete_terrain(numTerrain):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='terrains'
    cursor.execute("DELETE FROM " + table + " WHERE numTerrain = %s", (numTerrain))
    cnx.commit()
    cursor.close()
    cnx.close()

# Fonction pour vérifier si un adhérent existe déjà dans la base de données SQL
def adherent_exists(prenom, nom):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    cursor.execute("SELECT * FROM " + table + " WHERE prenom = %s AND nom = %s", (prenom, nom))
    adherent = cursor.fetchone()
    cursor.close()
    cnx.close()
    if adherent:
        return True
    else:
        return False
    
def adherent_exists_by_id(numAdherent):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    cursor.execute("SELECT * FROM " + table + " WHERE numAdherent = %s", (numAdherent))
    adherent = cursor.fetchone()
    cursor.close()
    cnx.close()
    if adherent:
        return True
    else:
        return False
    
def reservation_exists_by_id(numReservation):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    cursor.execute("SELECT * FROM " + table + " WHERE numResa = %s", (numReservation))
    reservation = cursor.fetchone()
    cursor.close()
    cnx.close()
    if reservation:
        return True
    else:
        return False

def terrain_exists_by_id(numTerrain):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='terrains'
    cursor.execute("SELECT * FROM " + table + " WHERE numTerrain = %s", (numTerrain))
    terrain = cursor.fetchone()
    cursor.close()
    cnx.close()
    if terrain:
        return True
    else:
        return False
    
# Fonction pour vérifier qu'un terrain existe déjà dans la base de données SQL
def terrain_exists(numTerrain):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='terrains'
    cursor.execute("SELECT * FROM " + table + " WHERE numTerrain = %s", (numTerrain))
    terrain = cursor.fetchone()
    cursor.close()
    cnx.close()
    if terrain:
        return True
    else:
        return False

# Fonction pour l'affichage des adherents avec les filtres
def get_adherents_filtres(colonne_a_afficher, flitre_a_appliquer):
    print(colonne_a_afficher, flitre_a_appliquer)
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    if colonne_a_afficher == "typeAdhesion" and flitre_a_appliquer == "adherent_competition":
        cursor.execute(f"SELECT * FROM `adherents` WHERE `typeAdhesion` = 'adherent_competition';")
    elif colonne_a_afficher == "typeAdhesion" and flitre_a_appliquer == "adherent_normal":
        cursor.execute(f"SELECT * FROM `adherents` WHERE `typeAdhesion` = 'adherent_normal';")
    elif flitre_a_appliquer == "ASC":
        cursor.execute(f"SELECT * FROM {table} ORDER BY {colonne_a_afficher} ASC;")
    elif flitre_a_appliquer == "DESC":
        cursor.execute(f"SELECT * FROM {table} ORDER BY {colonne_a_afficher} DESC;")
    adherents = cursor.fetchall()
    cursor.close()
    cnx.close()
    return adherents

    

    
# Fonction pour l'affichage des reservations avec les filtres
def get_reservations_filtres(colonne_a_afficher, flitre_a_appliquer):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    if flitre_a_appliquer == "ASC":
        cursor.execute(f"SELECT * FROM {table} ORDER BY {colonne_a_afficher} ASC;")
    elif flitre_a_appliquer == "DESC":
        cursor.execute(f"SELECT * FROM {table} ORDER BY {colonne_a_afficher} DESC;")
    reservations = cursor.fetchall()
    cursor.close()
    cnx.close()
    return reservations

# Fonction pour vérifer si la réservation est possible
def reservation_possible(numTerrain, hDebut):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)

    table='reservations'
    cursor.execute("SELECT * FROM " + table + " WHERE numTerrain = %s AND hDebut = %s", (numTerrain, hDebut))
    reservation = cursor.fetchone()
    cursor.close()
    cnx.close()
    if reservation:
        return False
    else:
        return True
    
    
# Fonction pour vérifier que la valeur de la colonne dateResa est la date du jour
def dateResa_is_today(dateResa):
    today = datetime.date.today()
    if dateResa == today:
        return True
    else:
        return False


# Fonction pour vérifier qu'une réservation existe déjà dans la base de données SQL
def reservation_exists(numAdherent, numTerrain, heure):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    cursor.execute("SELECT * FROM " + table + " WHERE numAdherent = %s AND numTerrain = %s AND hDebut = %s", (numAdherent, numTerrain, heure))
    reservation = cursor.fetchone()
    cursor.close()
    cnx.close()
    if reservation:
        return True
    else:
        return False
    
# Fonction pour modifier une réservation
def update_reservation(numAdherent, numTerrain, hDebut, hFin, dateResa, numResa):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    cursor.execute("UPDATE " + table + " SET numAdherent = %s, numTerrain = %s, hDebut = %s, hFin = %s, dateResa = %s WHERE numResa = %s", (numAdherent, numTerrain, hDebut, hFin, dateResa, numResa))
    cnx.commit()
    cursor.close()
    cnx.close()

# Fonction pour modifier un adhérent
def update_adherent(prenom, nom, dateNaissance, tel, typeAdhesion, datePaiement, numAdherent, classement):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table = 'adherents'
    print(f'la valeur de classement est {classement}')
    if classement is None:
        cursor.execute(f"UPDATE {table} SET prenom = '{prenom}', nom = '{nom}', dateNaissance = '{dateNaissance}', "
                       f"tel = '{tel}', typeAdhesion = '{typeAdhesion}', datePaiement = '{datePaiement}', "
                       f"classement = NULL WHERE numAdherent = '{numAdherent}';")
    else:
        cursor.execute(f"UPDATE {table} SET prenom = '{prenom}', nom = '{nom}', dateNaissance = '{dateNaissance}', "
                       f"tel = '{tel}', typeAdhesion = '{typeAdhesion}', datePaiement = '{datePaiement}', "
                       f"classement = {classement} WHERE numAdherent = '{numAdherent}';")

    cnx.commit()
    cursor.close()
    cnx.close()

# Fonction pour la barre de recherche adhérent
def search_adherent_by_id(numAdherent):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    cursor.execute("SELECT * FROM " + table + " WHERE numAdherent = %s", (numAdherent))
    adherent = cursor.fetchall()
    cursor.close()
    cnx.close()
    return adherent

# Fonction pour la barre de recherche reservation
def search_reservation_by_id(numResa):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='reservations'
    cursor.execute("SELECT * FROM " + table + " WHERE numResa = %s", (numResa))
    reservation = cursor.fetchall()
    cursor.close()
    cnx.close()
    return reservation

# Fonction pour verifier si un adhérent existe déjà par son nom et son prénom
def adherent_exists_by_name(nom, prenom):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    cursor.execute("SELECT * FROM " + table + " WHERE nom = %s AND prenom = %s", (nom, prenom))
    adherent = cursor.fetchone()
    cursor.close()
    cnx.close()
    if adherent:
        return True
    else:
        return False


# Fonction pou rechercher un adhérent par son nom et son prénom
def search_adherent_by_name(nom, prenom):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table='adherents'
    cursor.execute("SELECT * FROM " + table + " WHERE nom = %s AND prenom = %s", (nom, prenom))
    adherent = cursor.fetchall()
    cursor.close()
    cnx.close()
    return adherent

def get_adherents_colonne(colonnes_a_afficher):
    cnx = connect()
    cursor = cnx.cursor(pymysql.cursors.DictCursor)
    table = 'adherents'
    colonnes = ', '.join(colonnes_a_afficher)
    query = f"SELECT {colonnes} FROM {table};"
    print(query)
    cursor.execute(query)
    adherents = cursor.fetchall()
    cursor.close()
    cnx.close()
    return adherents

