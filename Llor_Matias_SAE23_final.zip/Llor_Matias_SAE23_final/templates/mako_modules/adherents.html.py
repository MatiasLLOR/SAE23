# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686103480.7184098
_enable_loop = True
_template_filename = 'templates/adherents.html'
_template_uri = 'adherents.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        adherents_data = context.get('adherents_data', UNDEFINED)
        error = context.get('error', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE mako>\r\n<html>\r\n    <head>\r\n        <title>Adherents</title>\r\n        <link rel="stylesheet" type="text/css" href="../css/style_adherents.css">\r\n    </head>\r\n    <body>\r\n        <nav class="menu">\r\n            <div><img src="../img/logo.jpg" width="50" height="auto"></div>\r\n            <div class="bloc"><a href="index" class="style_menu_text">Home</a></div>\r\n            <div class="bloc"><a href="adherents" class="style_menu_text">Adherents</a></div>\r\n            <div class="bloc"><a href="reservations" class="style_menu_text">Réservations</a></div>\r\n            <div class="bloc"><a href="reglement" class="style_menu_text">Découvrir le badminton</a></div>\r\n            <div class="bloc"><a href="administration" class="style_menu_text">Administration</a></div>\r\n        </nav>\r\n        <div><h1>BIENVENUE SUR LA PAGE DES ADHERENTS</h1></div>\r\n        <div>\r\n            <h2>Liste des adherents actuels</h2>\r\n            <p>nous disposons d\'un systeme de classement dans notre club mise à jour régulièrement ! <br> jeté un coup d\'oeil à votre classement !</p>\r\n        </div>\r\n        <!-- Affichage de la liste des adherents -->\r\n        <div>\r\n            <p>Afficher seulement les colonnes :</p>\r\n            <!--Choix des colonnes à afficher par cases à cocher-->\r\n            <form method="post" action="afficher-seulement-colonnes">\r\n                <input type="checkbox" name="numAdherent" id="numAdherent" checked>\r\n                <label for="numAdherent">Numéro Adhérent</label>\r\n                <input type="checkbox" name="prenom" id="prenom" checked>\r\n                <label for="prenom">Prénom</label>\r\n                <input type="checkbox" name="nom" id="nom" checked>\r\n                <label for="nom">Nom</label>\r\n                <input type="checkbox" name="dateNaissance" id="dateNaissance" checked>\r\n                <label for="dateNaissance">Date de Naissance</label>\r\n                <input type="checkbox" name="tel" id="tel" checked>\r\n                <label for="tel">Téléphone</label>\r\n                <input type="checkbox" name="typeAdhesion" id="typeAdhesion" checked>\r\n                <label for="typeAdhesion">Type d\'adhésion</label>\r\n                <input type="checkbox" name="datePaiement" id="datePaiement" checked>\r\n                <label for="datePaiement">Date de Paiement</label>\r\n                <input type="checkbox" name="classement" id="classement" checked>\r\n                <label for="classement">Classement</label>\r\n                <input type="submit" value="Valider">\r\n            </form>            \r\n        </div>\r\n        <div>\r\n            <table>\r\n                <thead>\r\n                    <tr>\r\n                        <th>Numéro Adhérents</th>\r\n                        <th>Prénom</th>\r\n                        <th>Nom</th>\r\n                        <th>Date de Naissance</th>\r\n                        <th>Téléphone</th>\r\n                        <th>Type d\'adhèsion</th>\r\n                        <th>Date de Paiement</th>\r\n                        <th>Classement</th>\r\n                    </tr>\r\n                </thead>\r\n                <tbody>\r\n')
        for adherent in adherents_data :
            __M_writer('                    <tr>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['numAdherent'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['numAdherent']))
            __M_writer('</td>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['prenom'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['prenom']))
            __M_writer('</td>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['nom'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['nom']))
            __M_writer('</td>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['dateNaissance'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['dateNaissance']))
            __M_writer('</td>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['tel'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['tel']))
            __M_writer('</td>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['typeAdhesion'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['typeAdhesion']))
            __M_writer('</td>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['datePaiement'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['datePaiement']))
            __M_writer('</td>\r\n                        <td class="')
            __M_writer(str('empty' if adherent['classement'] is None else ''))
            __M_writer('">')
            __M_writer(str(adherent['classement']))
            __M_writer('</td>\r\n                    </tr>                    \r\n')
        __M_writer('                </tbody>\r\n            </table>\r\n        </div>\r\n        <!-- Barre de proposition de tri d\'affichage -->\r\n        <div><p>Sélectionner le tri à effectuer</p></div>\r\n        <div class="choice_barre1">\r\n            <div class="choice1">\r\n                <div class="name1">numAdherent :</div>\r\n                <a href="tri-adherents?tri=numAdherent-croissant" class="buttun">croissant</a>\r\n                <a href="tri-adherents?tri=numAdherent-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">nom :</div>\r\n                <!-- panneau deroulant pour le choix adherent -->\r\n                <a href="tri-adherents?tri=nom-alpha" class="buttun">ordre Alphabétique</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">prenom :</div>\r\n                <!-- panneau deroulant pour le choix adherent -->\r\n                <a href="tri-adherents?tri=prenom-alpha" class="buttun">ordre Alphabétique</a>\r\n            </div>\r\n            <div class="choice1"> \r\n                <div class="name1">date de naissance :</div>\r\n             <!-- panneau deroulant pour le choix adherent -->\r\n                <a href="tri-adherents?tri=dateNaissance-croissant" class="buttun">croissant</a>\r\n                <a href="tri-adherents?tri=dateNaissance-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">téléphone :</div>\r\n             <!-- panneau deroulant pour le choix adherent -->\r\n                <a href="tri-adherents?tri=tel-croissant" class="buttun">croissant</a>\r\n                <a href="tri-adherents?tri=tel-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">type d\'adhésion</div>\r\n             <!-- panneau deroulant pour le choix adherent -->\r\n                <a href="tri-adherents?tri=typeAdhesion-normal" class="buttun">normal</a>\r\n                <a href="tri-adherents?tri=typeAdhesion-compet" class="buttun">compétition</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">date de Paiement :</div>\r\n            <!-- panneau deroulant pour le choix adherent -->\r\n                <a href="tri-adherents?tri=datePaiement-croissant" class="buttun">croissant</a>\r\n                <a href="tri-adherents?tri=datePaiement-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">classement :</div>\r\n             <!-- panneau deroulant pour le choix adherent -->\r\n                <a href="tri-adherents?tri=classement-croissant" class="buttun">croissant</a>\r\n                <a href="tri-adherents?tri=classement-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n        </div>\r\n        <!--Rechercher un adherent par son nom et son prenom-->\r\n        <div><p>Rechercher un adhérent par son nom et son prénom</p></div>\r\n        <div class="choice_barre2">\r\n            <form action="search-adherent" method="post">\r\n                <div class="choice2">\r\n                    <div class="name1">Prenom :</div>\r\n                    <input type="text" id="prenom" name="prenom" required>\r\n                </div>\r\n                <div class="choice2">\r\n                    <div class="name1">Nom :</div>\r\n                    <input type="text" id="nom" name="nom" required>\r\n                </div>\r\n                <div class="choice2">\r\n                    <input type="submit" value="Rechercher" class="buttun">\r\n                </div>\r\n            </form>\r\n        </div>\r\n        <div>\r\n')
        if error:
            __M_writer('            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('        </div>\r\n        <!-- Partie questionnaire pour ajouter un adhenrent-->\r\n        <h2>Vous souhaitez devenir un membre actif de notre club ?</h2>\r\n        <h3>Inscrivez vous avec ce rapide questionnaire et rejoingez-nous en tant que joueur pour le plaisir ou entrer dans la compétition inter-club !!</h3>\r\n        <div><p>Questionnaire d\'Inscription</p></div>\r\n        <form action="creer-adherent" method="post">\r\n    \r\n            <label for="prenom">Prénom :</label>\r\n            <input type="text" id="prenom" name="prenom" required><br><br>\r\n            \r\n            <label for="nom">Nom :</label>\r\n            <input type="text" id="nom" name="nom" required><br><br>\r\n            \r\n            <label for="dateNaissance">Date de Naissance :</label>\r\n            <input type="date" id="dateNaissance" name="dateNaissance" required><br><br>\r\n            \r\n            <label for="tel">Téléphone :</label>\r\n            <input type="tel" id="tel" name="tel" required><br><br>\r\n            \r\n            <label for="typeAdhesion">Type d\'adhésion :</label>\r\n            <select id="typeAdhesion" name="typeAdhesion" required>\r\n                <option value="normal">Normal</option>\r\n                <option value="compétition">Compétition</option>\r\n            </select><br><br>\r\n            \r\n            <label for="datePaiement">Date de Paiement :</label>\r\n            <input type="date" id="datePaiement" name="datePaiement" required><br><br>\r\n            \r\n            <input type="submit" value="Créer">\r\n        </form>\r\n        <!-- message erreur si l\'adherent existe déjà-->\r\n        <div>\r\n')
        if error:
            __M_writer('            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('        </div>\r\n        <button onclick="scrollToTop()" id="scrollToTop" title="Remonter en haut">&#9650;</button>\r\n\r\n        <script>\r\n            // Afficher le bouton lorsque l\'utilisateur a défilé 20 pixels vers le bas\r\n            window.onscroll = function() {\r\n                if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {\r\n                    document.getElementById("scrollToTop").style.display = "block";\r\n                } else {\r\n                    document.getElementById("scrollToTop").style.display = "none";\r\n                }\r\n            };\r\n\r\n            // Faire défiler la page jusqu\'en haut lorsque le bouton est cliqué\r\n            function scrollToTop() {\r\n                document.body.scrollTop = 0; // Pour les navigateurs Safari\r\n                document.documentElement.scrollTop = 0; // Pour les autres navigateurs\r\n            }\r\n        </script>\r\n    </body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "templates/adherents.html", "uri": "adherents.html", "source_encoding": "utf-8", "line_map": {"16": 0, "23": 1, "24": 60, "25": 61, "26": 62, "27": 62, "28": 62, "29": 62, "30": 63, "31": 63, "32": 63, "33": 63, "34": 64, "35": 64, "36": 64, "37": 64, "38": 65, "39": 65, "40": 65, "41": 65, "42": 66, "43": 66, "44": 66, "45": 66, "46": 67, "47": 67, "48": 67, "49": 67, "50": 68, "51": 68, "52": 68, "53": 68, "54": 69, "55": 69, "56": 69, "57": 69, "58": 72, "59": 142, "60": 143, "61": 143, "62": 143, "63": 145, "64": 177, "65": 178, "66": 178, "67": 178, "68": 180, "74": 68}}
__M_END_METADATA
"""
