# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686103705.307913
_enable_loop = True
_template_filename = 'templates/reservation.html'
_template_uri = 'reservation.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        error = context.get('error', UNDEFINED)
        reservations_data = context.get('reservations_data', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE mako>\r\n<html>\r\n    <head>\r\n        <title>Adherents</title>\r\n        <link rel="stylesheet" type="text/css" href="../css/style_reservation.css">\r\n    </head>\r\n    <body>\r\n        <nav class="menu">\r\n            <div><img src="../img/logo.jpg" width="50" height="auto"></div>\r\n            <div class="bloc"><a href="index" class="style_menu_text">Home</a></div>\r\n            <div class="bloc"><a href="adherents" class="style_menu_text">Adherents</a></div>\r\n            <div class="bloc"><a href="reservations" class="style_menu_text">Réservations</a></div>\r\n            <div class="bloc"><a href="reglement" class="style_menu_text">Découvrir le badminton</a></div>\r\n            <div class="bloc"><a href="administration" class="style_menu_text">Administration</a></div>\r\n        </nav>\r\n        <div><h1>BIENVENUE SUR LA PAGE DES RESERVATIONS</h1></div>\r\n        <div>\r\n            <h2>Vous pouvez ici la liste des réservations de la journée</h2>\r\n            <p>notre club est ouvert en CONTINU !!<br> réservez votre ou vos créneaux de 1h dès maintenant (Inscription Obligatoire) :</p>\r\n        </div>\r\n        <!-- Affichage de la liste des réservations -->\r\n        <div>\r\n            <table>\r\n                <thead>\r\n                    <tr>\r\n                        <th>Num de la Réservation</th>\r\n                        <th>heure de Début</th>\r\n                        <th>heure de Fin</th>\r\n                        <th>numéro du Terrain</th>\r\n                        <th>numéro de l\'Adhérent</th>\r\n                        <th>date de la Réservation</th>\r\n                    </tr>\r\n                </thead>\r\n                <tbody>\r\n')
        for reservation in reservations_data:
            __M_writer('                    <tr>\r\n                        <td>')
            __M_writer(str(reservation['numReservation']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(reservation['heureDebut']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(reservation['heureFin']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(reservation['numTerrain']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(reservation['numAdherent']))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(reservation['dateReservation']))
            __M_writer('</td>\r\n                    </tr>\r\n')
        __M_writer('                </tbody>\r\n            </table>\r\n        </div>\r\n        <!-- Barre de proposition de tri d\'affichage -->\r\n        <div><p>Sélectionner le tri à effectuer</p></div>\r\n        <div class="choice_barre1">\r\n            <div class="choice1">\r\n                <div class="name1">numResa :</div>\r\n                <a href="tri-reservations?tri=numResa-croissant" class="buttun">croissant</a>\r\n                <a href="tri-reservations?tri=numResa-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">heure Début :</div>\r\n                <!-- panneau deroulant pour le choix des reservation -->\r\n                <a href="tri-reservations?tri=hDebut-croissant" class="buttun">croissant</a>\r\n                <a href="tri-reservations?tri=hDebut-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">heure Fin :</div>\r\n                <!-- panneau deroulant pour le choix des reservations -->\r\n                <a href="tri-reservations?tri=hFin-croissant" class="buttun">croissant</a>\r\n                <a href="tri-reservations?tri=hFin-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1"> \r\n                <div class="name1">numTerrain :</div>\r\n             <!-- panneau deroulant pour le choix des reservations -->\r\n             <a href="tri-reservations?tri=numTerrain-croissant" class="buttun">croissant</a>\r\n             <a href="tri-reservations?tri=numTerrain-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n            <div class="choice1">\r\n                <div class="name1">numAdherent :</div>\r\n             <!-- panneau deroulant pour le choix des reservations -->\r\n             <a href="tri-reservations?tri=numAdherent-croissant" class="buttun">croissant</a>\r\n             <a href="tri-reservations?tri=numAdherent-decroissant" class="buttun">décroissant</a>\r\n            </div>\r\n        </div>\r\n        <!-- Partie questionnaire pour ajouter un adhenrent-->\r\n        <h2>Vous souhaitez réserver un terrain ?</h2>\r\n        <h3>Remplissez le formulaire de reservation et obtener votre terrain (n\'oubliez pas de vous inscrire au préalable)</h3>\r\n        <div><p>Questionnaire de Réservation</p></div>\r\n        <form action="creer-reservation" method="post">\r\n    \r\n            <label for="numAdherent">num d\'Adherent :</label>\r\n            <input type="text" id="numAdherent" name="numAdherent" required><br><br>\r\n            \r\n            <label for="hDebut">heure Debut :</label>\r\n            <input type="time" id="hDebut" name="hDebut" required><br><br>\r\n            \r\n            <label for="numTerrain">num Terrain :</label>\r\n            <input type="number" id="numTerrain" name="numTerrain" required><br><br>\r\n            \r\n            <label for="dateResa">date de Réservation ( entrer la date d\'aujourd\'hui) :</label>\r\n            <input type="date" id="dateResa" name="dateResa" required><br><br>\r\n            \r\n            <input type="submit" value="Créer">\r\n        </form>\r\n        <!-- message erreur si l\'adherent existe déjà, si la resa existe deja, si elle est impossible, si la date de correspond pas  -->\r\n        <div>\r\n')
        if error:
            __M_writer('            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('        </div> \r\n    </body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "templates/reservation.html", "uri": "reservation.html", "source_encoding": "utf-8", "line_map": {"16": 0, "23": 1, "24": 35, "25": 36, "26": 37, "27": 37, "28": 38, "29": 38, "30": 39, "31": 39, "32": 40, "33": 40, "34": 41, "35": 41, "36": 42, "37": 42, "38": 45, "39": 103, "40": 104, "41": 104, "42": 104, "43": 106, "49": 43}}
__M_END_METADATA
"""
