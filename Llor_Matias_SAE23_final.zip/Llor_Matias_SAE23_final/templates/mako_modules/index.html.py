# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686089699.1329293
_enable_loop = True
_template_filename = 'templates/index.html'
_template_uri = 'index.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('<html>\r\n  <head>\r\n    <title>Home</title>\r\n    <link rel="stylesheet" type="text/css" href="../css/style_index.css">\r\n  </head>\r\n  <body>\r\n    <nav class="menu">\r\n      <div><img src="../img/logo.jpg" width="50" height="auto"></div>\r\n      <div class="bloc"> <a href="index" class="style_menu_text">Home</a></div>\r\n      <div class="bloc"><a href="adherents" class="style_menu_text">Adherents</a></div>\r\n      <div class="bloc"><a href="reservations" class="style_menu_text">Réservations</a></div>\r\n      <div class="bloc"><a href="reglement" class="style_menu_text">Découvrir le badminton</a></div>\r\n      <div class="bloc"><a href="administration" class="style_menu_text">Administration</a></div>\r\n    </nav>\r\n    <div class="acceuil">\r\n      <div class="container">\r\n      <img src="../img/img3.jpg" alt="presentation" class="image1">\r\n      </div>\r\n      <div class="presentation">\r\n        <h1>Bienvenue !!</h1>\r\n        <h2>Club de badminton dynamique et convivial <br>\r\n        Terrains réservables en ligne. Rejoignez-nous et vivez la passion du volant !</h2>\r\n      </div>\r\n    </div>\r\n    <div class="presentation_club">\r\n      <div class="cadre">\r\n        <h1>Le club :</h1>\r\n        <h2 id="cache">Le club de badminton de la ville de Saint-Quentin-en-Yvelines est un club dynamique et convivial. <br>\r\n        Il est ouvert à tous les joueurs, du débutant au confirmé, du loisir à la compétition. <br>\r\n        Le club est affilié à la Fédération Française de Badminton (FFBaD) et à la Fédération Française du Sport d\'Entreprise (FFSE). <br>\r\n        Il est labellisé 2 étoiles par la FFBaD.</h2>\r\n      </div>\r\n    </div>\r\n    <div class="img_deco">\r\n      <div class="image">\r\n        <img src="../img/club1.jpg" alt="Image 1">\r\n      </div>\r\n      <div class="image">\r\n        <img src="../img/club 2.jpg" alt="Image 2">\r\n      </div>\r\n    </div>\r\n    <div class="fin_accueil">\r\n      <div class="choice">\r\n        <div id="texte"><p>Faitre votre choix pour naviguer sur notre site </p></div>\r\n      </div>\r\n      <div class="placement_button">\r\n        <div class="espace"><a href="adherents" class="button">Adhérents <br> Devenir un membre actif de notre club</a></div>\r\n        <div class="espace"><a href="reservations" class="button">Réservation <br> Réservez votre terrain pour le lendemain</a></div>\r\n      </div>\r\n    </div>\r\n    <div class="barre_de_fin">\r\n      <div class="texte">\r\n        <p>© 2023 - Badminton Club de Saint-Quentin-en-Yvelines</p>\r\n      </div>\r\n      <div class="texte">\r\n        <p>Site réalisé par : <br> <a href="mailto:>">Llor Desfarges Matias</a></p>\r\n    </div>\r\n  </body>\r\n</html')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "templates/index.html", "uri": "index.html", "source_encoding": "utf-8", "line_map": {"16": 0, "21": 1, "27": 21}}
__M_END_METADATA
"""
