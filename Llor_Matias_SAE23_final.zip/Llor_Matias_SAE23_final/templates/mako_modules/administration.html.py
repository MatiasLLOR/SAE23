# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686095474.8207464
_enable_loop = True
_template_filename = 'templates/administration.html'
_template_uri = 'administration.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        error = context.get('error', UNDEFINED)
        terrains_data = context.get('terrains_data', UNDEFINED)
        reservations_data = context.get('reservations_data', UNDEFINED)
        adherents_data = context.get('adherents_data', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE mako>\r\n<html>\r\n    <head>\r\n        <title>Adherents</title>\r\n        <link rel="stylesheet" type="text/css" href="../css/style_administration.css">\r\n    </head>\r\n    <body>\r\n        <nav class="menu">\r\n            <div><img src="../img/logo.jpg" width="50" height="auto"></div>\r\n            <div class="bloc"><a href="index" class="style_menu_text">Home</a></div>\r\n            <div class="bloc"><a href="adherents" class="style_menu_text">Adherents</a></div>\r\n            <div class="bloc"><a href="reservations" class="style_menu_text">Réservations</a></div>\r\n            <div class="bloc"><a href="reglement" class="style_menu_text">Découvrir le badminton</a></div>\r\n            <div class="bloc"><a href="administration" class="style_menu_text">Administration</a></div>\r\n        </nav>\r\n        <div><h1>Administration du site</h1></div>\r\n        <div class="corps">\r\n            <div class="partie">\r\n                <div class="table">\r\n                    <h2>Partie Adherents</h2>\r\n                    <!--supprimer un adherent-->\r\n                    <div class="sous_table">\r\n                        <h3>Supprimer un adhérent</h3>\r\n                        <form action="suppression-adherent" method="post">\r\n                            <label for="numAdherent">num d\'Adherent :</label>\r\n                            <input type="text" id="numAdherent" name="numAdherent" required><br><br>\r\n                            <input type="submit" value="Supprimer">\r\n                        </form>\r\n                        <!-- message erreur si l\'adherent n\'existe pas -->\r\n                        <div>\r\n')
        if error:
            __M_writer('                            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                    <div class="sous_table">\r\n                        <h3>Rechercher un adherent par nom ID</h3>\r\n                        <form action="search-adherent-by-number" method="post">\r\n                            <label for="numAdherent">num d\'Adherent :</label>\r\n                            <input type="number" id="numAdherent" name="numAdherent" required><br><br>\r\n                            <input type="submit" value="Rechercher">\r\n                        </form>\r\n                        <!-- message erreur si l\'adherent n\'existe pas -->\r\n                        <div>\r\n')
        if error:
            __M_writer('                            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('                    </div>\r\n                    <!--modifier un adherent-->\r\n                    <div class="sous_table">\r\n                        <h3>Modifier un adhérent</h3>\r\n                        <form action="modification-adherent" method="post">\r\n                            <label for="numAdherent">num d\'Adherent :</label>\r\n                            <input type="number" id="numAdherent" name="numAdherent" required><br><br>\r\n                            <label for="prenom">Prénom :</label>\r\n                            <input type="text" id="prenom" name="prenom" required><br><br>\r\n                            <label for="nom">Nom :</label>\r\n                            <input type="text" id="nom" name="nom" required><br><br>\r\n                            <label for="dateNaissance">Date de Naissance :</label>\r\n                            <input type="date" id="dateNaissance" name="dateNaissance" required><br><br>\r\n                            <label for="tel">Téléphone :</label>\r\n                            <input type="text" id="tel" name="tel" required><br><br>\r\n                            <label for="typeAdhesion">Type d\'adhésion :</label>\r\n                            <select id="typeAdhesion" name="typeAdhesion" required>\r\n                                <option value="adherent_normal">Normal</option>\r\n                                <option value="adherent_competition">Compétition</option>\r\n                            </select><br><br>\r\n                            <label for="datePaiement">Date de Paiement :</label>\r\n                            <input type="date" id="datePaiement" name="datePaiement" required><br><br>\r\n                            <label for="classement">Classement :</label>\r\n                            <input type="text" id="classement" name="classement"><br><br>\r\n                            <input type="submit" value="Modifier">\r\n                        </form>\r\n                        <!-- message erreur si l\'adherent n\'existe pas -->\r\n                        <div>\r\n')
        if error:
            __M_writer('                            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class="partie">\r\n                <div class="table">\r\n                    <h2>Partie Reservations</h2>\r\n                    <div class="sous_table">\r\n                        <h3>Supprimer une réservation</h3>\r\n                        <form action="suppression-reservation" method="post">\r\n                            <label for="numReservation">num de Réservation :</label>\r\n                            <input type="text" id="numReservation" name="numReservation" required><br><br>\r\n                            <input type="submit" value="Supprimer">\r\n                        </form>\r\n                        <!-- message erreur si la reservation n\'existe pas -->\r\n                        <div>\r\n')
        if error:
            __M_writer('                            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                    <div class="sous_table">\r\n                        <h3>Rechercher une réservation par ID</h3>\r\n                        <form action="search-reservation-by-number" method="post">\r\n                            <label for="numReservation">num de Réservation :</label>\r\n                            <input type="number" id="numReservation" name="numReservation" required><br><br>\r\n                            <input type="submit" value="Rechercher">\r\n                        </form>\r\n                        <!-- message erreur si la reservation n\'existe pas -->\r\n                        <div>\r\n')
        if error:
            __M_writer('                            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                    <div class="sous_table">\r\n                        <h3>Modifier une réservation</h3>\r\n                        <form action="modification-reservation" method="post">\r\n                            <label for="numResa">num de Réservation :</label>\r\n                            <input type="text" id="numResa" name="numResa" required><br><br>\r\n                            <label for="dateResa">Date de Réservation :</label>\r\n                            <input type="date" id="dateResa" name="dateResa" required><br><br>\r\n                            <label for="hDebut">Heure de début :</label>\r\n                            <input type="time" id="hDebut" name="hDebut" required><br><br>\r\n                            <label for="hFin">Heure de fin :</label>\r\n                            <input type="time" id="hFin" name="hFin" required><br><br>\r\n                            <label for="numAdherent">num d\'Adherent :</label>\r\n                            <input type="text" id="numAdherent" name="numAdherent" required><br><br>\r\n                            <label for="numTerrain">num de Terrain :</label>\r\n                            <input type="text" id="numTerrain" name="numTerrain" required><br><br>\r\n                            <input type="submit" value="Modifier">\r\n                        </form>\r\n                        <!-- message erreur si la reservation n\'existe pas -->\r\n                        <div>\r\n')
        if error:
            __M_writer('                            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class="partie">\r\n                <div class="table">\r\n                    <h2>Partie Terrains</h2>\r\n                    <div class="sous_table">\r\n                        <h3>Ajouter un terrain</h3>\r\n                        <form action="ajouter-terrain" method="post">\r\n                            <label for="numTerrain">num de Terrain :</label>\r\n                            <input type="text" id="numTerrain" name="numTerrain" required><br><br>\r\n                            <input type="submit" value="Ajouter">\r\n                        </form>\r\n                        <!-- message erreur si le terrain existe -->\r\n                        <div>\r\n')
        if error:
            __M_writer('                            <p class="error">')
            __M_writer(str(error))
            __M_writer('</p>\r\n')
        __M_writer("                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <!-- Affichage des tableaux de toutes les tables-->\r\n        <div>\r\n            <!-- Affichage de la liste des adherents -->\r\n            <div>\r\n                <table>\r\n                    <thead>\r\n                        <tr>\r\n                            <th>Numéro Adhérents</th>\r\n                            <th>Prénom</th>\r\n                            <th>Nom</th>\r\n                            <th>Date de Naissance</th>\r\n                            <th>Téléphone</th>\r\n                            <th>Type d'adhèsion</th>\r\n                            <th>Date de Paiement</th>\r\n                            <th>Classement</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n")
        for adherent in adherents_data :
            __M_writer('                        <tr>\r\n                            <td>')
            __M_writer(str(adherent['numAdherent']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(adherent['prenom']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(adherent['nom']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(adherent['dateNaissance']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(adherent['tel']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(adherent['typeAdhesion']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(adherent['datePaiement']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(adherent['classement']))
            __M_writer('</td>\r\n                        </tr>\r\n')
        __M_writer("                    </tbody>\r\n                </table>\r\n            </div>\r\n            <!-- Affichage de la liste des réservations -->\r\n            <div>\r\n                <table>\r\n                    <thead>\r\n                        <tr>\r\n                            <th>Num de la Réservation</th>\r\n                            <th>heure de Début</th>\r\n                            <th>heure de Fin</th>\r\n                            <th>numéro du Terrain</th>\r\n                            <th>numéro de l'Adhérent</th>\r\n                            <th>date de la Réservation</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n")
        for reservation in reservations_data:
            __M_writer('                        <tr>\r\n                            <td>')
            __M_writer(str(reservation['numReservation']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(reservation['heureDebut']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(reservation['heureFin']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(reservation['numTerrain']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(reservation['numAdherent']))
            __M_writer('</td>\r\n                            <td>')
            __M_writer(str(reservation['dateReservation']))
            __M_writer('</td>\r\n                        </tr>\r\n')
        __M_writer('                    </tbody>\r\n                </table>\r\n            </div>\r\n            <!-- Affichage de la liste des terrains -->\r\n            <div>\r\n                <table>\r\n                    <thead>\r\n                        <tr>\r\n                            <th>Numéro du Terrain</th>\r\n                        </tr>\r\n                    </thead>\r\n                    <tbody>\r\n')
        for terrain in terrains_data:
            __M_writer('                        <tr>\r\n                            <td>')
            __M_writer(str(terrain['numTerrain']))
            __M_writer('</td>\r\n                        </tr>\r\n')
        __M_writer('                    </tbody>\r\n                </table>\r\n        </div>\r\n        <button onclick="scrollToTop()" id="scrollToTop" title="Remonter en haut">&#9650;</button>\r\n\r\n        <script>\r\n            // Afficher le bouton lorsque l\'utilisateur a défilé 20 pixels vers le bas\r\n            window.onscroll = function() {\r\n                if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {\r\n                    document.getElementById("scrollToTop").style.display = "block";\r\n                } else {\r\n                    document.getElementById("scrollToTop").style.display = "none";\r\n                }\r\n            };\r\n\r\n            // Faire défiler la page jusqu\'en haut lorsque le bouton est cliqué\r\n            function scrollToTop() {\r\n                document.body.scrollTop = 0; // Pour les navigateurs Safari\r\n                document.documentElement.scrollTop = 0; // Pour les autres navigateurs\r\n            }\r\n        </script>       \r\n    </body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "templates/administration.html", "uri": "administration.html", "source_encoding": "utf-8", "line_map": {"16": 0, "25": 1, "26": 31, "27": 32, "28": 32, "29": 32, "30": 34, "31": 45, "32": 46, "33": 46, "34": 46, "35": 48, "36": 76, "37": 77, "38": 77, "39": 77, "40": 79, "41": 95, "42": 96, "43": 96, "44": 96, "45": 98, "46": 109, "47": 110, "48": 110, "49": 110, "50": 112, "51": 133, "52": 134, "53": 134, "54": 134, "55": 136, "56": 152, "57": 153, "58": 153, "59": 153, "60": 155, "61": 178, "62": 179, "63": 180, "64": 180, "65": 181, "66": 181, "67": 182, "68": 182, "69": 183, "70": 183, "71": 184, "72": 184, "73": 185, "74": 185, "75": 186, "76": 186, "77": 187, "78": 187, "79": 190, "80": 207, "81": 208, "82": 209, "83": 209, "84": 210, "85": 210, "86": 211, "87": 211, "88": 212, "89": 212, "90": 213, "91": 213, "92": 214, "93": 214, "94": 217, "95": 229, "96": 230, "97": 231, "98": 231, "99": 234, "105": 99}}
__M_END_METADATA
"""
