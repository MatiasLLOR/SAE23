# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686093173.8529134
_enable_loop = True
_template_filename = 'templates/reglebadminton.html'
_template_uri = 'reglebadminton.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('<html>\n    <head>\n        <title>Home</title>\n        <link rel="stylesheet" type="text/css" href="../css/style_regle.css">\n    </head>\n    <body>\n        <nav class="menu">\n            <div><img src="../img/logo.jpg" width="50" height="auto"></div>\n            <div class="bloc"> <a href="index" class="style_menu_text">Home</a></div>\n            <div class="bloc"><a href="adherents" class="style_menu_text">Adherents</a></div>\n            <div class="bloc"><a href="reservations" class="style_menu_text">Réservations</a></div>\n            <div class="bloc"><a href="reglement" class="style_menu_text">Découvrir le badminton</a></div>\n            <div class="bloc"><a href="administration" class="style_menu_text">Administration</a></div>\n        </nav>\n        <h1>Le Badminton</h1>\n\n        <div class="section">\n            <h2>Règles du Badminton</h2>\n            <p>Le badminton est un sport de raquette qui se joue en simple (1 joueur contre 1 joueur) ou en double (2 joueurs contre 2 joueurs). L\'objectif est de frapper un volant avec une raquette par-dessus un filet, de manière à ce qu\'il atterrisse dans le camp adverse sans être renvoyé.</p>\n            <p>Les règles du badminton incluent des zones de service, des règles de service, des fautes et des pénalités, ainsi que des règles spécifiques pour les matchs en simple et en double.</p>\n            <img src="../img/Limites-court-bad-simple-double.png" alt="img_limite">\n            <img src="../img/lexique-raquette.jpg" alt="lexique-raquette">\n            <img src="../img/fautes.jpg" alt="fautes" width="400" height="300">\n        </div>\n\n        <div class="section">\n            <h2>Histoire du Badminton</h2>\n            <p>Le badminton aurait été inventé en Inde il y a plusieurs siècles. Il était à l\'origine appelé le "poona" et était pratiqué comme un jeu de divertissement. Au fil du temps, le badminton s\'est développé et est devenu un sport compétitif populaire dans le monde entier.</p>\n        </div>\n\n        <div class="section">\n            <h2>Renommée Internationale</h2>\n            <p>Le badminton est largement pratiqué à travers le monde et est particulièrement populaire en Asie, en Europe et dans certains pays d\'Amérique du Nord. Il est reconnu comme un sport olympique depuis 1992.</p>\n            <img src="../img/deco1.jpg" alt="deco1" width="800" height="auto">\n        </div>\n\n        <div class="section">\n            <h2>Champions du Monde Actuels</h2>\n            <p>Les champions du monde actuels en badminton sont déterminés lors des Championnats du Monde de Badminton organisés par la Fédération Mondiale de Badminton (BWF). Les champions du monde sont couronnés dans différentes catégories, y compris les simples hommes et femmes, les doubles hommes et femmes, et les doubles mixtes.</p>\n            <p>Les noms des champions du monde actuels peuvent varier en fonction de l\'année et de la catégorie spécifique. Vous pouvez consulter le site officiel de la BWF pour obtenir les informations les plus récentes sur les champions du monde.</p>\n        </div>\n\n        <div class="section">\n            <h2>Le Badminton en France</h2>\n            <p>En France, le badminton est un sport populaire qui compte de nombreux joueurs et clubs à travers le pays. La Fédération Française de Badminton (FFBaD) est l\'organisme officiel qui supervise et développe le badminton en France.</p>\n            <p>La France participe régulièrement à des compétitions internationales de badminton, notamment les Championnats d\'Europe et les Championnats du Monde. Le pays a produit plusieurs joueurs de haut niveau qui ont excellé sur la scène internationale.</p>\n            <p>Les frères Popov actuellement les Francais plus renommés sur scène internationale :</p>\n            <img src="../img/Popov-freres-min-1.jpg" alt="Popov" width="700" height="auto">\n        </div>\n    </body>\n    \n\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "templates/reglebadminton.html", "uri": "reglebadminton.html", "source_encoding": "utf-8", "line_map": {"16": 0, "21": 1, "27": 21}}
__M_END_METADATA
"""
