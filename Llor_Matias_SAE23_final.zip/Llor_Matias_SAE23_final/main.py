from datetime import date
import cherrypy, os, os.path
from mako.template import Template
from mako.lookup import TemplateLookup
from initBase import generate_data, connect
import datetime
from fonction import afficheur, backspace
import inquirer




mylookup = TemplateLookup(directories=['templates'], input_encoding='utf-8', module_directory='templates/mako_modules')


class InterfaceWebbadminton(object):    
    ###### Page d'accueil #############
    @cherrypy.expose
    def index(self):
        mytemplate = mylookup.get_template("index.html")
        return mytemplate.render()
    
    ###### Page d'adhérent #############
    @cherrypy.expose
    def adherents(self, tri_numAdherent=None, tri_nom=None, tri_prenom=None, tri_dateNaissance=None, tri_tel=None, tri_typeAdhesion=None, tri_datePaiement=None, tri_classement=None):
        adherents_data = []
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())

        mytemplate = mylookup.get_template("adherents.html")
        return mytemplate.render(adherents_data=adherents_data)
    
    @cherrypy.expose
    def tri_adherents(self, tri=None):
        adherents_data = []
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        if tri == "numAdherent-croissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('numAdherent', 'ASC'))
        elif tri == "numAdherent-decroissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('numAdherent', 'DESC'))
        elif tri == "nom-alpha":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('nom', 'ASC'))
        elif tri == "prenom-alpha":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('prenom', 'ASC'))
        elif tri == "dateNaissance-croissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('dateNaissance', 'ASC'))
        elif tri == "dateNaissance-decroissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('dateNaissance', 'DESC'))
        elif tri == "tel-croissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('tel', 'ASC'))
        elif tri == "tel-decroissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('tel', 'DESC'))
        elif tri == "typeAdhesion-normal":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('typeAdhesion', 'adherent_normal'))
        elif tri == "typeAdhesion-compet":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('typeAdhesion', 'adherent_competition'))
        elif tri == "classement-croissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('classement', 'ASC'))
        elif tri == "classement-decroissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('classement', 'DESC'))
        elif tri == "datePaiement-croissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('datePaiement', 'ASC'))
        elif tri == "datePaiement-decroissant":
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents_filtres('datePaiement', 'DESC'))
        
        mytemplate = mylookup.get_template("adherents.html")
        return mytemplate.render(adherents_data=adherents_data, )

    @cherrypy.expose
    def creer_adherent(self, prenom, nom, dateNaissance, tel, typeAdhesion, datePaiement):
        adherent = {
            'prenom': str(prenom),
            'nom': str(nom),
            'dateNaissance': datetime.datetime.strptime(dateNaissance, '%Y-%m-%d').date(),
            'telephone': int(tel),
            'typeAdhesion': str(typeAdhesion),
            'datePaiement': datetime.datetime.strptime(datePaiement, '%Y-%m-%d').date(),
        }
        if backspace.adherent_exists(adherent['prenom'], adherent['nom']) == True:
            error = "L'adhérent existe déjà."
            adherents_data = backspace.get_adherents()
            mytemplate = mylookup.get_template("adherents.html")
            return mytemplate.render(adherents_data=adherents_data, error=error)
        else:
            backspace.create_adherent(adherent)

        print('adherent créé')
        adherents_data = backspace.get_adherents()
        mytemplate = mylookup.get_template("adherents.html")
        return mytemplate.render(adherents_data=adherents_data)


    ###### Page des réservations #############
    @cherrypy.expose
    def reservations(self, tri_numReservation=None, tri_numAdherent=None, tri_dateReservation=None, tri_heureDebut=None, tri_heureFin=None):
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        print(reservations_data)
        mytemplate = mylookup.get_template("reservation.html")
        return mytemplate.render(reservations_data=reservations_data, )
    
    @cherrypy.expose
    def tri_reservations(self, tri=None):
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        if tri == "numResa-croissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('numResa', 'ASC'))
        elif tri == "numResa-decroissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('numResa', 'DESC'))
        elif tri == "numAdherent-croissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('numAdherent', 'ASC'))
        elif tri == "numAdherent-decroissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('numAdherent', 'DESC'))
        elif tri == "hDebut-croissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('hDebut', 'ASC'))
        elif tri == "hDebut-decroissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('hDebut', 'DESC'))
        elif tri == "hFin-croissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('hFin', 'ASC'))
        elif tri == "hFin-decroissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('hFin', 'DESC'))
        elif tri == "numTerrain-croissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('numTerrain', 'ASC'))
        elif tri == "numTerrain-decroissant":
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations_filtres('numTerrain', 'DESC'))
        
        mytemplate = mylookup.get_template("reservation.html")
        return mytemplate.render(reservations_data=reservations_data)

    @cherrypy.expose
    def creer_reservation(self, numAdherent, dateResa, hDebut, numTerrain):
        reservation = {
            'numAdherent': int(numAdherent),
            'dateResa': datetime.datetime.strptime(dateResa, '%Y-%m-%d').date(),
            'hDebut': datetime.datetime.strptime(hDebut, '%H:%M').time(),
            'numTerrain': int(numTerrain),
        }
        if backspace.reservation_exists(reservation['numAdherent'], reservation['numTerrain'], reservation['hDebut'], ) == True:
            error = "La réservation existe déjà."
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            mytemplate = mylookup.get_template("reservation.html")
            return mytemplate.render(reservations_data=reservations_data, error=error)
        elif backspace.reservation_possible(reservation['numTerrain'], reservation['hDebut']) == False:
            error = "La réservation n'est pas possible."	
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            mytemplate = mylookup.get_template("reservation.html")
            return mytemplate.render(reservations_data=reservations_data, error=error)
        elif backspace.adherent_exists_by_id(reservation['numAdherent']) == False:
            error = "L'adhérent n'existe pas."
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            mytemplate = mylookup.get_template("reservation.html")
            return mytemplate.render(reservations_data=reservations_data, error=error)
        elif backspace.dateResa_is_today(reservation['dateResa']) == False:
            error = "La date de réservation n'est pas aujourd'hui."
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            mytemplate = mylookup.get_template("reservation.html")
            return mytemplate.render(reservations_data=reservations_data, error=error)
        else:
            backspace.create_reservation(reservation['numAdherent'], reservation['numTerrain'], reservation['hDebut'], reservation['dateResa'])
        

        print('reservation créée')
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        mytemplate = mylookup.get_template("reservation.html")
        return mytemplate.render(reservations_data=reservations_data)

    ###### Page administration #############      
    @cherrypy.expose
    def administration(self):
        adherents_data = []
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        mytemplate = mylookup.get_template("administration.html")
        return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)
    
    @cherrypy.expose
    def suppression_adherent(self, numAdherent):
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        if backspace.adherent_exists_by_id(numAdherent) == False:
            error = "L'adhérent n'existe pas."
            reservations_data = []
            mytemplate = mylookup.get_template("administration.html")
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        backspace.delete_adherent(numAdherent)
        adherents_data = []
        # Verrification de l'existance de l'adhérent
        
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        mytemplate = mylookup.get_template("administration.html")
        return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)
    
    @cherrypy.expose
    def suppression_reservation(self, numReservation):
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        if backspace.reservation_exists_by_id(numReservation) == False:
            error = "La réservation n'existe pas."
            reservations_data = []
            mytemplate = mylookup.get_template("administration.html")
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        backspace.delete_reservation(numReservation)
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        mytemplate = mylookup.get_template("administration.html")
        return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)
    
    @cherrypy.expose
    def modification_reservation(self, numResa, numAdherent, dateResa, hDebut, hFin, numTerrain):
        reservation = {
            'numResa': int(numResa),
            'numAdherent': int(numAdherent),
            'dateResa': datetime.datetime.strptime(dateResa, '%Y-%m-%d').date(),
            'hDebut': datetime.datetime.strptime(hDebut, '%H:%M').time(),
            'hFin': datetime.datetime.strptime(hFin, '%H:%M').time(),
            'numTerrain': int(numTerrain),
        }
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        if backspace.reservation_exists_by_id(reservation['numResa']) == False:
            error = "La réservation n'existe pas."
            reservations_data = []
            mytemplate = mylookup.get_template("administration.html")
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        elif backspace.adherent_exists_by_id(reservation['numAdherent']) == False:
            error = "L'adhérent n'existe pas."
            reservations_data = []
            mytemplate = mylookup.get_template("administration.html")
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        elif backspace.dateResa_is_today(reservation['dateResa']) == False:
            error = "La date de réservation n'est pas aujourd'hui."
            reservations_data = []
            mytemplate = mylookup.get_template("administration.html")
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        elif backspace.reservation_possible(reservation['numTerrain'], reservation['hDebut']) == False:
            error = "La réservation n'est pas possible."
            reservations_data = []
            mytemplate = mylookup.get_template("administration.html")
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        else:
            backspace.update_reservation(reservation['numAdherent'], reservation['numTerrain'], reservation['hDebut'], reservation['hFin'], reservation['dateResa'], reservation['numResa'])
            reservations_data = []
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
            mytemplate = mylookup.get_template("administration.html")
            return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)
        
    @cherrypy.expose
    def modification_adherent(self, numAdherent, prenom, nom, dateNaissance, tel, typeAdhesion, datePaiement, classement):
        adherent = {
            'numAdherent': int(numAdherent),
            'prenom': prenom,
            'nom': nom,
            'dateNaissance': datetime.datetime.strptime(dateNaissance, '%Y-%m-%d').date(),
            'tel': tel,
            'typeAdhesion': typeAdhesion,
            'datePaiement': datetime.datetime.strptime(datePaiement, '%Y-%m-%d').date(),
            'classement': classement,
        }
        if adherent['classement'] == '':
            adherent['classement'] = None
        else :
            adherent['classement'] = int(adherent['classement'])
        print(f"la valeur est !!!!! : _{adherent['classement']}_")
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        if backspace.adherent_exists_by_id(adherent['numAdherent']) == False:
            error = "L'adhérent n'existe pas."
            adherents_data = []
            mytemplate = mylookup.get_template("administration.html")
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        else:
            backspace.update_adherent(adherent['prenom'], adherent['nom'], adherent['dateNaissance'], adherent['tel'], adherent['typeAdhesion'], adherent['datePaiement'], adherent['numAdherent'], adherent['classement'])
            adherents_data = []
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            mytemplate = mylookup.get_template("administration.html")
            return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)

    @cherrypy.expose
    def ajouter_terrain(self, numTerrain):
        terrain = {
            'numTerrain': int(numTerrain),
        }
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        if backspace.terrain_exists_by_id(terrain['numTerrain']) == True:
            error = "Le terrain existe déjà."
            terrains_data = []
            mytemplate = mylookup.get_template("administration.html")
            terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        else:
            backspace.create_terrain(terrain['numTerrain'])
            terrains_data = []
            terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            mytemplate = mylookup.get_template("administration.html")
            return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)

    @cherrypy.expose
    def reglement(self):
        mytemplate = mylookup.get_template("reglebadminton.html")
        return mytemplate.render()
    
    @cherrypy.expose
    def search_adherent_by_number(self, numAdherent):
        adherent = {
            'numAdherent': int(numAdherent),
        }
        adherents_data = []
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        if backspace.adherent_exists_by_id(adherent['numAdherent']) == False:
            error = "L'adhérent n'existe pas."
            adherents_data = []
            mytemplate = mylookup.get_template("administration.html")
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        else:
            adherents_data = []
            adherents_data=afficheur.afficher_adherent(backspace.search_adherent_by_id(adherent['numAdherent']))
            mytemplate = mylookup.get_template("administration.html")
            return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)
    
    @cherrypy.expose
    def search_reservation_by_number(self, numReservation):
        reservation = {
            'numReservation': int(numReservation),
        }
        adherents_data = []
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        if backspace.reservation_exists_by_id(reservation['numReservation']) == False:
            error = "La réservation n'existe pas."
            reservations_data = []
            mytemplate = mylookup.get_template("administration.html")
            reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        else:
            reservations_data = []
            reservations_data=afficheur.afficher_reservation(backspace.search_reservation_by_id(reservation['numReservation']))
            mytemplate = mylookup.get_template("administration.html")
            return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)
    
    @cherrypy.expose
    def search_adherent(self, prenom, nom):
        adherent = {
            'nom': nom,
            'prenom': prenom,
        }
        adherents_data = []
        adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
        terrains_data = []
        terrains_data=afficheur.afficher_terrain(backspace.get_terrains())
        reservations_data = []
        reservations_data=afficheur.afficher_reservation(backspace.get_reservations())
        if backspace.adherent_exists_by_name(adherent['nom'], adherent['prenom']) == False:
            error = "L'adhérent n'existe pas."
            adherents_data = []
            mytemplate = mylookup.get_template("adherents.html")
            adherents_data=afficheur.afficher_adherent(backspace.get_adherents())
            return mytemplate.render(adherents_data=adherents_data, error=error, reservations_data=reservations_data, terrains_data=terrains_data)
        else:
            adherents_data = []
            adherents_data=afficheur.afficher_adherent(backspace.search_adherent_by_name(adherent['nom'], adherent['prenom']))
            mytemplate = mylookup.get_template("adherents.html")
            return mytemplate.render(adherents_data=adherents_data, reservations_data=reservations_data, terrains_data=terrains_data)
    
    @cherrypy.expose
    def afficher_seulement_colonnes(self, **kwargs):
        numAdherent = kwargs.get('numAdherent')
        prenom = kwargs.get('prenom')
        nom = kwargs.get('nom')
        dateNaissance = kwargs.get('dateNaissance')
        typeAdhesion = kwargs.get('typeAdhesion')
        tel = kwargs.get('tel')
        classement = kwargs.get('classement')
        datePaiement = kwargs.get('datePaiement')

        colonnes = []
        if numAdherent == 'on':
            colonnes.append('numAdherent')
        if prenom == 'on':
            colonnes.append('prenom')
        if nom == 'on':
            colonnes.append('nom')
        if dateNaissance == 'on':
            colonnes.append('dateNaissance')
        if typeAdhesion == 'on':
            colonnes.append('typeAdhesion')
        if tel == 'on':
            colonnes.append('tel')
        if classement == 'on':
            colonnes.append('classement')
        if datePaiement == 'on':
            colonnes.append('datePaiement')

        adherents_data=afficheur.afficher_adherent2(backspace.get_adherents_colonne(colonnes))
        mytemplate = mylookup.get_template("adherents.html")
        return mytemplate.render(adherents_data=adherents_data)

        
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    

    
    









    

    
    

if __name__ == '__main__':
    rootPath = os.path.abspath(os.getcwd())
    print(f"la racine du site est :\n\t{rootPath}\n\tcontient : {os.listdir()}")
    conf = {
        '/': {
            'tools.staticdir.root': rootPath,
        },
        '/img': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './img'
        },
        '/css': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './css'
        },
        '/fonction': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './fonction'
        },
    }
    print("data base generating ...")
    connect()
    # Choix du chargement du jeu d'essai
    questions_niv0_utltime = [
            inquirer.List('choix_jeu_essai',
                            message="Choisissez une option",
                            choices=['Injecter le jeu d essai', 'Autre', 'EXIT'],
                            carousel=False)                   
        ]
    answers = inquirer.prompt(questions_niv0_utltime)
    choix_jeu_essai = answers['choix_jeu_essai']
    if choix_jeu_essai == 'Injecter le jeu d essai':
        generate_data()
        cherrypy.quickstart(InterfaceWebbadminton(), '/', config=conf)
    elif choix_jeu_essai == 'Autre':
        print("pas encore implémenté")
        cherrypy.quickstart(InterfaceWebbadminton(), '/', config=conf)
    elif choix_jeu_essai == 'EXIT':
        exit()



cherrypy.config.update({'engine.autoreload.on': False})
cherrypy.server.unsubscribe()
cherrypy.engine.start()

wsgiapp = cherrypy.tree.mount(InterfaceWebbadminton(),'/club_badminton')