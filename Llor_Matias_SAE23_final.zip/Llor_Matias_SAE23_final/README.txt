commande pour tuer le processus qui occupe le prot 8080:
(sous linux) : 
lsof -i :8080 
kill PID

sous Windows :
netstat -ano | findstr :8080
taskkill /PID PID


dans le fichier config.txt mettre le mdp et le user de votre sql

pour lancer le serveur :
lancer le fichier main.py depuis le terminal ouvert dans le dossier Llor_Matias_SAE23_final
python3 main.py
choix d'implementer ou non le fichier .csv dans la base de donnée


il n'y a pas de fonction pour supprimer un terrain car cette table est liée à la table réservation 
le classement est fait manuellement par l'admin