import csv
import pymysql

def connect():
    # Lecture du fichier de configuration 
    config = {}
    with open('config.txt', 'r') as file:
        for line in file:
            key, value = line.strip().split(':')
            config[key] = value

    # Connexion à la base de données
    cnx = pymysql.connect(
        host=config['host'],
        user=config['user'],
        password=config['password'],
    )

    cursor = cnx.cursor(pymysql.cursors.DictCursor)

    # Création de la base de données, verifaction si elle existe déjà et suppression si elle existe
    database_name = config['database']
    drop_database_query = f'DROP DATABASE IF EXISTS {database_name};'
    create_database_query = f'CREATE DATABASE IF NOT EXISTS {database_name};'
    cursor.execute(drop_database_query)
    cursor.execute(create_database_query)

    # Exécution des requêtes SQL à partir du fichier database.txt
    with open('database.txt', 'r') as file:
        queries = file.read().split(';')

    for query in queries:
        query = query.strip()
        if query:
            cursor.execute(query)

    # Fermeture du curseur
    cursor.close()


    # Fermeture de la connexion
    cnx.commit()
    cnx.close()



def generate_data():
    # Lecture du fichier de configuration
    config = {}
    with open('config.txt', 'r') as file:
        for line in file:
            key, value = line.strip().split(':')
            config[key] = value
    
    # Connexion à la base de données
    cnx = pymysql.connect(
        host=config['host'],
        user=config['user'],
        password=config['password'],
        database=config['database']
    )
    
    # Créer un curseur
    cursor = cnx.cursor(pymysql.cursors.DictCursor)


    # Ouvrir le fichier CSV et lire son contenu
    with open('essaie.csv', 'r') as fichier:
        lecteur_csv = csv.reader(fichier, delimiter=",")

        # Parcourir chaque ligne du fichier CSV
        for ligne in lecteur_csv:

            # Vérifier si la ligne est vide
            if not ligne:
                continue

            # Vérifier si la ligne contient les entêtes
            if ligne[0] == 'entetes':
                continue
            
            # Récupérer le nom de la table (première valeur de la ligne)
            table = ligne[0]

            # Vérifier la table correspondante et effectuer l'insertion en conséquence
            if table == 'adherents':
                # Construction de la requête d'insertion pour la table "adherents"
                query = "INSERT INTO adherents (numAdherent, prenom, nom, dateNaissance, tel, typeAdhesion, classement, datePaiement) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                numAdherent, prenom, nom, dateNaissance, tel, typeAdhesion, classement, datePaiement = ligne[1:]
                if classement == '':
                    classement = None
                valeurs = (numAdherent, prenom, nom, dateNaissance, tel, typeAdhesion, classement, datePaiement)
                cursor.execute(query, valeurs)
            elif table == 'reservations':
                # Construction de la requête d'insertion pour la table "reservations"
                query = "INSERT INTO reservations (numResa, hDebut, hFin, numTerrain, numAdherent, dateResa) VALUES (%s, %s, %s, %s, %s, %s)"
                numResa, hDebut, hFin, numTerrain, numAdherent, dateResa = ligne[1:]
                valeurs = (numResa, hDebut, hFin, numTerrain, numAdherent, dateResa)
                cursor.execute(query, valeurs)
            elif table == 'terrains':
                # Construction de la requête d'insertion pour la table "terrains"
                query = "INSERT INTO terrains (numTerrain) VALUES (%s)"
                valeur = (ligne[1],)
                cursor.execute(query, valeur)

    # Valider les modifications et fermer la connexion à la base de données
    cursor.close()
    cnx.commit()
    cnx.close()


