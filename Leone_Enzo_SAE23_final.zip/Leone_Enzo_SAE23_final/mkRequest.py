# les fonctions suivantes permettent de créer des requêtes "SQL" avec des valeurs variables

_requetes = {
    "drop" : "DROP DATABASE IF EXISTS montre",
    "createBase" : "CREATE DATABASE IF NOT EXISTS montre DEFAULT CHARACTER SET utf8",
    "use" : "USE montre",
    "createTable_connexion" : "CREATE TABLE IF NOT EXISTS `connexion` (`mail` varchar(100) NOT NULL,\
  `nom` varchar(25) NOT NULL,\
  `prenom` varchar(20) NOT NULL,\
  `login` varchar(30) NOT NULL,\
  `mdp` varchar(20) NOT NULL,\
  `connexion` tinyint NOT NULL DEFAULT '0',\
  PRIMARY KEY (`mail`)\
) ENGINE=InnoDB;",
    "createTable_prix_enchere" : "CREATE TABLE IF NOT EXISTS `prix_enchere` (`id_connexion` varchar(100) NOT NULL,\
  `id_produits` int NOT NULL,\
  `prix_base` float NOT NULL,\
  `prix_final` float DEFAULT NULL,\
  PRIMARY KEY (`id_connexion`,`id_produits`),\
  KEY `encherir_sur` (`id_connexion`),\
  KEY `acheter_par` (`id_produits`)\
) ENGINE=InnoDB;",
    "createTable_dedans" : "CREATE TABLE IF NOT EXISTS `dedans` (`id_produit` int NOT NULL,\
  `id_lieu` int NOT NULL,\
  `prix` float NOT NULL,\
  `date` DATE NOT NULL,\
  PRIMARY KEY (`id_produit`,`id_lieu`),\
  KEY `proposer_a` (`id_produit`),\
  KEY `etre_dans` (`id_lieu`)\
) ENGINE=InnoDB;",
    "createTable_lieux" : "CREATE TABLE IF NOT EXISTS `lieux` (`id` int NOT NULL AUTO_INCREMENT,\
  `url` varchar(100) DEFAULT NULL,\
  PRIMARY KEY (`id`)\
) ENGINE=InnoDB;",
    "createTable_produits" :"CREATE TABLE IF NOT EXISTS `produits` (`id` int NOT NULL AUTO_INCREMENT,\
  `nom` varchar(50) NOT NULL,\
  `description` text NOT NULL,\
  `fabricant` text NOT NULL,\
  `mouvement` enum('automatique','manuel','quartz') NOT NULL,\
  `enchere` tinyint(1) NOT NULL,\
  PRIMARY KEY (`id`)\
) ENGINE=InnoDB;",
"contrainte" : "ALTER TABLE `dedans`\
  ADD CONSTRAINT `proposer_a` FOREIGN KEY (`id_produit`) REFERENCES `produits` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,\
  ADD CONSTRAINT `etre_dans` FOREIGN KEY (`id_lieu`) REFERENCES `lieux` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;",
  "contrainte2":"ALTER TABLE `prix_enchere`\
  ADD CONSTRAINT `encherir_sur` FOREIGN KEY (`id_connexion`) REFERENCES `connexion` (`mail`) ON DELETE CASCADE ON UPDATE RESTRICT,\
  ADD CONSTRAINT `acheter_par` FOREIGN KEY (`id_produits`) REFERENCES `produits` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;",
    "userdefault" : "insert into connexion(mail,nom,prenom,login,mdp,connexion) values ('root', 'root', 'root', 'root', 'root', '1'),('mailtest', 'nomtest', 'prenomtest', 'logintest', 'mdptest', '1');",
    "getTable_produits" : "select * from produits order by fabricant;",
    "getTable_lieux" : "select * from lieux order by id;",
    "getTable_prix" : "select * from dedans;",
    "getTable_User" : "select * from connexion",
    "getTable_enchere" : "select * from prix_enchere",
    "getAll" : "select p.id, p.nom, l.url, d.prix, d.date from dedans d join lieux l on d.id_lieu = l.id join produits p on d.id_produit=p.id;",
    "getAllByPrice" : "select p.nom, l.url, d.prix from dedans d join lieux l on d.id_lieu = l.id join produits p on d.id_produit=p.id where d.prix < {};",
    "getProduitby" : "select * from produit where {} = {};",
    "insert_produit" : "insert into produits (nom,description,fabricant,mouvement,enchere) values ('{}','{}','{}','{}','{}');",
    "insert_lieux" : "insert into lieux (url) values ('{}');",
    "insert_prix" : "insert into dedans (id_produit, id_lieu, prix, date) values ('{}','{}','{}','{}');",
    "insert_enchere" : "insert into prix_enchere (id_connexion, id_produits, prix_base, prix_final) values ('{}', '{}', '{}', '{}');",
    "create_user" : "insert into connexion (mail, nom, prenom, login, mdp, connexion) values ('{}','{}','{}','{}','{}','{}');",
    "mettre_aux_encheres" : "update produits set enchere = {} where id = {};",
    "prix_enchere" : "insert into prix_enchere (id_connexion, id_produits, prix_base, prix_final) values ('root', '{}', '{}', '{}');",
    "delete_ligne_prix_enchere" : "delete from prix_enchere where id_produits = {}",
    "proposer_prix" : "update prix_enchere set id_connexion = {}, prix_final = {} where id_produits = {}",
    "delete_produit_by_id" : "delete from produits where id = {};",
    "delete_prix" : "delete from dedans where id_produit = {} and id_lieu = {}",
    "reset_produits" : "drop table produits;",
    "reset_lieux" : "drop table lieux;",
    "reset_dedans" : "drop table dedans;",
    "reset_prix_enchere" :"drop table prix_enchere;",
    "reset_connexion" :"drop table connexion;",
    "reset_increment_produits" : "ALTER TABLE produits AUTO_INCREMENT = 1;",
    "reset_increment_lieu" : "ALTER TABLE lieux AUTO_INCREMENT = 1;",
    "get_prix_enchere" : "select e.id_connexion, p.id, p.nom, e.prix_base, e.prix_final from produits p join prix_enchere e on p.id = e.id_produits",
    "update_enchere" : "update prix_enchere set id_connexion = '{}', prix_final= prix_final + {} where id_produits = {};"
    }

def mkInsert_Produit_Request(id, nom, description, fabricant, mouvement, enchere) :
    s= _requetes["insert_produit"].format(id, nom ,description, fabricant, mouvement, enchere)
    return s

def mkInsert_Lieu_Request(id, url) :
    s= _requetes["insert_lieux"].format(id, url)
    return s

def mkInsert_Prix_Request(id_produit, id_lieu, prix) :
    s= _requetes["insert_produit"].format(id_produit , id_lieu, prix )
    return s
    
def mkDelete_Produit_Request(id) :
    s= _requetes["delete_produit_by_id"].format(id)
    return s

def mkDelete_Prix_Request(id_produit, id_lieu) :
    s= _requetes["delete_prix"].format(id_produit, id_lieu)
    return s

def mkGetAllbyPrice(prix) :
    s= _requetes["getAllByPrice"].format(prix)
    return s

def mkGetProduitBy(colonne, valeur) :
    s= _requetes["getProduitby"].format(colonne, valeur)
    return s

def create_user(mail, nom, prenom, login, mdp, connexion):
    s= _requetes["create_user"].format(mail, nom, prenom, login, mdp, connexion)
    return s

def mettre_aux_encheres(id, prix_base, prix_final):
    s = _requetes["mettre_aux_encheres"].format(id, id, prix_base, prix_final)
    return s

def proposer_prix(id_connexion, prix_final, id_produits):
    s = _requetes["proposer_prix"].format(id_connexion, prix_final, id_produits)
    return s


#select p.id, p.nom, l.url, d.prix, d.date from dedans d join lieux l on d.id_lieu = l.id join produits p on d.id_produit=p.id where mouvement="manuel";