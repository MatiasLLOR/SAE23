# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686084638.1363907
_enable_loop = True
_template_filename = 'res/templates/detail.html'
_template_uri = 'detail.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        mail = context.get('mail', UNDEFINED)
        nb = context.get('nb', UNDEFINED)
        int = context.get('int', UNDEFINED)
        lieux_prix = context.get('lieux_prix', UNDEFINED)
        str = context.get('str', UNDEFINED)
        len = context.get('len', UNDEFINED)
        enchere = context.get('enchere', UNDEFINED)
        produit = context.get('produit', UNDEFINED)
        range = context.get('range', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<body>\r\n\r\n    <!-- Navbar Start -->\r\n    <div class="container-fluid bg-dark mb-30">\r\n        <div class="row px-xl-5">\r\n            <div class="col-lg-3 d-none d-lg-block">\r\n                <a class="btn d-flex align-items-center justify-content-between bg-primary w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; padding: 0 30px;">\r\n                    <h6 class="text-dark m-0">WatchAuction : ')
        __M_writer(str(mail))
        __M_writer('</h6>\r\n                </a>\r\n            </div>\r\n            <div class="col-lg-9">\r\n                <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0">\r\n                    <a href="" class="text-decoration-none d-block d-lg-none">\r\n                        <span class="h1 text-uppercase text-dark bg-light px-2">Watch</span>\r\n                        <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Shop</span>\r\n                    </a>\r\n                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">\r\n                        <span class="navbar-toggler-icon"></span>\r\n                    </button>\r\n                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">\r\n                        <div class="navbar-nav mr-auto py-0">\r\n                            <a href="/" class="nav-item nav-link">Shop</a>\r\n')
        if mail == None:
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Mon compte <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <a href="connection" class="dropdown-item">Se connecter</a>\r\n                                        <a href="insertPage" class="dropdown-item">Créer un compte</a>\r\n                                    </div>\r\n                                </div>\r\n')
        if mail == "root" :
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Administration <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <a href="insert_Page_data" class="dropdown-item">Insérer des données</a>\r\n                                        <a href="DeleteProduit" class="dropdown-item">Supprimer des données</a>\r\n                                        <a href="UpdateProduit" class="dropdown-item">Mettre à jour des données</a>\r\n                                        <form action="Export">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Exporter la base</button>\r\n                                        </form>\r\n                                        <form action="Import">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Importer la base</button>\r\n                                        </form>\r\n                                    </div>\r\n                                </div>\r\n')
        if mail != None :
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Mon compte <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <form action="Deconnexion">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Déconnexion</button>\r\n                                        </form>\r\n                                    </div>\r\n                                </div>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                </nav>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <!-- Navbar End -->\r\n\r\n    <!-- Shop Detail Start -->\r\n    <div class="container-fluid pb-5">\r\n        <div class="row px-xl-5">\r\n            <div class="col-lg-5 mb-30">\r\n                <div id="product-carousel" class="carousel slide">\r\n                    <div class="carousel-inner bg-light">\r\n                        <div class="carousel-item active">\r\n')
        from os import listdir
        listefichier=listdir("res/img/")
        retour=0
        for index in range(len(produit)):
            if produit[index][0] == int(nb):
                for elem in listefichier:
                    if str(produit[index][1]) in elem:
                        retour = str(produit[index][1])
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['listefichier','index','elem','retour','listdir'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n                            <img class="w-100 h-100" src="/static/img/')
        __M_writer(str(retour))
        __M_writer('.png" alt="Image">\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class="col-lg-7 h-auto mb-30">\r\n                <div class="h-100 bg-light p-30">\r\n')
        for index in range(len(produit)):
            if produit[index][0] == int(nb):
                __M_writer('                            <h3 class="font-weight-semi-bold mb-4">')
                __M_writer(str(produit[index][1]))
                __M_writer('</h3>\r\n                            <h6 class="font-weight-semi-bold mb-4">Information relative au produit : </h6>\r\n                            <ul class="mb-4">Fabricant : ')
                __M_writer(str(produit[index][3]))
                __M_writer('</ul>\r\n                            <ul class="mb-4">Mouvement : ')
                __M_writer(str(produit[index][4]))
                __M_writer('</ul>\r\n                            <h6 class="font-weight-semi-bold mb-4">Description : </h6>\r\n                            <p class="mb-4">')
                __M_writer(str(produit[index][2]))
                __M_writer('</p>\r\n                            <h6 class="font-weight-semi-bold mb-4">Prix recensé sur différents sites web à la date indiquée : </h6>\r\n')
                for index2 in range(len(lieux_prix)):
                    if produit[index][0] == lieux_prix[index2][0]:
                        __M_writer('                                    <ul class="mb-4">Sur le site web : ')
                        __M_writer(str(lieux_prix[index2][2]))
                        __M_writer(' cette montre est proposée à ')
                        __M_writer(str(lieux_prix[index2][3]))
                        __M_writer('€ à la date du ')
                        __M_writer(str(lieux_prix[index2][4]))
                        __M_writer('. </ul>\r\n')
                __M_writer('                            <h6 class="font-weight-semi-bold mb-4">Enchère : </h6>\r\n')
                if produit[index][5] == 1 and mail !=None:
                    for index3 in range (len(enchere)):
                        if enchere[index3][1]== produit[index][0]:
                            __M_writer('                                    <p class="mb-4">Cette montre a pour prix de base : ')
                            __M_writer(str(enchere[index3][3]))
                            __M_writer('€</p>\r\n')
                            for index4 in range (len(enchere)):
                                if int(enchere[index4][1]) == nb:
                                    __M_writer('                                            <p class="mb-4">Cette montre a pour prix actuel : ')
                                    __M_writer(str(enchere[index3][4]))
                                    __M_writer('€, c\'est : "')
                                    __M_writer(str(enchere[index4][0]))
                                    __M_writer('"" le dernier à avoir enchéri</p>\r\n')
                            __M_writer('                                    <form action="auction">\r\n                                            <div class="col-md-6 form-group">\r\n                                                <input class="form-control" type="text" placeholder="Mettre de combien vous enchérissez ici" id="auction" name="auction" required>\r\n                                            </div>\r\n                                            <div class="col-md-6 form-group" style="display: none;">\r\n                                                <input class="form-control" type="text" id="id_produit" name="id_produit" value="')
                            __M_writer(str(nb))
                            __M_writer('">\r\n                                            </div>\r\n                                        <button type="submit" class="btn btn-primary px-3" name="id_connexion" value="')
                            __M_writer(str(mail))
                            __M_writer('">Enchérir</button>\r\n                                    </form>\r\n')
                elif mail == None:
                    __M_writer('                                <p class="mb-4">Vous devez vous connecter pour participer aux enchères</p>\r\n')
                else :
                    __M_writer('                                <p class="mb-4">Cette montre n\'est pas proposée aux enchères pour le moment.</p>\r\n')
        __M_writer('                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <!-- Shop Detail End -->\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/detail.html", "uri": "detail.html", "source_encoding": "utf-8", "line_map": {"27": 0, "41": 1, "42": 9, "43": 9, "44": 24, "45": 25, "46": 33, "47": 34, "48": 49, "49": 50, "50": 59, "51": 74, "52": 75, "53": 76, "54": 77, "55": 78, "56": 79, "57": 80, "58": 81, "59": 82, "60": 83, "63": 82, "64": 83, "65": 83, "66": 90, "67": 91, "68": 92, "69": 92, "70": 92, "71": 94, "72": 94, "73": 95, "74": 95, "75": 97, "76": 97, "77": 99, "78": 100, "79": 101, "80": 101, "81": 101, "82": 101, "83": 101, "84": 101, "85": 101, "86": 104, "87": 105, "88": 106, "89": 107, "90": 108, "91": 108, "92": 108, "93": 109, "94": 110, "95": 111, "96": 111, "97": 111, "98": 111, "99": 111, "100": 114, "101": 119, "102": 119, "103": 121, "104": 121, "105": 125, "106": 126, "107": 127, "108": 128, "109": 132, "115": 109}}
__M_END_METADATA
"""
