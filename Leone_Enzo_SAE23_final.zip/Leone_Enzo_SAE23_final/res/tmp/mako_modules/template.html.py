# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686084586.5890818
_enable_loop = True
_template_filename = 'res/templates/template.html'
_template_uri = 'template.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        self = context.get('self', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html lang="en">\r\n\r\n<head>\r\n    <meta charset="utf-8">\r\n    <title>WatchAuction</title>\r\n    <meta content="width=device-width, initial-scale=1.0" name="viewport">\r\n    <meta content="Free HTML Templates" name="keywords">\r\n    <meta content="Free HTML Templates" name="description">\r\n\r\n    <!-- Favicon -->\r\n    <link href="/static/favicon/favicon.ico" rel="icon">\r\n\r\n    <!-- Google Web Fonts -->\r\n    <link rel="preconnect" href="https://fonts.gstatic.com">\r\n    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  \r\n\r\n    <!-- Font Awesome -->\r\n    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">\r\n\r\n    <!-- Libraries Stylesheet -->\r\n    <link href="/static/lib/animate/animate.min.css" rel="stylesheet">\r\n    <link href="/static/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">\r\n\r\n    <!-- Customized Bootstrap Stylesheet -->\r\n    <link href="/static/css/style.css" rel="stylesheet">\r\n\r\n</head>\r\n<body>\r\n\r\n')
        __M_writer(str( self.body() ))
        __M_writer('\r\n\r\n    <!-- Back to Top -->\r\n    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>\r\n\r\n\r\n    <!-- JavaScript Libraries -->\r\n    <script src="/static/js/jquery.js"></script>\r\n    <script src="/static/js/bootstrap.js"></script>\r\n    <script src="/static/lib/easing/easing.min.js"></script>\r\n    <script src="/static/lib/owlcarousel/owl.carousel.min.js"></script>\r\n\r\n    <!-- Contact Javascript File \r\n    <script src="/static/mail/jqBootstrapValidation.min.js"></script>\r\n    <script src="/static/mail/contact.js"></script>-->\r\n\r\n    <!-- Template Javascript -->\r\n    <script src="/static/js/main.js"></script>\r\n\r\n    <!-- Filters Javascript -->\r\n    <script src="/static/js/filters.js"></script>\r\n</body>\r\n\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/template.html", "uri": "template.html", "source_encoding": "utf-8", "line_map": {"16": 0, "22": 1, "23": 31, "24": 31, "30": 24}}
__M_END_METADATA
"""
