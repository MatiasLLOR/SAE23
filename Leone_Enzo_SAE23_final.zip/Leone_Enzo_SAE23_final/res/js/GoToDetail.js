var idProduit = str(None)
function redirectToDetail(idProduit) {
    window.location.href = `/static/templates/detail.html?id=${idProduit}`;
}

