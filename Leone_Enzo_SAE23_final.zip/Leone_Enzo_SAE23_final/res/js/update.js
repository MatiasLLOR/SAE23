document.addEventListener("DOMContentLoaded", function() {
    var yesRadio = document.getElementById("yes");
    var noRadio = document.getElementById("no");
    var priceInput = document.getElementById("priceInput");
  
    yesRadio.addEventListener("change", function() {
      if (this.checked) {
        priceInput.style.display = "block";
      }
    });

    noRadio.addEventListener("change", function() {
      if (this.checked) {
        priceInput.style.display = "none";
      }
    })
  });
  