# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686087446.946188
_enable_loop = True
_template_filename = 'html/calendrier.html'
_template_uri = 'calendrier.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        rencontres = context.get('rencontres', UNDEFINED)
        equipes = context.get('equipes', UNDEFINED)
        str = context.get('str', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n\t<title>Effectif - RC Toulon</title>\r\n\t<link rel="stylesheet" type="text/css" href="/css/calendrier.css">\r\n\t<link rel="stylesheet" href="/css/icone.css">\r\n\t<script src="/js/alpine.js" defer></script>\r\n</head>\r\n<body>\r\n\t<header>\r\n\t\t<nav>\r\n\t\t\t<ul>\r\n\t\t\t\t<li><a href="regles">Règles</a></li>\r\n\t\t\t\t<li><a href="index">Effectif</a></li>\r\n\t\t\t\t<li><a href="calendar">Calendrier</a></li>\r\n\t\t\t\t<li><a href="classement">Classement</a></li>\r\n\t\t\t</ul>\r\n\t\t</nav>\r\n\t</header>\r\n\t<main>\r\n\t\t<navig>\r\n\t\t\t<h1>CALENDRIER</h1>\r\n\t\t</navig>\r\n\t\t<div id="ChoixTri">\r\n            <a href="calendar">PLUS ANCIEN</a>\r\n            <a href="calendar_inverse">PLUS RECENT</a>\r\n\t\t\t<a href="calendar_venir">A VENIR</a>\r\n\t\t\t<a href="calendar_passer">PASSER</a>\r\n        </div>\r\n\t\t<div id="div_ajouter">\r\n\t\t\t<h1>Calendrier des matchs</h1>\r\n\t\t\t<div>\r\n\t\t\t\t<button class="ajouter" onclick="open_popup_add(this)">Ajouter</button>\r\n\t\t\t\t<button class="supprimer" onclick="open_popup_suppr(this)"></i> Supprimer</button>\r\n\t\t\t\t<button class="modifier" onclick="open_popup_modif(this)"></i> Modifier</button>\r\n\t\t\t</div>\r\n\t\t</div>\r\n        <table>\r\n          <tr>\r\n            <th>Date et heure</th>\r\n            <th>Équipe dom.</th>\r\n            <th>Score</th>\r\n            <th>Équipe ext.</th>\r\n            <th>Fiche</th>\r\n          </tr>\r\n          <tr>\r\n            <td><hr></td>\r\n            <td><hr></td>\r\n            <td><hr></td>\r\n            <td><hr></td>\r\n            <td><hr></td>\r\n          </tr>\r\n          ')
        from datetime import datetime 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['datetime'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n')
        for rencontre in rencontres:
            __M_writer('          <tr>\r\n            <td>')
            __M_writer(str(str(datetime.strptime(rencontre.date, "%Y-%m-%d").strftime("%d/%m/%Y"))))
            __M_writer('</td>\r\n            <td class="equipe_nom"><img class="equipe_img" src="')
            __M_writer(str(rencontre.logo_suivi[1:-1]))
            __M_writer('" width="36", height="36"> ')
            __M_writer(str(rencontre.equipe_nom_suivi[1:-1]))
            __M_writer('</td>\r\n            <td>')
            __M_writer(str(rencontre.score_suivi))
            __M_writer(' - ')
            __M_writer(str(rencontre.score_adverse))
            __M_writer('</td>\r\n            <td class="equipe_nom"><img class="equipe_img" src="')
            __M_writer(str(rencontre.logo_adverse[1:-1]))
            __M_writer('" width="36" height="36"> ')
            __M_writer(str(rencontre.equipe_nom_adverse[1:-1]))
            __M_writer('</td>\r\n\t\t\t\r\n            <td>\r\n\t\t\t\t<form id="form-')
            __M_writer(str(rencontre.id))
            __M_writer('" action="/fiche" method="get" style="display: none;">\r\n\t\t\t\t\t<input type="hidden" name="id" value="')
            __M_writer(str(rencontre.id))
            __M_writer('">\r\n\t\t\t\t</form>\r\n\t\t\t\t<a href="#" onclick="event.preventDefault(); document.getElementById(\'form-')
            __M_writer(str(rencontre.id))
            __M_writer('\').submit();">Fiche match</a>\r\n\t\t\t</td>\r\n          </tr>\r\n')
        __M_writer('        </table>\r\n\t</main>\r\n\t<footer>\r\n\t\t<nav>\r\n\t\t\t<ul>\r\n\t\t\t\t<li><img src="/image/footer/nike.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/hyundai.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/spvie.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/interim.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/CA.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/yack.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/pizzorno.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/uniti.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/toulon.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/tpm.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/var.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/PACA.png" height="120", width="100"></li>\r\n\t\t\t</ul>\r\n\t\t<p>© 2023 - Ruellan Théo</p>\r\n\t\t</nav>\r\n\t</footer>\r\n\r\n\t<div id="popup_add" class="popup">\r\n        <div class="popup-content">\r\n            <span class="close" onclick="close_popup_add()">&times;</span>\r\n            <div>\r\n                <form id="form-add" action="/add_rencontre" method="GET">\r\n                    <div class="input-row">\r\n\t\t\t\t\t\t<label for="date">Date</label>\r\n\t\t\t\t\t\t<input class="form-input" type="date" id="date" name="date" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="dom_bool">Équipe Rugby Club Toulonnais à domicile ? </label>\r\n\t\t\t\t\t\t<input class="form-input" type="checkbox" id="dom_bool" name="dom_bool" value="1" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="equipe_adv">Équipe adverse</label>\r\n\t\t\t\t\t\t<select class="form-input" id="equipe_adv" name="equipe_adv" required>\r\n')
        for equipe in equipes:
            if 'Toulon' not in equipe.ville:
                __M_writer('\t\t\t\t\t\t\t\t<option value="')
                __M_writer(str(equipe.id))
                __M_writer('">')
                __M_writer(str(equipe.nom[1:-1]))
                __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="score_dom">Score Rugby Club Toulonnais</label>\r\n\t\t\t\t\t\t<input class="form-input" type="number" id="score_dom" name="score_dom" min="0" max="100" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="score_adv">Score équipe adverse</label>\r\n\t\t\t\t\t\t<input class="form-input" type="number" id="score_adv" name="score_adv" min="0" max="100" required>\r\n\t\t\t\t\t</div>\r\n                </form>\r\n            </div>\r\n            <button class="supprimer" onclick="close_popup_add()">Annuler</button>\r\n            <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-add\').submit();">Valider</button>\r\n        </div>\r\n    </div>\r\n\r\n\t<div id="popup_suppr" class="popup">\r\n\t\t<div class="popup-content">\r\n\t\t\t<span class="close" onclick="close_popup_suppr()">&times;</span>\r\n\t\t\t<div>\r\n\t\t\t\t<form id="form-suppr" action="/suppr_rencontre" method="GET">\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="id">Équipe adverse</label>\r\n\t\t\t\t\t\t<select class="form-input" id="id" name="id" required>\r\n')
        for rencontre in rencontres:
            __M_writer('\t\t\t\t\t\t\t<option value="')
            __M_writer(str(rencontre.id))
            __M_writer('">')
            __M_writer(str(rencontre.equipe_nom_suivi[1:-1]))
            __M_writer(' VS ')
            __M_writer(str(rencontre.equipe_nom_adverse[1:-1]))
            __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t\t<button class="supprimer" onclick="close_popup_suppr()">Annuler</button>\r\n\t\t\t<button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-suppr\').submit();">Valider</i></button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div id="popup_modif" class="popup">\r\n\t\t<div class="popup-content">\r\n\t\t\t<span class="close" onclick="close_popup_modif()">&times;</span>\r\n\t\t\t<div>\r\n\t\t\t\t<form id="form-modif" action="/modif_rencontre" method="GET">\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="id">Match à modifier</label>\r\n\t\t\t\t\t\t<select class="form-input" id="id" name="id" required>\r\n')
        for rencontre in rencontres:
            __M_writer('\t\t\t\t\t\t\t<option value="')
            __M_writer(str(rencontre.id))
            __M_writer('">')
            __M_writer(str(rencontre.equipe_nom_suivi[1:-1]))
            __M_writer(' VS ')
            __M_writer(str(rencontre.equipe_nom_adverse[1:-1]))
            __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\r\n\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="date">Date</label>\r\n\t\t\t\t\t\t<input class="form-input" type="date" id="date" name="date" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="dom_bool">Équipe Rugby Club Toulonnais à domicile ? </label>\r\n\t\t\t\t\t\t<input class="form-input" type="checkbox" id="dom_bool" name="dom_bool" value="1" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="equipe_adv">Équipe adverse</label>\r\n\t\t\t\t\t\t<select class="form-input" id="equipe_adv" name="equipe_adv" required>\r\n')
        for equipe in equipes:
            if 'Toulon' not in equipe.ville:
                __M_writer('\t\t\t\t\t\t\t\t<option value="')
                __M_writer(str(equipe.id))
                __M_writer('">')
                __M_writer(str(equipe.nom[1:-1]))
                __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="score_dom">Score Rugby Club Toulonnais</label>\r\n\t\t\t\t\t\t<input class="form-input" type="number" id="score_dom" name="score_dom" min="0" max="100" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="score_adv">Score équipe adverse</label>\r\n\t\t\t\t\t\t<input class="form-input" type="number" id="score_adv" name="score_adv" min="0" max="100" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t\t<button class="supprimer" onclick="close_popup_modif()">Annuler</button>\r\n\t\t\t<button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-modif\').submit();">Valider</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\r\n    <script>\r\n        function close_popup_add() {\r\n            var popup = document.getElementById("popup_add");\r\n            popup.style.display = "none";\r\n        }\r\n\r\n        function open_popup_add(button) {\r\n            var popup = document.getElementById("popup_add");\r\n            popup.style.display = "block";\r\n        }\r\n\r\n\t\tfunction close_popup_modif() {\r\n            var popup = document.getElementById("popup_modif");\r\n            popup.style.display = "none";\r\n        }\r\n\r\n        function open_popup_modif(button) {\r\n            var popup = document.getElementById("popup_modif");\r\n            popup.style.display = "block";\r\n        }\r\n\r\n        function close_popup_suppr() {\r\n            var popup = document.getElementById("popup_suppr");\r\n            popup.style.display = "none";\r\n        }\r\n\r\n        function open_popup_suppr(button) {\r\n            var popup = document.getElementById("popup_suppr");\r\n            popup.style.display = "block";\r\n        }\r\n    </script>\r\n\r\n</body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/calendrier.html", "uri": "calendrier.html", "source_encoding": "utf-8", "line_map": {"16": 0, "24": 1, "25": 53, "26": 54, "29": 53, "30": 54, "31": 55, "32": 56, "33": 56, "34": 57, "35": 57, "36": 57, "37": 57, "38": 58, "39": 58, "40": 58, "41": 58, "42": 59, "43": 59, "44": 59, "45": 59, "46": 62, "47": 62, "48": 63, "49": 63, "50": 65, "51": 65, "52": 69, "53": 107, "54": 108, "55": 109, "56": 109, "57": 109, "58": 109, "59": 109, "60": 112, "61": 137, "62": 138, "63": 138, "64": 138, "65": 138, "66": 138, "67": 138, "68": 138, "69": 140, "70": 157, "71": 158, "72": 158, "73": 158, "74": 158, "75": 158, "76": 158, "77": 158, "78": 160, "79": 175, "80": 176, "81": 177, "82": 177, "83": 177, "84": 177, "85": 177, "86": 180, "92": 86}}
__M_END_METADATA
"""
