# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686094966.6502986
_enable_loop = True
_template_filename = 'html/joueur.html'
_template_uri = 'joueur.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        str = context.get('str', UNDEFINED)
        joueur = context.get('joueur', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n\t<title>Effectif - RC Toulon</title>\r\n\t<link rel="stylesheet" type="text/css" href="/css/joueur.css">\r\n    <script src="/js/alpine.js" defer></script>\r\n    <link rel="stylesheet" href="/css/icone.css">\r\n</head>\r\n<body>\r\n\t<header>\r\n\t\t<nav>\r\n\t\t\t<ul>\r\n\t\t\t\t<li><a href="regles">Règles</a></li>\r\n\t\t\t\t<li><a href="index">Effectif</a></li>\r\n\t\t\t\t<li><a href="calendar">Calendrier</a></li>\r\n                <li><a href="classement">Classement</a></li>\r\n\t\t\t</ul>\r\n\t\t</nav>\r\n\t</header>\r\n    <main>\r\n        <navig>\r\n            <h1>')
        __M_writer(str(joueur.prenom))
        __M_writer(' <br> ')
        __M_writer(str(str(joueur.nom).upper()))
        __M_writer('</h1>\r\n            ')
        from random import randint 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['randint'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n            ')
        nb = randint(1, 15) 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['nb'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n            <img src="/image/maillot/maillot')
        __M_writer(str(nb))
        __M_writer('.png" height="300", width="300">\r\n        </navig>\r\n        <div id="container">\r\n            <div id="image">\r\n                <img src="/')
        __M_writer(str(joueur.photo_url))
        __M_writer('" height="700", width="700">\r\n            </div>\r\n            <div id="joueur">\r\n                <div id="info">\r\n                    ')
        from datetime import datetime 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['datetime'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n                    <div id="blase">\r\n                        <p id="blase_p">')
        __M_writer(str(joueur.prenom))
        __M_writer(' ')
        __M_writer(str(str(joueur.nom).upper()))
        __M_writer('</p>\r\n                        <div>\r\n                            <form id="form-supprimer" action="/supprime_joueur" method="post" style="display: none;">\r\n                                <input type="hidden" name="id" value="')
        __M_writer(str(joueur.id))
        __M_writer('">\r\n                            </form>\r\n                            <button class="modifier" onclick="open_popup_modif(this)" data-id="')
        __M_writer(str(joueur.id))
        __M_writer('" data-nom="')
        __M_writer(str(joueur.nom))
        __M_writer('" data-prenom="')
        __M_writer(str(joueur.prenom))
        __M_writer('" data-age="')
        __M_writer(str(joueur.age))
        __M_writer('" data-poste="')
        __M_writer(str(joueur.poste))
        __M_writer('" data-taille="')
        __M_writer(str(joueur.taille))
        __M_writer('" data-poids="')
        __M_writer(str(joueur.poids))
        __M_writer('" data-date_naissance="')
        __M_writer(str(joueur.date_naissance))
        __M_writer('" data-nationalite="')
        __M_writer(str(joueur.nationalite))
        __M_writer('" data-photo_url="')
        __M_writer(str(joueur.photo_url))
        __M_writer('" data-equipe_id="')
        __M_writer(str(joueur.equipe_id))
        __M_writer('">Modifier</button>\r\n                            <button class="supprimer" onclick="open_popup_suppr(this)">Supprimer</button>\r\n                        </div>\r\n                    </div>\r\n                    <p id="poste_p">')
        __M_writer(str(joueur.poste))
        __M_writer('</p>\r\n                    <div class="div_gauche">\r\n                        <p id="naissance" class="column_gauche">Né le :</p> \r\n                        <p class="column_droite">')
        __M_writer(str(str(datetime.strptime(joueur.date_naissance, "%Y-%m-%d").strftime("%d/%m/%Y"))))
        __M_writer('</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="age" class="column_gauche">Age :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(joueur.age))
        __M_writer(' ans</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="nationalite" class="column_gauche">Nationalité :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(joueur.nationalite))
        __M_writer('</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="taille" class="column_gauche">Taille :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(joueur.taille))
        __M_writer(' m</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="poids" class="column_gauche">Poids :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(joueur.poids))
        __M_writer(' kg</p>\r\n                    </div>\r\n                </div>\r\n                <div id="stat">\r\n                    <h2>Statistiques</h2>\r\n                    ')
        from fonction import Joueur 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['Joueur'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n                    <div class="div_gauche">\r\n                        <p id="matchs_joues" class="column_gauche">Matchs joués :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(Joueur.Joueur.getNbMatchsByJoueur_id(joueur.id)))
        __M_writer('</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="essais" class="column_gauche">Essais :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(Joueur.Joueur.getNbEssaisByJoueur_id(joueur.id)))
        __M_writer('</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="transformations" class="column_gauche">Transformations :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(Joueur.Joueur.getNbTransformationByJoueur_id(joueur.id)))
        __M_writer('</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="drop" class="column_gauche">Drop :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(Joueur.Joueur.getNbDropByJoueur_id(joueur.id)))
        __M_writer('</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="cartons_jaunes" class="column_gauche">Cartons jaunes :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(Joueur.Joueur.getNbCartonJauneByJoueur_id(joueur.id)))
        __M_writer('</p>\r\n                    </div>\r\n                    <div class="div_gauche">\r\n                        <p id="cartons_rouges" class="column_gauche">Cartons rouges :</p>\r\n                        <p class="column_droite">')
        __M_writer(str(Joueur.Joueur.getNbCartonRougeByJoueur_id(joueur.id)))
        __M_writer('</p>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n    </main>\r\n      \r\n\t<footer>\r\n\t\t<nav>\r\n\t\t\t<ul>\r\n\t\t\t\t<li><img src="/image/footer/nike.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/hyundai.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/spvie.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/interim.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/CA.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/yack.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/pizzorno.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/uniti.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/toulon.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/tpm.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/var.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/PACA.png" height="120", width="100"></li>\r\n\t\t\t</ul>\r\n        </nav>\r\n\t\t<p>© 2023 - Ruellan Théo</p>\r\n    </footer>\r\n\r\n    <div id="popup_suppr" class="popup">\r\n        <div class="popup-content">\r\n            <span class="close" onclick="close_popup_suppr()">&times;</span>\r\n            <p>Voulez-vous vraiment supprimer ce joueur ?</p>\r\n            <div>\r\n                <button class="supprimer" onclick="close_popup_suppr()">Annuler</button>\r\n                <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-supprimer\').submit();">Valider</button>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <div id="popup_modif" class="popup">\r\n        <div class="popup-content">\r\n            <span class="close" onclick="close_popup_modif()">&times;</span>\r\n            <div>\r\n                <form id="form-modifier" action="/update_joueur" method="POST" enctype="multipart/form-data">\r\n                    <input type="hidden" name="id" value="')
        __M_writer(str(joueur.id))
        __M_writer('" id="id">\r\n                    <div class="input-row">\r\n                        <label for="nom">Nom : </label>\r\n                        <input type="text" class="form-input" name="nom" value="')
        __M_writer(str(joueur.nom))
        __M_writer('" id="nom">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="prenom">Prénom : </label>\r\n                        <input type="text" class="form-input" name="prenom" value="')
        __M_writer(str(joueur.prenom))
        __M_writer('" id="prenom">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="age">Age : </label>\r\n                        <input type="number" class="form-input" name="age" value="')
        __M_writer(str(joueur.age))
        __M_writer('" id="age">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="poste">Poste : </label>\r\n                        <input type="text" class="form-input" name="poste" value="')
        __M_writer(str(joueur.poste))
        __M_writer('" id="poste">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="taille">Taille : </label>\r\n                        <input type="number" class="form-input" step="0.01" name="taille" value="')
        __M_writer(str(joueur.taille))
        __M_writer('" id="taille">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="poids">Poids : </label>\r\n                        <input type="number" class="form-input" step="0.01" name="poids" value="')
        __M_writer(str(joueur.poids))
        __M_writer('" id="poids">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="date_naissance">Date de naissance : </label>\r\n                        <input type="date" class="form-input" name="date_naissance" value="')
        __M_writer(str(joueur.date_naissance))
        __M_writer('" id="date_naissance">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="nationalite">Nationalité : </label>\r\n                        <input type="text" class="form-input" name="nationalite" value="')
        __M_writer(str(joueur.nationalite))
        __M_writer('" id="nationalite">\r\n                    </div>\r\n                    <div class="input-row">\r\n                        <label for="photo">Photo :</label>\r\n                        <input type="file" name="photo" id="photo">\r\n                    </div>\r\n                    <input type="hidden" class="form-input" name="equipe_id" value="')
        __M_writer(str(joueur.equipe_id))
        __M_writer('" id="equipe_id">\r\n                </form>\r\n                <button class="supprimer" onclick="close_popup_modif()">Annuler</button>\r\n                <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-modifier\').submit();">Valider</button>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <script>\r\n\r\n        function close_popup_modif() {\r\n            var popup = document.getElementById("popup_modif");\r\n            popup.style.display = "none";\r\n        }\r\n\r\n        function open_popup_modif(button) {\r\n\r\n            var id = button.getAttribute("data-id");\r\n            var nom = button.getAttribute("data-nom");\r\n            var prenom = button.getAttribute("data-prenom");\r\n            var age = button.getAttribute("data-age");\r\n            var poste = button.getAttribute("data-poste");\r\n            var taille = button.getAttribute("data-taille");\r\n            var poids = button.getAttribute("data-poids");\r\n            var date_naissance = button.getAttribute("data-date_naissance");\r\n            var nationalite = button.getAttribute("data-nationalite");\r\n            var equipe_id = button.getAttribute("data-equipe_id");\r\n\r\n            document.getElementById("id").value = id;\r\n            document.getElementById("nom").value = nom;\r\n            document.getElementById("prenom").value = prenom;\r\n            document.getElementById("age").value = age;\r\n            document.getElementById("poste").value = poste;\r\n            document.getElementById("taille").value = taille;\r\n            document.getElementById("poids").value = poids;\r\n            document.getElementById("date_naissance").value = date_naissance;\r\n            document.getElementById("nationalite").value = nationalite;\r\n            document.getElementById("equipe_id").value = equipe_id;\r\n\r\n\r\n            var popup = document.getElementById("popup_modif");\r\n            popup.style.display = "block";\r\n        }\r\n\r\n        function close_popup_suppr() {\r\n            var popup = document.getElementById("popup_suppr");\r\n            popup.style.display = "none";\r\n        }\r\n\r\n        function open_popup_suppr(button) {\r\n            var popup = document.getElementById("popup_suppr");\r\n            popup.style.display = "block";\r\n        }\r\n\r\n    </script>\r\n</body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/joueur.html", "uri": "joueur.html", "source_encoding": "utf-8", "line_map": {"16": 0, "23": 1, "24": 22, "25": 22, "26": 22, "27": 22, "28": 23, "29": 24, "32": 23, "33": 24, "34": 25, "37": 24, "38": 25, "39": 25, "40": 29, "41": 29, "42": 33, "43": 34, "46": 33, "47": 35, "48": 35, "49": 35, "50": 35, "51": 38, "52": 38, "53": 40, "54": 40, "55": 40, "56": 40, "57": 40, "58": 40, "59": 40, "60": 40, "61": 40, "62": 40, "63": 40, "64": 40, "65": 40, "66": 40, "67": 40, "68": 40, "69": 40, "70": 40, "71": 40, "72": 40, "73": 40, "74": 40, "75": 44, "76": 44, "77": 47, "78": 47, "79": 51, "80": 51, "81": 55, "82": 55, "83": 59, "84": 59, "85": 63, "86": 63, "87": 68, "88": 69, "91": 68, "92": 71, "93": 71, "94": 75, "95": 75, "96": 79, "97": 79, "98": 83, "99": 83, "100": 87, "101": 87, "102": 91, "103": 91, "104": 135, "105": 135, "106": 138, "107": 138, "108": 142, "109": 142, "110": 146, "111": 146, "112": 150, "113": 150, "114": 154, "115": 154, "116": 158, "117": 158, "118": 162, "119": 162, "120": 166, "121": 166, "122": 172, "123": 172, "129": 123}}
__M_END_METADATA
"""
