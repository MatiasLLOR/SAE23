# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686087524.6613917
_enable_loop = True
_template_filename = 'html/classement.html'
_template_uri = 'classement.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        equipes = context.get('equipes', UNDEFINED)
        enumerate = context.get('enumerate', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\n<html>\n<head>\n\t<title>Effectif - RC Toulon</title>\n\t<link rel="stylesheet" type="text/css" href="/css/calendrier.css">\n\t<script src="/js/alpine.js" defer></script>\n\t<link rel="stylesheet" href="/css/icone.css">\n</head>\n<body>\n\t<header>\n\t\t<nav>\n\t\t\t<ul>\n\t\t\t\t<li><a href="regles">Règles</a></li>\n\t\t\t\t<li><a href="index">Effectif</a></li>\n\t\t\t\t<li><a href="calendar">Calendrier</a></li>\n                <li><a href="classement">Classement</a></li>\n\t\t\t</ul>\n\t\t</nav>\n\t</header>\n\t<main>\n\t\t<navig>\n\t\t\t<h1>CALENDRIER</h1>\n\t\t</navig>\n\t\t<div id="ChoixTri">\n            <a href="classement">PAR POINTS</a>\n            <a href="classement_matchNb">PAR NOMBRE DE MATCH</a>\n        </div>\n\t\t<div id="div_ajouter">\n\t\t\t<h1>Classements des equipes</h1>\n\t\t\t<div>\n\t\t\t\t<button class="ajouter" onclick="open_popup_add(this)">Ajouter</button>\n\t\t\t\t<button class="supprimer" onclick="open_popup_suppr(this)">Supprimer</button>\n\t\t\t\t<button class="modifier" onclick="open_popup_modif(this)">Modifier</button>\n\t\t\t</div>\n\t\t</div>\n        <table>\n          <tr>\n            <th>Equipe</th>\n            <th>Points</th>\n            <th>J.</th>\n            <th>G.</th>\n            <th>N.</th>\n            <th>P.</th>\n          </tr>\n          <tr>\n            <td><hr></td>\n            <td><hr></td>\n            <td><hr></td>\n            <td><hr></td>\n            <td><hr></td>\n            <td><hr></td>\n          </tr>\n          ')
        from fonction import Equipe 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['Equipe'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\n')
        for index, equipe in enumerate(equipes):
            __M_writer('          <tr>\n            <td class="equipe_nom">')
            __M_writer(str(index+1))
            __M_writer('.  <img class="equipe_img" src="')
            __M_writer(str(equipe.logo[1:-1]))
            __M_writer('" width="36", height="36"> ')
            __M_writer(str(equipe.nom[1:-1]))
            __M_writer('</td>\n            <td>')
            __M_writer(str(Equipe.Equipe.getPointsByequipeId(equipe.getId())))
            __M_writer('</td>\n            <td>')
            __M_writer(str(Equipe.Equipe.getNbMatchJoueByequipeId(equipe.getId())))
            __M_writer('</td>\n            <td>')
            __M_writer(str(Equipe.Equipe.getNbMatchGagneByequipeId(equipe.getId())))
            __M_writer('</td>\n            <td>')
            __M_writer(str(Equipe.Equipe.getNbMatchNulByequipeId(equipe.getId())))
            __M_writer('</td>\n            <td>')
            __M_writer(str(Equipe.Equipe.getNbMatchPerduByequipeId(equipe.getId())))
            __M_writer('</td>\n          </tr>\n')
        __M_writer('        </table>\n\t</main>\n\t<footer>\n\t\t<nav>\n\t\t\t<ul>\n\t\t\t\t<li><img src="/image/footer/nike.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/hyundai.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/spvie.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/interim.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/CA.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/yack.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/pizzorno.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/uniti.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/toulon.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/tpm.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/var.png" height="120", width="100"></li>\n\t\t\t\t<li><img src="/image/footer/PACA.png" height="120", width="100"></li>\n\t\t\t</ul>\n\t\t<p>© 2023 - Ruellan Théo</p>\n\t\t</nav>\n\t</footer>\n\n    <div id="popup_add" class="popup">\n        <div class="popup-content">\n            <span class="close" onclick="close_popup_add()">&times;</span>\n            <div>\n                <form id="form-add" action="/add_equipe" method="post" enctype="multipart/form-data">\n                    <div class="input-row">\n\t\t\t\t\t\t<label for="nom">Nom</label>\n\t\t\t\t\t\t<input class="form-input" type="text" id="nom" name="nom" required>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class="input-row">\n\t\t\t\t\t\t<label for="ville">Ville</label>\n\t\t\t\t\t\t<input class="form-input" type="text" id="ville" name="ville" required>\n\t\t\t\t\t</div>\n                    <div class="input-row">\n                        <label for="stade">Stade</label>\n                        <input class="form-input" type="text" id="stade" name="stade" required>\n                    </div>\n\t\t\t\t\t<div class="input-row">\n                        <label for="logo">Logo</label>\n                        <input type="file" id="logo" name="logo" required>\n\t\t\t\t\t</div>\n                </form>\n            </div>\n            <button class="supprimer" onclick="close_popup_add()">Annuler</button>\n            <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-add\').submit();">Valider</button>\n        </div>\n    </div>\n\n    <div id="popup_suppr" class="popup">\n        <div class="popup-content">\n            <span class="close" onclick="close_popup_suppr()">&times;</span>\n            <div>\n                <form id="form-suppr" action="/suppr_equipe" method="post">\n                    <div class="input-row">\n                        <label for="id">Nom</label>\n                        <select class="form-input" id="id" name="id" required>\n')
        for equipe in equipes:
            __M_writer('                            <option value="')
            __M_writer(str(equipe.id))
            __M_writer('">')
            __M_writer(str(equipe.nom[1:-1]))
            __M_writer('</option>\n')
        __M_writer('                        </select>\n                    </div>\n                </form>\n            </div>\n            <button class="supprimer" onclick="close_popup_suppr()">Annuler</button>\n            <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-suppr\').submit();">Valider</button>\n        </div>\n    </div>\n\n    <div id="popup_modif" class="popup">\n        <div class="popup-content">\n            <span class="close" onclick="close_popup_modif()">&times;</span>\n            <div>\n                <form id="form-modif" action="/modif_equipe" method="post" enctype="multipart/form-data">\n                    <div class="input-row">\n                        <label for="id">Nom</label>\n                        <select class="form-input" id="id" name="id" required>\n')
        for equipe in equipes:
            __M_writer('                            <option value="')
            __M_writer(str(equipe.id))
            __M_writer('">')
            __M_writer(str(equipe.nom[1:-1]))
            __M_writer('</option>\n')
        __M_writer('                        </select>\n                    </div>\n                    <div class="input-row">\n\t\t\t\t\t\t<label for="nom">Nom</label>\n\t\t\t\t\t\t<input class="form-input" type="text" id="nom" name="nom" required>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class="input-row">\n\t\t\t\t\t\t<label for="ville">Ville</label>\n\t\t\t\t\t\t<input class="form-input" type="text" id="ville" name="ville" required>\n\t\t\t\t\t</div>\n                    <div class="input-row">\n                        <label for="stade">Stade</label>\n                        <input class="form-input" type="text" id="stade" name="stade" required>\n                    </div>\n\t\t\t\t\t<div class="input-row">\n                        <label for="logo">Logo</label>\n                        <input type="file" id="logo" name="logo" required>\n\t\t\t\t\t</div>\n                </form>\n            </div>\n            <button class="supprimer" onclick="close_popup_modif()">Annuler</button>\n            <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-modif\').submit();">Valider</button>\n        </div>\n    </div>                       \n\n    <script>\n        function close_popup_add() {\n            var popup = document.getElementById("popup_add");\n            popup.style.display = "none";\n        }\n\n        function open_popup_add(button) {\n            var popup = document.getElementById("popup_add");\n            popup.style.display = "block";\n        }\n\n\t\tfunction close_popup_modif() {\n            var popup = document.getElementById("popup_modif");\n            popup.style.display = "none";\n        }\n\n        function open_popup_modif(button) {\n            var popup = document.getElementById("popup_modif");\n            popup.style.display = "block";\n        }\n\n        function close_popup_suppr() {\n            var popup = document.getElementById("popup_suppr");\n            popup.style.display = "none";\n        }\n\n        function open_popup_suppr(button) {\n            var popup = document.getElementById("popup_suppr");\n            popup.style.display = "block";\n        }\n    </script>\n\n\n</body>\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/classement.html", "uri": "classement.html", "source_encoding": "utf-8", "line_map": {"16": 0, "23": 1, "24": 53, "25": 54, "28": 53, "29": 54, "30": 55, "31": 56, "32": 56, "33": 56, "34": 56, "35": 56, "36": 56, "37": 57, "38": 57, "39": 58, "40": 58, "41": 59, "42": 59, "43": 60, "44": 60, "45": 61, "46": 61, "47": 64, "48": 122, "49": 123, "50": 123, "51": 123, "52": 123, "53": 123, "54": 125, "55": 142, "56": 143, "57": 143, "58": 143, "59": 143, "60": 143, "61": 145, "67": 61}}
__M_END_METADATA
"""
