# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686519032.2691593
_enable_loop = True
_template_filename = 'html/fiche.html'
_template_uri = 'fiche.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        len = context.get('len', UNDEFINED)
        joueurs = context.get('joueurs', UNDEFINED)
        evenements = context.get('evenements', UNDEFINED)
        joueurs_eve = context.get('joueurs_eve', UNDEFINED)
        enumerate = context.get('enumerate', UNDEFINED)
        compositions = context.get('compositions', UNDEFINED)
        rencontre = context.get('rencontre', UNDEFINED)
        range = context.get('range', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n<head>\r\n\t<title>Effectif - RC Toulon</title>\r\n\t<link rel="stylesheet" type="text/css" href="/css/fiche.css">\r\n\t<script src="/js/alpine.js" defer></script>\r\n\t<link rel="stylesheet" href="/css/icone.css">\r\n</head>\r\n<body>\r\n\t<header>\r\n\t\t<nav>\r\n\t\t\t<ul>\r\n\t\t\t\t<li><a href="regles">Règles</a></li>\r\n\t\t\t\t<li><a href="index">Effectif</a></li>\r\n\t\t\t\t<li><a href="calendar">Calendrier</a></li>\r\n\t\t\t\t<li><a href="classement">Classement</a></li>\r\n\t\t\t</ul>\r\n\t\t</nav>\r\n\t</header>\r\n\t<main>\r\n\t\t<navig>\r\n\t\t\t<h1>')
        __M_writer(str(rencontre.equipe_nom_suivi[1:-1]))
        __M_writer(' VS ')
        __M_writer(str(rencontre.equipe_nom_adverse[1:-1]))
        __M_writer('</h1>\r\n\t\t</navig>\r\n        <div id="div_score">\r\n\t\t\t<form action="/ajouter_score_suivi">\r\n\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n\t\t\t\t<input type="hidden" id="equipe_suivi_id" name="equipe_suivi_id" value="')
        __M_writer(str(rencontre.equipe_suivi_id))
        __M_writer('">\r\n\t\t\t\t<button class="score" type="submit">+1</button>\r\n\t\t\t</form>\r\n            <img class="equipe_img" src="')
        __M_writer(str(rencontre.logo_suivi[1:-1]))
        __M_writer('" height="160", width="160">\r\n            <p>')
        __M_writer(str(rencontre.score_suivi))
        __M_writer(' / ')
        __M_writer(str(rencontre.score_adverse))
        __M_writer('</p>\r\n            <img class="equipe_img" src="')
        __M_writer(str(rencontre.logo_adverse[1:-1]))
        __M_writer('" height="160", width="160">\r\n\t\t\t<form action="/ajouter_score_adverse">\r\n\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n\t\t\t\t<input type="hidden" id="equipe_adverse_id" name="equipe_adverse_id" value="')
        __M_writer(str(rencontre.equipe_adverse_id))
        __M_writer('">\r\n\t\t\t\t<button class="score" type="submit">+1</button>\r\n\t\t\t</form>\r\n        </div>\r\n\t\t<h1>Composition</h1>\r\n\t\t<div class="div_button">\r\n\t\t\t<button class="ajouter" onclick="open_popup_add_compo(this)"> Ajouter</button>\r\n\t\t\t<button class="supprimer" onclick="open_popup_suppr_compo(this)"> Supprimer</button>\r\n\t\t\t<button class="modifier" onclick="open_popup_modif_compo(this)"> Modifier</button>\r\n\t\t</div>\r\n\t\t<div id="compo">\r\n\t\t\t<div>\r\n\t\t\t\t<img src="/image/header/map_compo.jpg" width="600px">\r\n\t\t\t</div>\r\n\t\t\t<div id="compo_joueur">\r\n')
        for composition in compositions:
            __M_writer('\t\t\t\t\t<p>')
            __M_writer(str(composition.numero_maillot))
            __M_writer(' - ')
            __M_writer(str(composition.joueurs.getJoueurById(composition.joueur_id).getNom()))
            __M_writer(' ')
            __M_writer(str(composition.joueurs.getJoueurById(composition.joueur_id).getPrenom()))
            __M_writer('</p>\r\n')
        __M_writer('\t\t\t</div>\r\n\t\t</div>\r\n\t\t<h1>Evenements</h1>\r\n\t\t<div class="div_button">\r\n\t\t\t<button class="ajouter" onclick="open_popup_add_evenement(this)"> Ajouter</button>\r\n\t\t\t<button class="supprimer" onclick="open_popup_suppr_evenement(this)"> Supprimer</button>\r\n\t\t\t<button class="modifier" onclick="open_popup_modif_evenement(this)"> Modifier</button>\r\n\t\t</div>\r\n\t\t<div id="div_evenement">\r\n\t\t')
        ancien_type = [] 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['ancien_type'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\r\n')
        for index, evenement in enumerate(evenements) :
            if index == 0 or evenement.type_evenement != ancien_type[-1]:
                __M_writer('\t\t\t\t\t<div class="type">\r\n\t\t\t\t\t\t<div id="titre">\r\n\t\t\t\t\t\t\t<h2>')
                __M_writer(str(evenement.type_evenement))
                __M_writer('</h2>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t')
                ancien_type.append(evenement.type_evenement) 
                
                __M_locals_builtin_stored = __M_locals_builtin()
                __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in [] if __M_key in __M_locals_builtin_stored]))
                __M_writer('\r\n')
            __M_writer('\t\t\t\t\t\t<div class="evenement">\r\n\t\t\t\t\t\t\t<p>')
            __M_writer(str(evenement.minute))
            __M_writer("' -  ")
            __M_writer(str(evenement.joueurs.getJoueurById(evenement.joueur_id).getNom()))
            __M_writer(' ')
            __M_writer(str(evenement.joueurs.getJoueurById(evenement.joueur_id).getPrenom()))
            __M_writer(' <p>\r\n\t\t\t\t\t\t</div>\r\n')
            if index == len(evenements) - 1 or evenement.type_evenement != evenements[index+1].type_evenement:
                __M_writer('\t\t\t\t\t</div>\r\n')
        __M_writer('\t\t</div>\r\n\t</main>\r\n\t<footer>\r\n\t\t<nav>\r\n\t\t\t<ul>\r\n\t\t\t\t<li><img src="/image/footer/nike.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/hyundai.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/spvie.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/interim.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/CA.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/yack.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/pizzorno.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/uniti.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/toulon.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/tpm.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/var.png" height="120", width="100"></li>\r\n\t\t\t\t<li><img src="/image/footer/PACA.png" height="120", width="100"></li>\r\n\t\t\t</ul>\r\n\t\t<p>© 2023 - Ruellan Théo</p>\r\n\t\t</nav>\r\n\t</footer>\r\n\r\n\t<div id="popup_add_compo" class="popup">\r\n        <div class="popup-content">\r\n            <span class="close" onclick="close_popup_add_compo()">&times;</span>\r\n            <div>\r\n                <form id="form-add_composition" action="/add_composition" method="GET">\r\n')
        for index in range(1, 16):
            __M_writer('\t\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t\t<label for="joueur')
            __M_writer(str(index))
            __M_writer('">Numero ')
            __M_writer(str(index))
            __M_writer('</label>\r\n\t\t\t\t\t\t\t<select class="form-input" id="joueur')
            __M_writer(str(index))
            __M_writer('" name="joueur')
            __M_writer(str(index))
            __M_writer('" required>\r\n')
            for joueur in joueurs:
                if index == 1 and joueur.poste == "Pilier Gauche":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 2 and joueur.poste == "Talonneur":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 3 and joueur.poste == "Pilier Droit":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 4  or index == 5) and joueur.poste == "Deuxième Ligne":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 6 or index == 7 or index == 8) and joueur.poste == "Troisième Ligne":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 9 and joueur.poste == "Demi de mêlée":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 10 and joueur.poste == "Demi d'ouverture":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 11 or index == 14) and joueur.poste == "Trois-Quarts Aile":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 12 or index == 13) and joueur.poste == "Trois-Quarts Centre":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 15 and joueur.poste == "Arrière":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
            __M_writer('\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t</div>\r\n')
        __M_writer('\t\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n                </form>\r\n            </div>\r\n            <button class="supprimer" onclick="close_popup_add_compo()">Annuler</button>\r\n            <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-add_composition\').submit();">Valider</button>\r\n        </div>\r\n    </div>\r\n\r\n\r\n\t<div id="popup_suppr_compo" class="popup">\r\n\t\t<div class="popup-content">\r\n\t\t\t<span class="close" onclick="close_popup_suppr_compo()">&times;</span>\r\n\t\t\t<div>\r\n\t\t\t\t<form id="form-suppr" action="/suppr_composition" method="GET">\r\n\t\t\t\t\t<p>Êtes-vous sûr de vouloir supprimer cette composition ?</p>\r\n\t\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n                </form>\r\n\t\t\t</div>\r\n\t\t\t<button class="supprimer" onclick="close_popup_suppr_compo()">Annuler</button>\r\n\t\t\t<button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-suppr\').submit();">Valider</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div id="popup_modif_compo" class="popup">\r\n        <div class="popup-content">\r\n            <span class="close" onclick="close_popup_modif_compo()">&times;</span>\r\n            <div>\r\n                <form id="form-modif" action="/modif_composition" method="GET">\r\n')
        for index in range(1, 16):
            __M_writer('\t\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t\t<label for="joueur')
            __M_writer(str(index))
            __M_writer('">Numero ')
            __M_writer(str(index))
            __M_writer('</label>\r\n\t\t\t\t\t\t\t<select class="form-input" id="joueur')
            __M_writer(str(index))
            __M_writer('" name="joueur')
            __M_writer(str(index))
            __M_writer('" required>\r\n')
            for joueur in joueurs:
                if index == 1 and joueur.poste == "Pilier Gauche":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 2 and joueur.poste == "Talonneur":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 3 and joueur.poste == "Pilier Droit":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 4  or index == 5) and joueur.poste == "Deuxième Ligne":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 6 or index == 7 or index == 8) and joueur.poste == "Troisième Ligne":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 9 and joueur.poste == "Demi de mêlée":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 10 and joueur.poste == "Demi d'ouverture":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 11 or index == 14) and joueur.poste == "Trois-Quarts Aile":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif (index == 12 or index == 13) and joueur.poste == "Trois-Quarts Centre":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
                elif index == 15 and joueur.poste == "Arrière":
                    __M_writer('\t\t\t\t\t\t\t\t\t\t<option value="')
                    __M_writer(str(joueur.id))
                    __M_writer('">')
                    __M_writer(str(joueur.nom))
                    __M_writer('</option>\r\n')
            __M_writer('\t\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t</div>\r\n')
        __M_writer('\t\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n                </form>\r\n            </div>\r\n            <button class="supprimer" onclick="close_popup_modif_compo()">Annuler</button>\r\n            <button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-modif\').submit();">Valider</button>\r\n        </div>\r\n    </div>\r\n\r\n\t<!-- Evenements -->\r\n\r\n\t<div id="popup_add" class="popup">\r\n\t\t<div class="popup-content">\r\n\t\t\t<span class="close" onclick="close_popup_add_evenement()">&times;</span>\r\n\t\t\t<div>\r\n\t\t\t\t<form id="form-add_evenement" action="/add_evenement" method="GET">\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="type">Type</label>\r\n\t\t\t\t\t\t<select class="form-input" id="type_evenement" name="type_evenement" required>\r\n\t\t\t\t\t\t\t<option value="Transformation">Transformation</option>\r\n\t\t\t\t\t\t\t<option value="Essai">Essai</option>\r\n\t\t\t\t\t\t\t<option value="Drop">Drop</option>\r\n\t\t\t\t\t\t\t<option value="Carton Jaune">Carton Jaune</option>\r\n\t\t\t\t\t\t\t<option value="Carton Rouge">Carton Rouge</option>\r\n\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<select class="form-input" id="joueur_id" name="joueur_id" required>\r\n')
        for joueur in joueurs_eve:
            __M_writer('\t\t\t\t\t\t\t\t<option value="')
            __M_writer(str(joueur.id))
            __M_writer('">')
            __M_writer(str(joueur.nom))
            __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="minute">Minute</label>\r\n\t\t\t\t\t\t<input type="number" id="minute" name="minute" min="0" max="80" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t\t<button class="supprimer" onclick="close_popup_add_evenement()">Annuler</button>\r\n\t\t\t<button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-add_evenement\').submit();">Valider</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div id="popup_suppr" class="popup">\r\n\t\t<div class="popup-content">\r\n\t\t\t<span class="close" onclick="close_popup_suppr_evenement()">&times;</span>\r\n\t\t\t<div>\r\n\t\t\t\t<form id="form-suppr_evenement" action="/suppr_evenement" method="GET">\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<select class="form-input" id="evenement_id" name="evenement_id" required>\r\n')
        for evenement in evenements:
            __M_writer('\t\t\t\t\t\t\t\t<option value="')
            __M_writer(str(evenement.id))
            __M_writer('">')
            __M_writer(str(evenement.type_evenement))
            __M_writer(' - ')
            __M_writer(str(evenement.minute))
            __M_writer("' ")
            __M_writer(str(evenement.joueurs.getJoueurById(evenement.joueur_id).getNom()))
            __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t\t<button class="supprimer" onclick="close_popup_suppr_evenement()">Annuler</button>\r\n\t\t\t<button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-suppr_evenement\').submit();">Valider</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div id="popup_modif" class="popup">\r\n\t\t<div class="popup-content">\r\n\t\t\t<span class="close" onclick="close_popup_modif_evenement()">&times;</span>\r\n\t\t\t<div>\r\n\t\t\t\t<form id="form-modif_evenement" action="/modif_evenement" method="GET">\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<select class="form-input" id="evenement_id" name="evenement_id" required>\r\n')
        for evenement in evenements:
            __M_writer('\t\t\t\t\t\t\t\t<option value="')
            __M_writer(str(evenement.id))
            __M_writer('">')
            __M_writer(str(evenement.type_evenement))
            __M_writer(' - ')
            __M_writer(str(evenement.minute))
            __M_writer("' ")
            __M_writer(str(evenement.joueurs.getJoueurById(evenement.joueur_id).getNom()))
            __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<select class="form-input" id="joueur_id" name="joueur_id" required>\r\n')
        for joueur in joueurs_eve:
            __M_writer('\t\t\t\t\t\t\t\t<option value="')
            __M_writer(str(joueur.id))
            __M_writer('">')
            __M_writer(str(joueur.nom))
            __M_writer('</option>\r\n')
        __M_writer('\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="input-row">\r\n\t\t\t\t\t\t<label for="minute">Minute</label>\r\n\t\t\t\t\t\t<input type="number" id="minute" name="minute" min="0" max="80" required>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<input type="hidden" id="rencontre_id" name="rencontre_id" value="')
        __M_writer(str(rencontre.id))
        __M_writer('">\r\n\t\t\t\t</form>\r\n\t\t\t</div>\r\n\t\t\t<button class="supprimer" onclick="close_popup_modif_evenement()">Annuler</button>\r\n\t\t\t<button class="valider" onclick="event.preventDefault(); document.getElementById(\'form-modif_evenement\').submit();">Valider</button>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<script>\r\n        function close_popup_add_compo() {\r\n            var popup = document.getElementById("popup_add_compo");\r\n            popup.style.display = "none";\r\n        }\r\n\r\n        function open_popup_add_compo(button) {\r\n            var popup = document.getElementById("popup_add_compo");\r\n            popup.style.display = "block";\r\n        }\r\n\r\n\t\tfunction close_popup_suppr_compo() {\r\n\t\t\tvar popup = document.getElementById("popup_suppr_compo");\r\n\t\t\tpopup.style.display = "none";\r\n\t\t}\r\n\r\n\t\tfunction open_popup_suppr_compo(button) {\r\n\t\t\tvar popup = document.getElementById("popup_suppr_compo");\r\n\t\t\tpopup.style.display = "block";\r\n\t\t}\r\n\r\n\t\tfunction close_popup_modif_compo() {\r\n\t\t\tvar popup = document.getElementById("popup_modif_compo");\r\n\t\t\tpopup.style.display = "none";\r\n\t\t}\r\n\r\n\t\tfunction open_popup_modif_compo(button) {\r\n\r\n\t\t\tvar popup = document.getElementById("popup_modif_compo");\r\n\t\t\tpopup.style.display = "block";\r\n\t\t}\r\n\r\n\t\tfunction close_popup_add_evenement() {\r\n\t\t\tvar popup = document.getElementById("popup_add");\r\n\t\t\tpopup.style.display = "none";\r\n\t\t}\r\n\r\n\t\tfunction open_popup_add_evenement(button) {\r\n\t\t\tvar popup = document.getElementById("popup_add");\r\n\t\t\tpopup.style.display = "block";\r\n\t\t}\r\n\r\n\t\tfunction close_popup_suppr_evenement() {\r\n\t\t\tvar popup = document.getElementById("popup_suppr");\r\n\t\t\tpopup.style.display = "none";\r\n\t\t}\r\n\r\n\t\tfunction open_popup_suppr_evenement(button) {\r\n\t\t\tvar popup = document.getElementById("popup_suppr");\r\n\t\t\tpopup.style.display = "block";\r\n\t\t}\r\n\r\n\t\tfunction close_popup_modif_evenement() {\r\n\t\t\tvar popup = document.getElementById("popup_modif");\r\n\t\t\tpopup.style.display = "none";\r\n\t\t}\r\n\r\n\t\tfunction open_popup_modif_evenement(button) {\r\n\t\t\tvar popup = document.getElementById("popup_modif");\r\n\t\t\tpopup.style.display = "block";\r\n\t\t}\r\n\r\n\t</script>\r\n\r\n\r\n\r\n</body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/fiche.html", "uri": "fiche.html", "source_encoding": "utf-8", "line_map": {"16": 0, "29": 1, "30": 22, "31": 22, "32": 22, "33": 22, "34": 26, "35": 26, "36": 27, "37": 27, "38": 30, "39": 30, "40": 31, "41": 31, "42": 31, "43": 31, "44": 32, "45": 32, "46": 34, "47": 34, "48": 35, "49": 35, "50": 50, "51": 51, "52": 51, "53": 51, "54": 51, "55": 51, "56": 51, "57": 51, "58": 53, "59": 62, "60": 63, "63": 62, "64": 63, "65": 64, "66": 65, "67": 67, "68": 67, "69": 69, "70": 70, "73": 69, "74": 71, "75": 72, "76": 72, "77": 72, "78": 72, "79": 72, "80": 72, "81": 74, "82": 75, "83": 78, "84": 105, "85": 106, "86": 107, "87": 107, "88": 107, "89": 107, "90": 108, "91": 108, "92": 108, "93": 108, "94": 109, "95": 110, "96": 111, "97": 111, "98": 111, "99": 111, "100": 111, "101": 112, "102": 113, "103": 113, "104": 113, "105": 113, "106": 113, "107": 114, "108": 115, "109": 115, "110": 115, "111": 115, "112": 115, "113": 116, "114": 117, "115": 117, "116": 117, "117": 117, "118": 117, "119": 118, "120": 119, "121": 119, "122": 119, "123": 119, "124": 119, "125": 120, "126": 121, "127": 121, "128": 121, "129": 121, "130": 121, "131": 122, "132": 123, "133": 123, "134": 123, "135": 123, "136": 123, "137": 124, "138": 125, "139": 125, "140": 125, "141": 125, "142": 125, "143": 126, "144": 127, "145": 127, "146": 127, "147": 127, "148": 127, "149": 128, "150": 129, "151": 129, "152": 129, "153": 129, "154": 129, "155": 132, "156": 135, "157": 135, "158": 135, "159": 150, "160": 150, "161": 163, "162": 164, "163": 165, "164": 165, "165": 165, "166": 165, "167": 166, "168": 166, "169": 166, "170": 166, "171": 167, "172": 168, "173": 169, "174": 169, "175": 169, "176": 169, "177": 169, "178": 170, "179": 171, "180": 171, "181": 171, "182": 171, "183": 171, "184": 172, "185": 173, "186": 173, "187": 173, "188": 173, "189": 173, "190": 174, "191": 175, "192": 175, "193": 175, "194": 175, "195": 175, "196": 176, "197": 177, "198": 177, "199": 177, "200": 177, "201": 177, "202": 178, "203": 179, "204": 179, "205": 179, "206": 179, "207": 179, "208": 180, "209": 181, "210": 181, "211": 181, "212": 181, "213": 181, "214": 182, "215": 183, "216": 183, "217": 183, "218": 183, "219": 183, "220": 184, "221": 185, "222": 185, "223": 185, "224": 185, "225": 185, "226": 186, "227": 187, "228": 187, "229": 187, "230": 187, "231": 187, "232": 190, "233": 193, "234": 193, "235": 193, "236": 220, "237": 221, "238": 221, "239": 221, "240": 221, "241": 221, "242": 223, "243": 229, "244": 229, "245": 244, "246": 245, "247": 245, "248": 245, "249": 245, "250": 245, "251": 245, "252": 245, "253": 245, "254": 245, "255": 247, "256": 249, "257": 249, "258": 264, "259": 265, "260": 265, "261": 265, "262": 265, "263": 265, "264": 265, "265": 265, "266": 265, "267": 265, "268": 267, "269": 271, "270": 272, "271": 272, "272": 272, "273": 272, "274": 272, "275": 274, "276": 280, "277": 280, "283": 277}}
__M_END_METADATA
"""
