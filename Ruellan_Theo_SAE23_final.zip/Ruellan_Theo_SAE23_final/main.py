import cherrypy, os, os.path

from mako.template import Template
from mako.lookup import TemplateLookup
from fonction import Connection
from fonction import Joueur
from fonction import Equipe
from fonction import Composition
from fonction import Rencontre
from fonction import Evenement
from fonction import Jeu 



mylookup = TemplateLookup(directories=['html'], module_directory='mako_modules')

class RugbyClub(object):

    def getConnection(self):
        return Connection.Connection.from_config_file("config.txt")

    @cherrypy.expose
    def regles(self):
        main= mylookup.get_template('regles.html')
        return main.render()

    @cherrypy.expose
    def index(self):
        main= mylookup.get_template('main.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = Joueur.JoueurRepository(connection).importJoueurs()
        db.close()
        return main.render(joueurs=joueurs)
    
    @cherrypy.expose
    def getJoueurByPoste(self):
        main= mylookup.get_template('main_poste.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = Joueur.JoueurRepository(connection).trierJoueurParPoste()
        db.close()
        return main.render(joueurs=joueurs)
    
    @cherrypy.expose
    def getJoueurByAge(self):
        main= mylookup.get_template('main.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = Joueur.JoueurRepository(connection).trierJoueurParAge()
        db.close()
        return main.render(joueurs=joueurs)
    
    @cherrypy.expose
    def getJoueurByAlpha(self):
        main= mylookup.get_template('main.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = Joueur.JoueurRepository(connection).trierJoueurParOrdreAlphabetique()
        db.close()
        return main.render(joueurs=joueurs)
    
    @cherrypy.expose
    def getJoueurByAge_min_max(self, age_min, age_max):
        main= mylookup.get_template('main.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = Joueur.JoueurRepository(connection).trierJoueurParAge_min_max(age_min=age_min, age_max=age_max)
        db.close()
        return main.render(joueurs=joueurs)
    
    @cherrypy.expose
    def getJoueurByPoste(self, **kwargs):
        main= mylookup.get_template('main_poste.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        postes = Joueur.JoueurRepository(connection).transfKwargIntoPoste(kwargs)
        joueurs = Joueur.JoueurRepository(connection).getJoueurByPostes(postes)
        db.close()
        return main.render(joueurs=joueurs)
    
    @cherrypy.expose
    def calendar(self):
        main= mylookup.get_template('calendrier.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        rencontres = Rencontre.RencontreRepository(connection).trierMatchParDate()
        equipes = Equipe.EquipeRepository(connection).importEquipes()
        db.close()
        return main.render(rencontres=rencontres, equipes=equipes)

    @cherrypy.expose
    def calendar_inverse(self):
        main= mylookup.get_template('calendrier.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        rencontres = Rencontre.RencontreRepository(connection).trierMatchParDateInverse()
        equipes = Equipe.EquipeRepository(connection).importEquipes()
        db.close()
        return main.render(rencontres=rencontres, equipes=equipes)

    @cherrypy.expose
    def calendar_venir(self):
        main= mylookup.get_template('calendrier.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        rencontres = Rencontre.RencontreRepository(connection).trierMatchAVenir()
        equipes = Equipe.EquipeRepository(connection).importEquipes()
        db.close()
        return main.render(rencontres=rencontres, equipes=equipes)

    @cherrypy.expose
    def calendar_passer(self):
        main= mylookup.get_template('calendrier.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        rencontres = Rencontre.RencontreRepository(connection).trierMatchPasser()
        equipes = Equipe.EquipeRepository(connection).importEquipes()
        db.close()
        return main.render(rencontres=rencontres, equipes=equipes)
    
    @cherrypy.expose
    def joueur(self, id):
        main= mylookup.get_template('joueur.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueur = Joueur.JoueurRepository(connection).getJoueurById(int(id))
        db.close()
        return main.render(joueur=joueur)
    
    @cherrypy.expose
    def supprime_joueur(self, id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        Joueur.JoueurRepository(connection).deleteJoueur(int(id))
        db.close()
        raise cherrypy.HTTPRedirect("/getJoueurByPoste?tout=true")
    
    @cherrypy.expose
    def update_joueur(self, id, nom, prenom, age, poste, taille, poids, date_naissance, nationalite, photo, equipe_id):

        # Récupérer le fichier photo et le chemin temporaire sur le serveur
        photo_file = photo.file
        temp_path = photo_file.name

        # Extraire l'extension du fichier photo
        _, ext = os.path.splitext(photo.filename)

        # Générer le nouveau nom de fichier en utilisant "Nom_Prenom" format
        nouveau_nom = f"{nom.capitalize()}_{prenom.capitalize()}{ext}"

        # Déterminer le répertoire de destination pour la photo
        dest_dir = os.path.join(os.path.dirname(__file__), 'image', 'pro')
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)

        # Déplacer le fichier photo vers le répertoire de destination en utilisant le nouveau nom de fichier
        dest_path = os.path.join(dest_dir, nouveau_nom)
        with open(dest_path, 'wb') as f:
            while True:
                data = photo_file.read(8192)
                if not data:
                    break
                f.write(data)

        main= mylookup.get_template('joueur.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        Joueur.JoueurRepository(connection).updateJoueur(Joueur.Joueur(int(id), nom, prenom, age, poste, taille, poids, str(date_naissance), nationalite, f"image/pro/{nouveau_nom}", equipe_id))
        joueur = Joueur.JoueurRepository(connection).getJoueurById(int(id))
        db.close()
        return main.render(joueur=joueur)

    @cherrypy.expose
    def add_joueur(self, nom, prenom, age, poste, taille, poids, date_naissance, nationalite, photo, equipe_id):
        # Récupérer le fichier photo et le chemin temporaire sur le serveur
        photo_file = photo.file
        temp_path = photo_file.name

        # Extraire l'extension du fichier photo
        _, ext = os.path.splitext(photo.filename)

        # Générer le nouveau nom de fichier en utilisant "Nom_Prenom" format
        nouveau_nom = f"{nom.capitalize()}_{prenom.capitalize()}{ext}"

        # Déterminer le répertoire de destination pour la photo
        dest_dir = os.path.join(os.path.dirname(__file__), 'image', 'pro')
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)

        # Déplacer le fichier photo vers le répertoire de destination en utilisant le nouveau nom de fichier
        dest_path = os.path.join(dest_dir, nouveau_nom)
        with open(dest_path, 'wb') as f:
            while True:
                data = photo_file.read(8192)
                if not data:
                    break
                f.write(data)

        # Continuez avec le reste de la logique pour ajouter le joueur à la base de données
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        last_id = Joueur.JoueurRepository(connection).getIDLastJoueur()
        print(str(date_naissance))
        Joueur.JoueurRepository(connection).addJoueur(Joueur.Joueur(last_id, nom, prenom, age, poste, taille, poids, str(date_naissance), nationalite, f"image/pro/{nouveau_nom}", equipe_id))
        db.close()
        raise cherrypy.HTTPRedirect("/getJoueurByPoste?tout=true")

    
    @cherrypy.expose
    def add_rencontre(self, date, equipe_adv, score_dom, score_adv, dom_bool=0):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        last_id = Rencontre.RencontreRepository(connection).getIdLastRencontre()

        if dom_bool == 0:
            domicile = False
            equipe_suivi_id = int(equipe_adv)
            equipe_adverse_id = 1
            score_suivi = int(score_adv)
            score_adverse = int(score_dom)
            if score_suivi < score_adverse:
                resultat = "Victoire"
            elif score_suivi > score_adverse:
                resultat = "Défaite"
            else:
                resultat = "Match Nul"


        else:
            domicile = True
            equipe_suivi_id = 1
            equipe_adverse_id = int(equipe_adv)
            score_suivi = int(score_dom)
            score_adverse = int(score_adv)
            if score_suivi > score_adverse:
                resultat = "Victoire"
            elif score_suivi < score_adverse:
                resultat = "Défaite"
            else:
                resultat = "Match Nul"
        print(f"date : {date}, domicile : {dom_bool}, equipe_suivi_id : {equipe_suivi_id}, equipe_adverse_id : {equipe_adverse_id}, score_suivi : {score_suivi}, score_adverse : {score_adverse}, resultat : {resultat}")
        Rencontre.RencontreRepository(connection).addRencontre(Rencontre.Rencontre(last_id, score_suivi, score_adverse, domicile, resultat, int(equipe_suivi_id), int(equipe_adverse_id), str(date)))
        db.close()
        raise cherrypy.HTTPRedirect("/calendar")
    
    @cherrypy.expose
    def suppr_rencontre(self, id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        Rencontre.RencontreRepository(connection).deleteRencontre(int(id))
        db.close()
        raise cherrypy.HTTPRedirect("/calendar")
    
    @cherrypy.expose
    def modif_rencontre(self, id, date, equipe_adv, score_dom, score_adv, dom_bool=0):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        if dom_bool == 0:
            domicile = False
            equipe_suivi_id = int(equipe_adv)
            equipe_adverse_id = 1
            score_suivi = int(score_adv)
            score_adverse = int(score_dom)
            if score_suivi < score_adverse:
                resultat = "Victoire"
            elif score_suivi > score_adverse:
                resultat = "Défaite"
            else:
                resultat = "Match Nul"


        else:
            domicile = True
            equipe_suivi_id = 1
            equipe_adverse_id = int(equipe_adv)
            score_suivi = int(score_dom)
            score_adverse = int(score_adv)
            if score_suivi > score_adverse:
                resultat = "Victoire"
            elif score_suivi < score_adverse:
                resultat = "Défaite"
            else:
                resultat = "Match Nul"
        Rencontre.RencontreRepository(connection).updateRencontre(Rencontre.Rencontre(id, score_suivi, score_adverse, domicile, resultat, int(equipe_suivi_id), int(equipe_adverse_id), str(date)))
        db.close()
        raise cherrypy.HTTPRedirect("/calendar")   
    
    @cherrypy.expose
    def add_composition(self, joueur1, joueur2, joueur3, joueur4, joueur5, joueur6, joueur7, joueur8, joueur9, joueur10, joueur11, joueur12, joueur13, joueur14, joueur15, rencontre_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = [joueur1, joueur2, joueur3, joueur4, joueur5, joueur6, joueur7, joueur8, joueur9, joueur10, joueur11, joueur12, joueur13, joueur14, joueur15]
        cpt = 1
        while cpt != 16:
            last_id = Composition.CompositionRepository(connection).getIDLastComposition()
            print(f"last_id : {last_id}, cpt : {cpt}, joueurs[cpt-1] : {joueurs[cpt-1]}, rencontre_id : {rencontre_id}")
            Composition.CompositionRepository(connection).addComposition(Composition.Composition(last_id, cpt, rencontre_id , int(joueurs[cpt-1])))
            cpt += 1
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")
    
    @cherrypy.expose
    def suppr_composition(self, rencontre_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        Composition.CompositionRepository(connection).deleteCompositionsByRencontreId(int(rencontre_id))
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")
    
    @cherrypy.expose
    def modif_composition(self, joueur1, joueur2, joueur3, joueur4, joueur5, joueur6, joueur7, joueur8, joueur9, joueur10, joueur11, joueur12, joueur13, joueur14, joueur15, rencontre_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = [joueur1, joueur2, joueur3, joueur4, joueur5, joueur6, joueur7, joueur8, joueur9, joueur10, joueur11, joueur12, joueur13, joueur14, joueur15]
        cpt = 1
        while cpt != 16:
            id = Composition.CompositionRepository(connection).getCompositionIDByRencontreIdAndNumeroMaillot(int(rencontre_id), cpt)
            print(f"cpt : {cpt}, joueurs[cpt-1] : {joueurs[cpt-1]}, rencontre_id : {rencontre_id}")
            Composition.CompositionRepository(connection).updateComposition(Composition.Composition(id, cpt, rencontre_id , int(joueurs[cpt-1])))
            cpt += 1
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")
    
    @cherrypy.expose
    def add_evenement(self, type_evenement, joueur_id, minute, rencontre_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        id = Evenement.EvenementRepository(connection).getIDLastEvenement()
        print(f"joueur_id : {joueur_id}, type_evenement : {type_evenement}, minute : {minute}, rencontre_id : {rencontre_id}")
        Evenement.EvenementRepository(connection).addEvenement(Evenement.Evenement(id, type_evenement, minute, rencontre_id, joueur_id))
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")
    
    @cherrypy.expose
    def suppr_evenement(self, evenement_id, rencontre_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        Evenement.EvenementRepository(connection).deleteEvenement(int(evenement_id))
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")
    
    @cherrypy.expose
    def modif_evenement(self, evenement_id, joueur_id, minute, rencontre_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        evenement_type = Evenement.EvenementRepository(connection).getTypeByEvenementId(int(evenement_id))
        Evenement.EvenementRepository(connection).updateEvenement(Evenement.Evenement(int(evenement_id), evenement_type, minute, rencontre_id, joueur_id))
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")
    
    @cherrypy.expose
    def fiche(self, id):
        main = mylookup.get_template('fiche.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        joueurs = Joueur.JoueurRepository(connection).importJoueurs()
        joueurs_eve = Joueur.JoueurRepository(connection).getJoueurByRencontreIdINComposition(int(id))
        rencontre = Rencontre.RencontreRepository(connection).getRencontreById(int(id))
        equipes = Equipe.EquipeRepository(connection).importEquipes()
        evenements = Evenement.EvenementRepository(connection).getEvenementByRencontreId(int(id))
        compositions = Composition.CompositionRepository(connection).getCompositionsByRencontreId(int(id))
        db.close()
        return main.render(joueurs=joueurs, rencontre=rencontre, equipes=equipes, evenements=evenements, compositions=compositions, joueurs_eve=joueurs_eve)

    @cherrypy.expose
    def classement(self):
        main = mylookup.get_template('classement.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        equipes = Equipe.EquipeRepository(connection).trierEquipeParPoints()
        db.close()
        return main.render(equipes=equipes)

    @cherrypy.expose
    def classement_matchNb(self):
        main = mylookup.get_template('classement.html')
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        equipes = Equipe.EquipeRepository(connection).trierEquipeParNbMatchJoue()
        db.close()
        return main.render(equipes=equipes)


    @cherrypy.expose
    def add_equipe(self, nom, ville, stade, logo):
        photo_file = logo.file
        temp_path = photo_file.name

        # Extraire l'extension du fichier photo
        _, ext = os.path.splitext(logo.filename)

        # Générer le nouveau nom de fichier en utilisant "Nom_Prenom" format
        nouveau_nom = f"{ville.capitalize()}{ext}"

        # Déterminer le répertoire de destination pour la photo
        dest_dir = os.path.join(os.path.dirname(__file__), 'image', 'equipe')
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)

        # Déplacer le fichier photo vers le répertoire de destination en utilisant le nouveau nom de fichier
        dest_path = os.path.join(dest_dir, nouveau_nom)
        with open(dest_path, 'wb') as f:
            while True:
                data = photo_file.read(8192)
                if not data:
                    break
                f.write(data)
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        last_id = Equipe.EquipeRepository(connection).getIDLastEquipe()
        Equipe.EquipeRepository(connection).addEquipe(Equipe.Equipe(last_id, f"'{nom}'", f"'{ville}'", f"'image/equipe/{nouveau_nom}'", f"'{stade}'"))
        db.close()
        raise cherrypy.HTTPRedirect("/classement")

    @cherrypy.expose
    def suppr_equipe(self, id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        Equipe.EquipeRepository(connection).deleteEquipe(int(id))
        db.close()
        raise cherrypy.HTTPRedirect("/classement")

    @cherrypy.expose
    def modif_equipe(self, id, nom, ville, stade, logo):
        photo_file = logo.file

        _, ext = os.path.splitext(logo.filename)

        nouveau_nom = f"{ville.capitalize()}{ext}"

        dest_dir = os.path.join(os.path.dirname(__file__), 'image', 'equipe')
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)

        dest_path = os.path.join(dest_dir, nouveau_nom)
        with open(dest_path, 'wb') as f:
            while True:
                data = photo_file.read(8192)
                if not data:
                    break
                f.write(data)
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        Equipe.EquipeRepository(connection).updateEquipe(Equipe.Equipe(int(id), f"'{nom}'", f"'{ville}'", f"'image/equipe/{nouveau_nom}'", f"'{stade}'"))
        db.close()
        raise cherrypy.HTTPRedirect("/classement")
    

    @cherrypy.expose
    def ajouter_score_suivi(self, rencontre_id, equipe_suivi_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        score_suivi = Rencontre.RencontreRepository(connection).getScoreSuiviByRencontreId(int(rencontre_id))
        score_suivi += 1
        Rencontre.RencontreRepository(connection).updateScoreSuiviByRencontreId(int(rencontre_id), score_suivi)
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")

    @cherrypy.expose
    def ajouter_score_adverse(self, rencontre_id, equipe_adverse_id):
        connection = RugbyClub.getConnection(self)
        connection.connect()
        db = connection.getDb()
        score_adverse = Rencontre.RencontreRepository(connection).getScoreAdverseByRencontreId(int(rencontre_id))
        score_adverse += 1
        Rencontre.RencontreRepository(connection).updateScoreAdverseByRencontreId(int(rencontre_id), score_adverse)
        db.close()
        raise cherrypy.HTTPRedirect(f"/fiche?id={rencontre_id}")





if __name__ == '__main__':
    connection = Connection.Connection.from_config_file("config.txt")
    connection.connect()
    db = connection.getDb()
    cursor = connection.getCursor()
    Jeu.Jeu.CreateJeu("fonction/jeu.csv")

    rootPath = os.path.abspath(os.getcwd())
    print(f"la racine du site est :\n\t{rootPath}\n\tcontient : {os.listdir()}")
    conf = {
         '/': {
            'tools.staticdir.root': rootPath,   
            },
        '/image': {
            'tools.staticdir.on': True,         
            'tools.staticdir.dir': './image'
        },
        '/css': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './css'
        },
        '/fonction': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './fonction'
        },
        '/js': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './js'
        }
    }
    cherrypy.quickstart(RugbyClub(), '/', config=conf)
    
