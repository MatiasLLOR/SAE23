import pymysql
import pymysql.cursors
from fonction import Connection, Joueur, Equipe, Evenement, Composition
from tabulate import tabulate
from datetime import datetime


class Rencontre():
    def __init__(self, id, score_suivi, score_adverse, domicile, resultat, equipe_suivi_id, equipe_adverse_id, date):
        self.id = id
        self.score_suivi = score_suivi
        self.score_adverse = score_adverse
        self.domicile = domicile
        self.resultat = resultat
        self.equipe_suivi_id = equipe_suivi_id
        self.equipe_adverse_id = equipe_adverse_id
        self.date = date
        self.equipe_nom_suivi = Equipe.EquipeRepository(Connection.Connection.from_config_file("config.txt")).getEquipeById(equipe_suivi_id).getNom()
        self.equipe_nom_adverse = Equipe.EquipeRepository(Connection.Connection.from_config_file("config.txt")).getEquipeById(equipe_adverse_id).getNom()
        self.logo_suivi = Equipe.EquipeRepository(Connection.Connection.from_config_file("config.txt")).getEquipeById(equipe_suivi_id).getLogo()
        self.logo_adverse = Equipe.EquipeRepository(Connection.Connection.from_config_file("config.txt")).getEquipeById(equipe_adverse_id).getLogo()

    
    def getId(self) -> int:
        return self.id
    
    def getScoreSuivi(self) -> int:
        return self.score_suivi
    
    def getScoreAdverse(self) -> int:
        return self.score_adverse
    
    def getDomicile(self) -> bool:
        return self.domicile
    
    def getResultat(self) -> str:
        return self.resultat
    
    def getEquipeSuiviId(self) -> int:
        return self.equipe_suivi_id
    
    def getEquipeAdverseId(self) -> int:
        return self.equipe_adverse_id
    
    def getDate(self) -> str:
        return self.date
    
    def setScoreSuivi(self, score_suivi) -> None:
        self.score_suivi = score_suivi
    
    def setScoreAdverse(self, score_adverse) -> None:
        self.score_adverse = score_adverse
    
    def setDomicile(self, domicile) -> None:
        self.domicile = domicile
    
    def setResultat(self, resultat) -> None:
        self.resultat = resultat
    
    def setEquipeSuiviId(self, equipe_suivi_id) -> None:
        self.equipe_suivi_id = equipe_suivi_id
    
    def setEquipeAdverseId(self, equipe_adverse_id) -> None:
        self.equipe_adverse_id = equipe_adverse_id

    def setDate(self, date) -> None:
        self.date = date


class RencontreRepository():
    def __init__(self, connection: Connection.Connection):
        self.db = connection.getDb()
        self.cursor = connection.getCursor()
        self.rencontres = self.importRencontres()
        self.equipeRepository = Equipe.EquipeRepository(connection)

    def importRencontres(self) -> list:
        self.cursor.execute("SELECT * FROM Matchs")
        result = self.cursor.fetchall()
        rencontres = []
        for row in result:
            rencontres.append(Rencontre(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7]))
        return rencontres
    
    def getIdLastRencontre(self) -> int:
        self.cursor.execute("SELECT MAX(match_id) FROM Matchs")
        try:
            return int(self.cursor.fetchone()[0]) + 1
        except TypeError as e:
            return 1
        
    def getRencontres(self) -> list:
        return self.rencontres
    
    def getRencontreById(self, id) -> Rencontre:
        for rencontre in self.rencontres:
            if rencontre.getId() == id:
                return rencontre
        return None
    
    def getRencontresByEquipeId(self, equipe_id) -> list:
        rencontres = []
        for rencontre in self.rencontres:
            if rencontre.getEquipeSuiviId() == equipe_id or rencontre.getEquipeAdverseId() == equipe_id:
                rencontres.append(rencontre)
        return rencontres

    def getScoreSuiviByRencontreId(self, id) -> int:
        for rencontre in self.rencontres:
            if rencontre.getId() == id:
                return rencontre.getScoreSuivi()
        return None

    def getScoreAdverseByRencontreId(self, id) -> int:
        for rencontre in self.rencontres:
            if rencontre.getId() == id:
                return rencontre.getScoreAdverse()
        return None
    
    def addRencontre(self, rencontre : Rencontre) -> None:
        self.cursor.execute("INSERT INTO Matchs (score_suivi, score_adverse, domicile, resultat, equipe_suivi, equipe_adverse, date) VALUES (%s, %s, %s, %s, %s, %s, %s)", (rencontre.getScoreSuivi(), rencontre.getScoreAdverse(), rencontre.getDomicile(), rencontre.getResultat(), rencontre.getEquipeSuiviId(), rencontre.getEquipeAdverseId(), rencontre.getDate()))
        self.db.commit()
        self.rencontres = self.importRencontres()

    def updateRencontre(self, rencontre : Rencontre) -> None:
        query = f"UPDATE Matchs SET score_suivi = {rencontre.getScoreSuivi()}, score_adverse = {rencontre.getScoreAdverse()}, domicile = {rencontre.getDomicile()}, resultat = '{rencontre.getResultat()}', equipe_suivi = {rencontre.getEquipeSuiviId()}, equipe_adverse = {rencontre.getEquipeAdverseId()}, date = '{rencontre.getDate()}' WHERE match_id = {rencontre.getId()}"
        self.cursor.execute(query)
        #self.cursor.execute("UPDATE Matchs SET score_suivi = %s, score_adverse = %s, domicile = %s, resultat = '%s', equipe_suivi_id = %s, equipe_adverse_id = %s WHERE match_id = %s", (rencontre.getScoreSuivi(), rencontre.getScoreAdverse(), rencontre.getDomicile(), rencontre.getResultat(), rencontre.getEquipeSuiviId(), rencontre.getEquipeAdverseId(), rencontre.getId()))

        self.db.commit()
        self.rencontres = self.importRencontres()

    def updateScoreSuiviByRencontreId(self, id, score) -> None:
        self.cursor.execute("UPDATE Matchs SET score_suivi = %s WHERE match_id = %s", (score, id))
        self.db.commit()
        self.rencontres = self.importRencontres()

    def updateScoreAdverseByRencontreId(self, id, score) -> None:
        self.cursor.execute("UPDATE Matchs SET score_adverse = %s WHERE match_id = %s", (score, id))
        self.db.commit()
        self.rencontres = self.importRencontres()

    def deleteRencontre(self, id) -> None:
        self.cursor.execute("DELETE FROM Matchs WHERE match_id = %s", (id))
        self.db.commit()
        self.rencontres = self.importRencontres()


    def trierMatchParDate(self) -> list:
        return sorted(self.rencontres, key=lambda x: x.getDate())
    
    def trierMatchParDateInverse(self) -> list:
        return sorted(self.rencontres, key=lambda x: x.getDate(), reverse=True)
    
    def trierMatchParEquipe(self) -> list:
        return sorted(self.rencontres, key=lambda x: x.getEquipeAdverseId())

    def trierMatchAVenir(self) -> list:
        rencontres = []
        for rencontre in self.rencontres:
            if rencontre.getDate() >= datetime.now().strftime("%Y-%m-%d"):
                rencontres.append(rencontre)
        return rencontres

    def trierMatchPasser(self) -> list:
        rencontres = []
        for rencontre in self.rencontres:
            if rencontre.getDate() < datetime.now().strftime("%Y-%m-%d"):
                rencontres.append(rencontre)
        return rencontres
    
    @staticmethod
    def FormatTabulateRencontre(rencontres) -> str:
        return tabulate(rencontres, headers=["Id", "Score Suivi", "Score Adverse", "Domicile", "Resultat", "Equipe Suivi Id", "Equipe Adverse Id", "Date"], tablefmt="fancy_grid", stralign="center", numalign="center")
    
    def ObjectToList(self, rencontre : Rencontre) -> list:
        return [rencontre.getId(), rencontre.getScoreSuivi(), rencontre.getScoreAdverse(), rencontre.getDomicile(), rencontre.getResultat(), rencontre.getEquipeSuiviId(), rencontre.getEquipeAdverseId(), rencontre.getDate()]
    
    def ObjectListToListList(self, rencontres : list) -> list:
        rencontresList = []
        for rencontre in rencontres:
            rencontresList.append(self.ObjectToList(rencontre))
        return rencontresList