import pymysql
import pymysql.cursors
from fonction import Connection, Joueur, Equipe, Rencontre, Composition
from tabulate import tabulate
import inquirer

'''
CREATE TABLE Evenement (
    evenement_id INT PRIMARY KEY AUTO_INCREMENT,
    type_evenement VARCHAR(255),
    minute INT(3),
    match_id INT(3),
    joueur_id INT(3),
    FOREIGN KEY (match_id) REFERENCES Matchs(match_id),
    FOREIGN KEY (joueur_id) REFERENCES Joueur(joueur_id)
);"""
'''

connection = Connection.Connection.from_config_file("config.txt")

class Evenement:
    def __init__(self, id, type_evenement, minute, match_id, joueur_id):
        self.id = id
        self.type_evenement = type_evenement
        self.minute = minute
        self.match_id = match_id
        self.joueur_id = joueur_id
        self.joueurs = Joueur.JoueurRepository(connection)
    
    def getId(self):
        return self.id
    
    def getType(self):
        return self.type_evenement
    
    def getMinute(self):
        return self.minute
    
    def getMatchId(self):
        return self.match_id
    
    def getJoueurId(self):
        return self.joueur_id
    
    def setType(self, type_evenement):
        self.type_evenement = type_evenement

    def setMinute(self, minute):
        self.minute = minute

    def setMatchId(self, match_id):
        self.match_id = match_id

    def setJoueurId(self, joueur_id):
        self.joueur_id = joueur_id


class EvenementRepository():
    def __init__(self, connection : Connection.Connection):
        self.db = connection.getDb()
        self.cursor = connection.getCursor()
        self.evenements = self.importEvenements()
        self.joueurRepository = Joueur.JoueurRepository(connection)
        self.matchRepository = Rencontre.RencontreRepository(connection)

    def importEvenements(self) -> list:
        evenements = []
        self.cursor.execute("SELECT * FROM Evenement")
        for row in self.cursor:
            evenements.append(Evenement(row[0], row[1], row[2], row[3], row[4]))
        return evenements

    def getIDLastEvenement(self) -> int:
        self.cursor.execute("SELECT MAX(evenement_id) FROM Evenement")
        try:
            return int(self.cursor.fetchone()[0]) + 1
        except TypeError as e:
            return 1
    
    def getEvenements(self) -> list:
        return self.evenements
    
    def getEvenementById(self, id) -> Evenement:
        for evenement in self.evenements:
            if evenement.getId() == id:
                return evenement
        return None
    
    def getTypeByEvenementId(self, id) -> str:
        for evenement in self.evenements:
            if evenement.getId() == id:
                return evenement.getType()
        return None
    
    def getEvenementByRencontreId(self, match_id) -> list:
        evenements = []
        for evenement in self.evenements:
            if evenement.getMatchId() == match_id:
                evenements.append(evenement)
        evenements = sorted(evenements, key=lambda evenement: (evenement.getType(), evenement.getMinute()))
        evenements = sorted(evenements, key=lambda evenement: evenement.getType(), reverse=True)
        return evenements
    
    def getEvenementByType(self, type_evenement) -> Evenement:
        for evenement in self.evenements:
            if evenement.getType() == type_evenement:
                return evenement
        return None
    
    def getEvenementByMinute(self, minute) -> Evenement:
        for evenement in self.evenements:
            if evenement.getMinute() == minute:
                return evenement
        return None
    
    def getEvenementByMatchId(self, match_id) -> Evenement:
        for evenement in self.evenements:
            if evenement.getMatchId() == match_id:
                return evenement
        return None
    
    def getEvenementByJoueurId(self, joueur_id) -> Evenement:
        for evenement in self.evenements:
            if evenement.getJoueurId() == joueur_id:
                return evenement
        return None
    
    def addEvenement(self, evenement : Evenement) -> None:
        self.evenements.append(evenement)
        self.cursor.execute(f"INSERT INTO Evenement (type_evenement, minute, match_id, joueur_id) VALUES ('{str(evenement.getType())}', {evenement.getMinute()}, {evenement.getMatchId()}, {evenement.getJoueurId()})")
        self.db.commit()

    def updateEvenement(self, evenement : Evenement) -> None:
        self.cursor.execute(f"UPDATE Evenement SET type_evenement = '{evenement.getType()}', minute = {evenement.getMinute()}, match_id = {evenement.getMatchId()}, joueur_id = {evenement.getJoueurId()} WHERE evenement_id = {evenement.getId()}")
        self.db.commit()

    def deleteEvenement(self, id) -> None:
        self.cursor.execute(f"DELETE FROM Evenement WHERE evenement_id = {id}")
        self.db.commit()
        
    
    def trierEvenementParType(self) -> list:
        return sorted(self.evenements, key=lambda evenement: evenement.getType())
    
    def trierEvenementParMinute(self) -> list:
        return sorted(self.evenements, key=lambda evenement: evenement.getMinute())
    
    def trierEvenementParMatch(self) -> list:
        return sorted(self.evenements, key=lambda evenement: evenement.getMatchId())

    @staticmethod
    def FormatTabulateEvenement(evenements) -> str:
        return tabulate(evenements, headers=["ID", "Type", "Minute", "Match ID", "Joueur ID"], tablefmt="fancy_grid", stralign="center", numalign="center")
    
    def ObjectToList(self, evenement : Evenement) -> list:
        return [evenement.getId(), evenement.getType(), evenement.getMinute(), evenement.getMatchId(), evenement.getJoueurId()]
    
    def ObjectListToListList(self, evenements : list) -> list:
        evenementsList = []
        for evenement in evenements:
            evenementsList.append(self.ObjectToList(evenement))
        return evenementsList