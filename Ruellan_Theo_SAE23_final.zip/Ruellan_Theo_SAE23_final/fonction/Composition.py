import pymysql
import pymysql.cursors
from fonction import Connection, Joueur, Equipe, Rencontre, Evenement
from tabulate import tabulate
import inquirer

'''
CREATE TABLE Composition (
    compo_id INT PRIMARY KEY AUTO_INCREMENT,
    numero_maillot INT(2),
    match_id INT(3),
    joueur_id INT(3),
    FOREIGN KEY (match_id) REFERENCES Matchs(match_id),
    FOREIGN KEY (joueur_id) REFERENCES Joueur(joueur_id)
);
'''

connection = Connection.Connection.from_config_file("config.txt")

class Composition():
    def __init__(self, id, numero_maillot, match_id, joueur_id):
        self.id = id
        self.numero_maillot = numero_maillot
        self.match_id = match_id
        self.joueur_id = joueur_id
        self.joueurs = Joueur.JoueurRepository(connection)

    def getId(self) -> int:
        return self.id

    def getNumeroMaillot(self) -> int:
        return self.numero_maillot

    def getMatchId(self) -> int:
        return self.match_id

    def getJoueurId(self) -> int:
        return self.joueur_id

    def setNumeroMaillot(self, numero_maillot) -> None:
        self.numero_maillot = numero_maillot

    def setMatchId(self, match_id) -> None:
        self.match_id = match_id

    def setJoueurId(self, joueur_id) -> None:
        self.joueur_id = joueur_id


class CompositionRepository():
    def __init__(self, connection : Connection.Connection):
        self.db = connection.getDb()
        self.cursor = connection.getCursor()
        self.compositions = self.importCompositions()
        self.rencontreRepository = Rencontre.RencontreRepository(connection)
        self.joueurRepository = Joueur.JoueurRepository(connection)

    def importCompositions(self) -> list:
        self.cursor.execute("SELECT * FROM Composition ")
        compositions = []
        for row in self.cursor:
            compositions.append(Composition(row[0], row[1], row[2], row[3]))
        return compositions
    
    def getIDLastComposition(self) -> int:
        self.cursor.execute("SELECT MAX(compo_id) FROM Composition")
        return self.cursor.fetchone()[0]+1

    def getCompositions(self) -> list:
        return self.compositions

    def getCompositionById(self, id) -> Composition:
        for composition in self.compositions:
            if composition.getId() == id:
                return composition

    def getCompositionsByRencontreId(self, match_id) -> list:
        compositions = []
        for composition in self.compositions:
            if composition.getMatchId() == match_id:
                compositions.append(composition)
        return compositions
    
    def getCompositionIDByRencontreIdAndNumeroMaillot(self, match_id, numero_maillot) -> int:
        for composition in self.compositions:
            if composition.getMatchId() == match_id and composition.getNumeroMaillot() == numero_maillot:
                return composition.getId()

    def addComposition(self, composition : Composition) -> None:
        self.cursor.execute(f"INSERT INTO Composition (numero_maillot,match_id,joueur_id) VALUES ({composition.getNumeroMaillot()}, {composition.getMatchId()}, {composition.getJoueurId()})")
        self.db.commit()
        self.compositions = self.importCompositions()

    def updateComposition(self, composition : Composition) -> None:
        self.cursor.execute(f"UPDATE Composition SET numero_maillot = {composition.getNumeroMaillot()}, match_id = {composition.getMatchId()}, joueur_id = {composition.getJoueurId()} WHERE compo_id = {composition.getId()}")
        self.db.commit()
        self.compositions = self.importCompositions()

    def deleteComposition(self, id) -> None:
        self.cursor.execute(f"DELETE FROM Composition WHERE compo_id = {id}")
        self.db.commit()
        self.compositions = self.importCompositions()

    def deleteCompositionsByRencontreId(self, rencontre_id) -> None:
        self.cursor.execute(f"DELETE FROM Composition WHERE match_id = {rencontre_id}")
        self.db.commit()
        self.compositions = self.importCompositions()


    def trierCompositionParMatch(self) -> list:
        return sorted(self.compositions, key=lambda composition: composition.getMatchId())
    
    def trierCompositionParJoueur(self) -> list:
        return sorted(self.compositions, key=lambda composition: composition.getJoueurId())
    

    @staticmethod
    def FormatTabulateComposition(compositions) -> str:
        return tabulate(compositions, headers=["Id", "Numero maillot", "Match id", "Joueur id"], tablefmt="fancy_grid", stralign="center", numalign="center")
    
    def ObjectToList(self, composition : Composition) -> list:
        return [composition.getId(), composition.getNumeroMaillot(), composition.getMatchId(), composition.getJoueurId()]
    
    def ObjectListToListList(self, compositions : list) -> list:
        compositionsList = []
        for composition in compositions:
            compositionsList.append(self.ObjectToList(composition))
        return compositionsList