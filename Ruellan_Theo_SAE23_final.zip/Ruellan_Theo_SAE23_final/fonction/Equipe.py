from sqlite3 import connect
import pymysql
import pymysql.cursors
from fonction import Connection, Joueur, Rencontre, Evenement, Composition
from tabulate import tabulate
import inquirer

connection = Connection.Connection.from_config_file("config.txt")

class Equipe():
    def __init__(self, id, nom, ville, logo, stade):
        self.id = id
        self.nom = nom
        self.ville = ville
        self.logo = logo
        self.stade = stade
    
    def getId(self) -> int:
        return self.id
    
    def getNom(self) -> str:
        return self.nom
    
    def getVille(self) -> str:
        return self.ville
    
    def getLogo(self) -> str:
        return self.logo
    
    def getStade(self) -> str:
        return self.stade

    @staticmethod
    def getRencontreByequipeId(equipe_id) -> int:
        cursor = connection.getCursor()
        cursor.execute("SELECT Matchs.match_id, Matchs.resultat FROM Equipe JOIN Matchs ON Equipe.equipe_id = Matchs.equipe_adverse WHERE Equipe.equipe_id = %s", (equipe_id))
        result = cursor.fetchall()
        rencontres = []
        for row in result:
            rencontres.append((row[0], row[1]))
        cursor.execute("SELECT Matchs.match_id, Matchs.resultat FROM Equipe JOIN Matchs ON Equipe.equipe_id = Matchs.equipe_suivi WHERE Equipe.equipe_id = %s", (equipe_id))
        result = cursor.fetchall()
        for row in result:
            rencontres.append((row[0], row[1]))
        cursor.close()
        return rencontres

    @staticmethod
    def getPointsByequipeId(equipe_id) -> int:
        points = 0
        if equipe_id == 1:
            for rencontre in Equipe.getRencontreByequipeId(equipe_id):
                if "V" in rencontre[1]:
                    points += 3
                elif "N" in rencontre[1]:
                    points += 1
        else:
            for rencontre in Equipe.getRencontreByequipeId(equipe_id):
                if "D" in rencontre[1]:
                    points += 3
                elif "N" in rencontre[1]:
                    points += 1
        return points

    @staticmethod
    def getNbMatchJoueByequipeId(equipe_id) -> int:
        return len(Equipe.getRencontreByequipeId(equipe_id))

    @staticmethod
    def getNbMatchGagneByequipeId(equipe_id) -> int:
        nbMatchGagne = 0
        if equipe_id == 1:
            for rencontre in Equipe.getRencontreByequipeId(equipe_id):
                if "V" in rencontre[1]:
                    nbMatchGagne += 1
        else:
            for rencontre in Equipe.getRencontreByequipeId(equipe_id):
                if "D" in rencontre[1]:
                    nbMatchGagne += 1
        return nbMatchGagne

    @staticmethod
    def getNbMatchNulByequipeId(equipe_id) -> int:
        nbMatchNul = 0
        for rencontre in Equipe.getRencontreByequipeId(equipe_id):
            if "N" in rencontre[1]:
                nbMatchNul += 1
        return nbMatchNul

    @staticmethod
    def getNbMatchPerduByequipeId(equipe_id) -> int:
        nbMatchPerdu = 0
        if equipe_id == 1:
            for rencontre in Equipe.getRencontreByequipeId(equipe_id):
                if "D" in rencontre[1]:
                    nbMatchPerdu += 1
        else:
            for rencontre in Equipe.getRencontreByequipeId(equipe_id):
                if "V" in rencontre[1]:
                    nbMatchPerdu += 1
        return nbMatchPerdu

    def getPoints(self) -> int:
        if self.getNbMatchJoue() == 0:
            return 1
        else:
            return Equipe.getPointsByequipeId(self.id)

    def getNbMatchJoue(self) -> int:
        return Equipe.getNbMatchJoueByequipeId(self.id)

    def getNbMatchGagne(self) -> int:
        return Equipe.getNbMatchGagneByequipeId(self.id)

    def getNbMatchNul(self) -> int:
        return Equipe.getNbMatchNulByequipeId(self.id)

    def getNbMatchPerdu(self) -> int:
        return Equipe.getNbMatchPerduByequipeId(self.id)
    
    def setNom(self, nom) -> None:
        self.nom = nom

    def setVille(self, ville) -> None:
        self.ville = ville

    def setLogo(self, logo) -> None:
        self.logo = logo

    def setStade(self, stade) -> None:
        self.stade = stade


class EquipeRepository():
    def __init__(self, connection: Connection.Connection):
        self.connection = connection
        self.equipes = self.importEquipes()

    def importEquipes(self) -> list:
        cursor = self.connection.getCursor()
        cursor.execute("SELECT * FROM Equipe")
        result = cursor.fetchall()
        equipes = []
        for row in result:
            equipes.append(Equipe(row[0], row[1], row[2], row[3], row[4]))
        return equipes

    def getEquipes(self) -> list:
        return self.importEquipes()

    def getEquipeById(self, id) -> Equipe:
        for equipe in self.equipes:
            if equipe.getId() == id:
                return equipe
        return None
    
    def getIDLastEquipe(self) -> int:
        cursor = self.connection.getCursor()
        cursor.execute("SELECT MAX(equipe_id) FROM Equipe")
        try:
            return int(cursor.fetchone()[0]) + 1
        except TypeError as e:
            return 1

    def addEquipe(self, equipe: Equipe) -> None:
        cursor = self.connection.getCursor()
        cursor.execute("INSERT INTO Equipe (nom, ville, logo, stade) VALUES (%s, %s, %s, %s)", (equipe.getNom(), equipe.getVille(), equipe.getLogo(), equipe.getStade()))
        self.connection.getDb().commit()
        cursor.close()

    def updateEquipe(self, equipe: Equipe) -> None:
        cursor = self.connection.getCursor()
        cursor.execute("UPDATE Equipe SET nom = %s, ville = %s, logo = %s, stade = %s WHERE equipe_id = %s", (equipe.getNom(), equipe.getVille(), equipe.getLogo(), equipe.getStade(), equipe.getId()))
        self.connection.getDb().commit()
        cursor.close()

    def deleteEquipe(self, id) -> None:
        cursor = self.connection.getCursor()
        cursor.execute("DELETE FROM Equipe WHERE equipe_id = %s", (id))
        self.connection.getDb().commit()
        cursor.close()
    
    def trierEquipeParOrdreAlphabetique(self) -> list:
        return sorted(self.equipes, key=lambda equipe: equipe.getNom())
    
    def trierEquipeParOrdreAlphabetiqueInverse(self) -> list:
        return sorted(self.equipes, key=lambda equipe: equipe.getNom(), reverse=True)

    def trierEquipeParPoints(self) -> list:
        return sorted(self.equipes, key=lambda equipe: equipe.getPoints(), reverse=True)

    def trierEquipeParNbMatchJoue(self) -> list:
        return sorted(self.equipes, key=lambda equipe: equipe.getNbMatchJoue(), reverse=True)



    
    @staticmethod
    def FormatTabulateEquipe(equipes) -> str:
        return tabulate(equipes, headers=["ID", "Nom", "Ville", "Logo", "Stade"], tablefmt="fancy_grid", stralign="center", numalign="center")
    
    def ObjectToList(self, equipe : Equipe) -> list:
        return [equipe.getId(), equipe.getNom(), equipe.getVille(), equipe.getLogo(), equipe.getStade()]
    
    def ObjectListToListList(self, equipes : list) -> list:
        equipesList = []
        for equipe in equipes:
            equipesList.append(self.ObjectToList(equipe))
        return equipesList

    