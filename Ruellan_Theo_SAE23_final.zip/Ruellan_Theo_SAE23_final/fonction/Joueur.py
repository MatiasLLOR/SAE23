import pymysql
import pymysql.cursors
from tabulate import tabulate
from fonction import Connection, Equipe, Rencontre, Evenement, Composition
import inquirer
from datetime import datetime

connection = Connection.Connection.from_config_file("config.txt")

class Joueur():
    def __init__(self, id, nom, prenom, age, poste, taille, poids, date_naissance, nationalite, photo_url, equipe_id):
        self.id = id
        self.nom = nom
        self.prenom = prenom
        self.age = age
        self.poste = poste
        self.taille = taille
        self.poids = poids
        self.date_naissance = date_naissance
        self.nationalite = nationalite
        self.photo_url = photo_url
        self.equipe_id = equipe_id
    
    def getId(self) -> int:
        return self.id
    
    def getNom(self) -> str:
        return self.nom
    
    def getPrenom(self) -> str:
        return self.prenom
    
    def getAge(self) -> int:
        return self.age
    
    def getPoste(self) -> str:
        return self.poste
    
    def getTaille(self) -> float:
        return self.taille
    
    def getPoids(self) -> int:
        return self.poids
    
    def getDateNaissance(self) -> str:
        return self.date_naissance
    
    def getNationalite(self) -> str:
        return self.nationalite
    
    def getPhotoUrl(self) -> str:
        return self.photo_url
    
    def getEquipeId(self) -> int:
        return self.equipe_id
    
    @staticmethod
    def getNbMatchsByJoueur_id(id) -> int:
        cursor = connection.getCursor()
        cursor.execute("SELECT COUNT(*) FROM Composition WHERE joueur_id = %s", id)
        return int(cursor.fetchone()[0])
    
    @staticmethod
    def getNbEssaisByJoueur_id(id) -> int:
        cursor = connection.getCursor()
        cursor.execute("SELECT COUNT(*) FROM Evenement WHERE joueur_id = %s AND type_evenement = 'Essai'", id)
        return int(cursor.fetchone()[0])
    
    @staticmethod
    def getNbTransformationByJoueur_id(id) -> int:
        cursor = connection.getCursor()
        cursor.execute("SELECT COUNT(*) FROM Evenement WHERE joueur_id = %s AND type_evenement = 'Transformation'", id)
        return int(cursor.fetchone()[0])
    
    @staticmethod
    def getNbDropByJoueur_id(id) -> int:
        cursor = connection.getCursor()
        cursor.execute("SELECT COUNT(*) FROM Evenement WHERE joueur_id = %s AND type_evenement = 'Drop'", id)
        return int(cursor.fetchone()[0])
    
    @staticmethod
    def getNbCartonJauneByJoueur_id(id) -> int:
        cursor = connection.getCursor()
        cursor.execute("SELECT COUNT(*) FROM Evenement WHERE joueur_id = %s AND type_evenement = 'Carton Jaune'", id)
        return int(cursor.fetchone()[0])
    
    @staticmethod
    def getNbCartonRougeByJoueur_id(id) -> int:
        cursor = connection.getCursor()
        cursor.execute("SELECT COUNT(*) FROM Evenement WHERE joueur_id = %s AND type_evenement = 'Carton Rouge'", id)
        return int(cursor.fetchone()[0])

    
    def setNom(self, nom) -> None:
        self.nom = nom

    def setPrenom(self, prenom) -> None:
        self.prenom = prenom

    def setAge(self, age) -> None:
        self.age = age

    def setPoste(self, poste) -> None:
        self.poste = poste

    def setTaille(self, taille) -> None:
        self.taille = taille

    def setPoids(self, poids) -> None:
        self.poids = poids

    def setDateNaissance(self, date_naissance) -> None:
        self.date_naissance = date_naissance

    def setNationalite(self, nationalite) -> None:
        self.nationalite = nationalite

    def setPhotoUrl(self, photo_url) -> None:
        self.photo_url = photo_url

    def setEquipeId(self, equipe_id) -> None:
        self.equipe_id = equipe_id


class JoueurRepository():
    def __init__(self, connection : Connection.Connection):
        self.db = connection.getDb()
        self.cursor = connection.getCursor()
        self.joueurs = self.importJoueurs()
        self.equipeRepository = Equipe.EquipeRepository(connection)

    def importJoueurs(self) -> list:
        self.cursor.execute("SELECT * FROM Joueur")
        joueurs = []
        for joueur in self.cursor.fetchall():
            joueurs.append(Joueur(joueur[0], joueur[1], joueur[2], joueur[3], joueur[4], joueur[5], joueur[6], joueur[7], joueur[8], joueur[9], joueur[10]))
        return joueurs
    
    def getIDLastJoueur(self) -> int:
        self.cursor.execute("SELECT MAX(joueur_id) FROM Joueur")
        try:
            return int(self.cursor.fetchone()[0]) + 1
        except TypeError as e:
            return 1
    
    def getJoueurs(self) -> list:
        return self.joueurs
    
    def getJoueurById(self, id) -> Joueur:
        for joueur in self.joueurs:
            if joueur.getId() == id:
                return joueur
        return None
    
    def getJoueurByNom(self, nom) -> Joueur:
        for joueur in self.joueurs:
            if joueur.getNom() == nom:
                return joueur
        return None
    
    def getJoueurByAge(self, age) -> Joueur:
        for joueur in self.joueurs:
            if joueur.getAge() == age:
                return joueur
        return None
    
    def getJoueurByPoste(self, poste) -> Joueur:
        for joueur in self.joueurs:
            if joueur.getPoste() == poste:
                return joueur
        return None
    
    def getJoueurByPostes(self, postes) -> list:
        joueurs = []
        for joueur in self.joueurs:
            if joueur.getPoste() in postes:
                joueurs.append(joueur)
        joueurs.sort(key=lambda x: x.getPoste())
        return joueurs
    
    def getJoueurByEquipeId(self, equipe_id) -> Joueur:
        for joueur in self.joueurs:
            if joueur == equipe_id:
                return joueur
        return None
    
    def addJoueur(self, joueur : Joueur) -> None:
        self.cursor.execute("INSERT INTO Joueur (nom, prenom, age, poste, taille, poids, date_naissance, nationalite, photo_url, equipe_id) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (joueur.getNom(), joueur.getPrenom(), joueur.getAge(), joueur.getPoste(), joueur.getTaille(), joueur.getPoids(), joueur.getDateNaissance(), joueur.getNationalite(), joueur.getPhotoUrl(), joueur.getEquipeId()))
        self.db.commit()
        self.joueurs.append(joueur)

    def updateJoueur(self, joueur : Joueur) -> None:
        self.cursor.execute("UPDATE Joueur SET nom = %s, prenom = %s, age = %s, poste = %s, taille = %s, poids = %s, date_naissance = %s, nationalite = %s, photo_url = %s, equipe_id = %s WHERE joueur_id = %s", (joueur.getNom(), joueur.getPrenom(), joueur.getAge(), joueur.getPoste(), joueur.getTaille(), joueur.getPoids(), joueur.getDateNaissance(), joueur.getNationalite(), joueur.getPhotoUrl(), joueur.getEquipeId(), joueur.getId()))
        self.db.commit()
        self.joueurs = self.importJoueurs()

    def deleteJoueur(self, id) -> None:
        self.cursor.execute("DELETE FROM Joueur WHERE joueur_id = %s", (id))
        self.db.commit()
        self.joueurs = self.importJoueurs()

    def transfKwargIntoPoste(self, dico) -> list:
        postes = []
        for poste in dico.keys():
            if poste == "talonneur":
                postes.append("Talonneur")
            elif poste == "pilier_droit":
                postes.append("Pilier Droit")
            elif poste == "pilier_gauche":
                postes.append("Pilier Gauche")
            elif poste == "deuxieme_ligne":
                postes.append("Deuxième Ligne")
            elif poste == "troisieme_ligne":
                postes.append("Troisième Ligne")
            elif poste == "demi_de_melee":
                postes.append("Demi de mêlée")
            elif poste == "demi_d_ouverture":
                postes.append("Demi d'ouverture")
            elif poste == "trois_quarts_aile":
                postes.append("Trois-Quarts Aile")
            elif poste == "trois_quarts_centre":
                postes.append("Trois-Quarts Centre")
            elif poste == "arriere":
                postes.append("Arrière")
            elif poste == "tout":
                postes.append("Talonneur")
                postes.append("Pilier Droit")
                postes.append("Pilier Gauche")
                postes.append("Deuxième Ligne")
                postes.append("Troisième Ligne")
                postes.append("Demi de mêlée")
                postes.append("Demi d'ouverture")
                postes.append("Trois-Quarts Aile")
                postes.append("Trois-Quarts Centre")
                postes.append("Arrière") 
        return postes



    def trierJoueurParAge(self) -> list:
        return sorted(self.joueurs, key=lambda joueur: joueur.getAge())
    

    def trierJoueurParOrdreAlphabetique(self) -> list:
        return sorted(self.joueurs, key=lambda joueur: joueur.getNom())
    

    def trierJoueurParOrdreAlphabetiqueInverse(self) -> list:
        return sorted(self.joueurs, key=lambda joueur: joueur.getNom(), reverse=True)
    

    def trierJoueurParPoste(self) -> list:
        return sorted(self.joueurs, key=lambda joueur: joueur.getPoste())
    

    def trierJoueurParEquipe(self) -> list:
        return sorted(self.joueurs, key=lambda joueur: joueur.getEquipeId())
    

    def trierJoueurParAge_min_max(self, age_min, age_max) -> list:
        joueurs = []
        for joueur in self.joueurs:
            if int(joueur.getAge()) >= int(age_min) and int(joueur.getAge()) <= int(age_max):
                joueurs.append(joueur)
        return joueurs


    @staticmethod
    def FormatTabulateJoueur(joueurs) -> str:
        return tabulate(joueurs, headers=["Id", "Nom", "Prenom", "Age", "Poste", "Taille", "Poids", "Date de naissance", "Nationalite", "Photo", "Equipe"], tablefmt="fancy_grid", stralign="center", numalign="center")


    def ObjectToList(self, joueur : Joueur) -> list:
        return [joueur.getId(), joueur.getNom(), joueur.getPrenom(), joueur.getAge(), joueur.getPoste(), joueur.getTaille(), joueur.getPoids(), joueur.getDateNaissance(), joueur.getNationalite(), joueur.getPhotoUrl(), joueur.getEquipeId()]


    def ObjectListToListList(self, joueurs : list) -> list:
        list_list = []
        for joueur in joueurs:
            list_list.append(self.ObjectToList(joueur))
        return list_list
    

    def CalcAge(self, date_naissance) -> int:
        return int((datetime.now() - date_naissance).days / 365.25)
    
    def getJoueurByRencontreIdINComposition(self, rencontre_id) -> list:
        joueurs = []
        self.cursor.execute("SELECT Joueur.* FROM Joueur JOIN Composition ON Joueur.joueur_id = Composition.joueur_id WHERE Composition.match_id = %s", rencontre_id)
        for joueur in self.cursor.fetchall():
            joueurs.append(Joueur(joueur[0], joueur[1], joueur[2], joueur[3], joueur[4], joueur[5], joueur[6], joueur[7], joueur[8], joueur[9], joueur[10]))
        return joueurs