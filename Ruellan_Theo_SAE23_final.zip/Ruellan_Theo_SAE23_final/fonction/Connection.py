import pymysql
import pymysql.cursors
import os


class Connection():
    def __init__(self, host=None, user=None, password=None, nom_db=None):
        self.host = host
        self.user = user
        self.password = password
        self.nom_db = nom_db
        self.db = None
        
    def connect(self) -> pymysql.Connection:
        try:
            return pymysql.connect(host=self.host, user=self.user, passwd=self.password, db=self.nom_db)
        except pymysql.err.OperationalError as e:
            print("La base de données n'existe pas, création...\n")
            Connection.CreateSQL(self)
            print("Base de données créée")
            return pymysql.connect(host=self.host, user=self.user, passwd=self.password, db=self.nom_db)

    def CreateSQL(self):
        return os.system(f"mysql -h {self.host} -u {self.user} -p{str(self.password)} < source.sql")
    
    def getDb(self):
        if self.db is None:
            self.db = self.connect()
        return self.db
    
    def getCursor(self) -> pymysql.cursors.Cursor:
        if self.db is None:
            self.db = self.connect()
        return self.db.cursor()

    @classmethod
    def from_config_file(cls, config_file):
        host, user, password, nom_db = "localhost", "admin", "admin", "sae23"
        try:
            with open(config_file) as f:
                for ligne in f:
                    if len(ligne)<5 or ligne[0] == '#':
                        continue
                    champs = ligne.split(':')
                    if 'nombase' in champs[0]:
                        nom_db = champs[1].strip()
                    elif 'host' in champs[0]:
                        host = champs[1].strip()
                    elif 'user' in champs[0]:
                        user = champs[1].strip()
                    elif 'password' in champs[0]:
                        password = champs[1].strip()
        except FileNotFoundError as e:
            pass
        return cls(host=host, user=user, password=password, nom_db=nom_db)
    
    #Ecrit une fonction qui me permet de voir si les tables dans ma base de données sont vides ou non
    def is_empty(self, table):
        cursor = self.getCursor()
        cursor.execute("SELECT * FROM " + str(table))
        result = cursor.fetchall()
        if len(result) == 0:
            return True
        else:
            return False