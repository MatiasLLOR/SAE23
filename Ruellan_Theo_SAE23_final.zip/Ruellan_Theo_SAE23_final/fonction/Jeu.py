import pymysql
import pymysql.cursors
import csv
from fonction import Connection, Joueur, Equipe, Rencontre, Evenement, Composition


class Jeu:
    def __init__(self, joueurs, equipes, matches, compositions, evenements):
        self.joueurs = joueurs
        self.equipes = equipes
        self.matches = matches
        self.compositions = compositions
        self.evenements = evenements
    
    
    @staticmethod
    def Read_csv(csv_file):
        with open(csv_file, encoding='utf-8') as f:
            return f.readlines()
        

    @staticmethod
    def ExportCSV():
        connection = Connection.Connection.from_config_file("config.txt")
        with open('export.csv', 'w', newline='', encoding='utf8') as csvfile:
            writer = csv.writer(csvfile, delimiter=',')
            writer.writerow(['joueur_id', 'nom', 'prenom', 'age', 'poste', 'taille', 'poids', 'date_naissance', 'nationalite', 'photo_url', 'equipe_id'])
            for joueur in Joueur.JoueurRepository(connection).getJoueurs():
                writer.writerow([joueur.id, joueur.nom, joueur.prenom, joueur.age, joueur.poste, joueur.taille, joueur.poids, joueur.date_naissance, joueur.nationalite, joueur.photo_url, joueur.equipe_id])
            writer.writerow(['equipe_id','nom', 'ville', 'logo', 'stade'])
            for equipe in Equipe.EquipeRepository(connection).getEquipes():
                writer.writerow([equipe.id, equipe.nom, equipe.ville, equipe.logo, equipe.stade])
            writer.writerow(['match_id', 'score_suivi', 'score_adverse', 'domicile', 'resultat', 'equipe_suivi', 'equipe_adverse', 'date'])
            for rencontre in Rencontre.RencontreRepository(connection).getRencontres():
                writer.writerow([rencontre.id, rencontre.score_suivi, rencontre.score_adverse, rencontre.domicile, rencontre.resultat, rencontre.equipe_suivi_id, rencontre.equipe_adverse_id, rencontre.date])
            writer.writerow(['compo_id', 'numero_maillot', 'match_id', 'joueur_id'])
            for compo in Composition.CompositionRepository(connection).getCompositions():
                writer.writerow([compo.id, compo.numero_maillot, compo.match_id, compo.joueur_id])
            writer.writerow(['evenement_id', 'type_evenement', 'minute', 'match_id', 'joueur_id'])
            for evenement in Evenement.EvenementRepository(connection).getEvenements():
                writer.writerow([evenement.id, evenement.type_evenement, evenement.minute, evenement.match_id, evenement.joueur_id])

        
    @staticmethod
    def ExtractJoueur(file):
        joueurs = []
        start_appending = False
        for line in Jeu.Read_csv(file):
            if "joueur_id, nom, prenom, age, poste, taille, poids, date_naissance, nationalite, photo_url, equipe_id" in line:
                start_appending = True
            elif start_appending and line == "\n":
                break
            elif start_appending:
                joueur_id, nom, prenom, age, poste, taille, poids, date_naissance, nationalite, photo_url, equipe_id = line.split(",")
                joueurs.append(Joueur.Joueur(int(joueur_id.strip()), nom.strip()[1:-1], prenom.strip()[1:-1], int(age.strip()), poste.strip()[1:-1], float(taille.strip()), int(poids.strip()), date_naissance.strip()[1:-1], nationalite.strip()[1:-1], photo_url.strip()[1:-1], int(equipe_id.strip())))
        return joueurs

    
    @staticmethod
    def ExtractEquipe(file):
        equipes = []
        start_appending = False
        for line in Jeu.Read_csv(file):
            if "equipe_id,nom,ville,logo,stade" in line:
                start_appending = True
            elif start_appending and line == "\n":
                break
            elif start_appending:
                equipe_id, nom, ville, logo, stade = line.split(",")
                equipes.append(Equipe.Equipe(int(equipe_id.strip()), nom.strip(), ville.strip(), logo.strip(), stade.strip()))
        return equipes
    
    @staticmethod
    def ExtractRencontre(file):
        matches = []
        start_appending = False
        for line in Jeu.Read_csv(file):
            if "match_id, score_suivi, score_adverse, domicile, resultat, equipe_suivi, equipe_adverse, date" in line:
                start_appending = True
            elif start_appending and line == "\n":
                break
            elif start_appending:
                match_id, score_suivi, score_adverse, domicile, resultat, equipe_suivi, equipe_adverse, date = line.split(",")
                matches.append(Rencontre.Rencontre(int(match_id.strip()), int(score_suivi.strip()), int(score_adverse.strip()), bool(domicile.strip()), resultat.strip(), int(equipe_suivi.strip()), int(equipe_adverse.strip()), date.strip()))
        return matches
    
    @staticmethod
    def ExtractComposition(file):
        compositions = []
        start_appending = False
        for line in Jeu.Read_csv(file):
            if "compo_id,numero_maillot,match_id,joueur_id" in line:
                start_appending = True
            elif start_appending and line == "\n":
                break
            elif start_appending:
                compo_id,numero_maillot,match_id,joueur_id = line.split(",")
                compositions.append(Composition.Composition(int(compo_id.strip()), int(numero_maillot.strip()), int(match_id.strip()), int(joueur_id.strip())))
        return compositions
    
    @staticmethod
    def ExtractEvenement(file):
        evenements = []
        start_appending = False
        for line in Jeu.Read_csv(file):
            if "evenement_id, type_evenement, minute, match_id, joueur_id" in line:
                start_appending = True
            elif start_appending and line == "\n":
                break
            elif start_appending:
                evenement_id, type_evenement, minute, match_id, joueur_id = line.split(",")
                evenements.append(Evenement.Evenement(int(evenement_id.strip()), type_evenement.strip(), int(minute.strip()), int(match_id.strip()), int(joueur_id.strip())))
        return evenements
    
    @staticmethod
    def addJoueurs(file):
        connection = Connection.Connection.from_config_file("config.txt")
        JoueursRepository = Joueur.JoueurRepository(connection)
        for joueur in Jeu.ExtractJoueur(file):
            JoueursRepository.addJoueur(joueur)

    @staticmethod
    def addEquipes(file):
        connection = Connection.Connection.from_config_file("config.txt")
        EquipeRepository = Equipe.EquipeRepository(connection)
        for equipe in Jeu.ExtractEquipe(file):
            EquipeRepository.addEquipe(equipe)

    @staticmethod
    def addRencontres(file):
        connection = Connection.Connection.from_config_file("config.txt")
        RencontreRepository = Rencontre.RencontreRepository(connection)
        for rencontre in Jeu.ExtractRencontre(file):
            RencontreRepository.addRencontre(rencontre)

    @staticmethod
    def addCompositions(file):
        connection = Connection.Connection.from_config_file("config.txt")
        CompositionRepository = Composition.CompositionRepository(connection)
        for compo in Jeu.ExtractComposition(file):
            CompositionRepository.addComposition(compo)

    @staticmethod
    def addEvenements(file):
        connection = Connection.Connection.from_config_file("config.txt")
        EvenementRepository = Evenement.EvenementRepository(connection)
        for evenement in Jeu.ExtractEvenement(file):
            EvenementRepository.addEvenement(evenement)

    @staticmethod
    def CreateJeu(file):
        connection = Connection.Connection.from_config_file("config.txt")
        if Connection.Connection.is_empty(connection, "Equipe"):
            try:
                Jeu.addEquipes('jeu.csv')
                print("Insertion des équipes réussie")
            except pymysql.err.IntegrityError as e:
                print("Erreur lors de l'ajout des équipes")
        if Connection.Connection.is_empty(connection, "Joueur"):
            try:
                Jeu.addJoueurs('jeu.csv')
                print("Insertion des joueurs réussie")
            except pymysql.err.IntegrityError as e:
                print("Erreur lors de l'ajout des joueurs")
        if Connection.Connection.is_empty(connection, "Matchs"):
            try:
                Jeu.addRencontres('jeu.csv')
                print("Insertion des matchs réussie")
            except pymysql.err.IntegrityError as e:
                print("Erreur lors de l'ajout des matchs")
        if Connection.Connection.is_empty(connection, "Evenement"):
            try:
                Jeu.addEvenements('jeu.csv')
                print("Insertion des évènements réussie")
            except pymysql.err.IntegrityError as e:
                print("Erreur lors de l'ajout des évènements")
        if Connection.Connection.is_empty(connection, "Composition"):
            try:
                Jeu.addCompositions('jeu.csv')
                print("Insertion des compositions réussie")
            except pymysql.err.IntegrityError as e:
                print("Erreur lors de l'ajout des compositions\n")