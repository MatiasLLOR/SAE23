CREATE DATABASE IF NOT EXISTS sae23 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

USE sae23;

CREATE TABLE `Composition` (
  `compo_id` int(11) NOT NULL,
  `numero_maillot` int(2) DEFAULT NULL,
  `match_id` int(3) DEFAULT NULL,
  `joueur_id` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Equipe` (
  `equipe_id` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `ville` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `stade` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Evenement` (
  `evenement_id` int(11) NOT NULL,
  `type_evenement` varchar(255) DEFAULT NULL,
  `minute` int(3) DEFAULT NULL,
  `match_id` int(3) DEFAULT NULL,
  `joueur_id` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Joueur` (
  `joueur_id` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `poste` varchar(255) DEFAULT NULL,
  `taille` float(3,2) DEFAULT NULL,
  `poids` int(3) DEFAULT NULL,
  `date_naissance` VARCHAR(255) DEFAULT NULL,
  `nationalite` varchar(255) DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `equipe_id` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Matchs` (
  `match_id` int(11) NOT NULL,
  `score_suivi` int(3) DEFAULT NULL,
  `score_adverse` int(3) DEFAULT NULL,
  `domicile` tinyint(1) DEFAULT NULL,
  `resultat` varchar(255) DEFAULT NULL,
  `equipe_suivi` int(3) NOT NULL DEFAULT 1,
  `equipe_adverse` int(3) NOT NULL,
  `date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `Composition`
  ADD PRIMARY KEY (`compo_id`),
  ADD KEY `match_id` (`match_id`),
  ADD KEY `joueur_id` (`joueur_id`);

ALTER TABLE `Equipe`
  ADD PRIMARY KEY (`equipe_id`);

ALTER TABLE `Evenement`
  ADD PRIMARY KEY (`evenement_id`),
  ADD KEY `match_id` (`match_id`),
  ADD KEY `joueur_id` (`joueur_id`);

ALTER TABLE `Joueur`
  ADD PRIMARY KEY (`joueur_id`),
  ADD KEY `equipe_id` (`equipe_id`);

ALTER TABLE `Matchs`
  ADD PRIMARY KEY (`match_id`),
  ADD KEY `equipe_suivi` (`equipe_suivi`),
  ADD KEY `equipe_adverse` (`equipe_adverse`);

ALTER TABLE `Composition`
  MODIFY `compo_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Equipe`
  MODIFY `equipe_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Evenement`
  MODIFY `evenement_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Joueur`
  MODIFY `joueur_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Matchs`
  MODIFY `match_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Composition`
ADD CONSTRAINT `fk_composition_match` FOREIGN KEY (`match_id`) REFERENCES `Matchs` (`match_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_composition_joueur` FOREIGN KEY (`joueur_id`) REFERENCES `Joueur` (`joueur_id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `Evenement`
ADD CONSTRAINT `fk_evenement_match` FOREIGN KEY (`match_id`) REFERENCES `Matchs` (`match_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_evenement_joueur` FOREIGN KEY (`joueur_id`) REFERENCES `Joueur` (`joueur_id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `Joueur`
ADD CONSTRAINT `fk_joueur_equipe` FOREIGN KEY (`equipe_id`) REFERENCES `Equipe` (`equipe_id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `Matchs`
ADD CONSTRAINT `fk_matchs_equipe_suivi` FOREIGN KEY (`equipe_suivi`) REFERENCES `Equipe` (`equipe_id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_matchs_equipe_adverse` FOREIGN KEY (`equipe_adverse`) REFERENCES `Equipe` (`equipe_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;