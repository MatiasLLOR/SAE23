Pour lancer le site/serveur/creation de la base de donnée, il faut :

- Se placer dans le dossier du projet (Ruellan_Theo_SAE23_liv_final)
- Modifier les informations de connexion à la base de donnée dans le fichier "config.txt"
- Excecuter le fichier main.py

-- Attendre que le site se lance --

## Utilisation du site

#Page Regles
La page Règles permet de voir les règles du jeu.

#Page Effectif
La page Effectif est composé de tout les joueurs de la base de donnée, avec leurs images.
Il est possible de filtrer les joueurs par poste, en cliquant sur les boutons correspondant aux postes.
En haut à droite de la page, il est possible d'ajouter un joueur.

En cliquant sur un joueur, on accède à sa page de profil.
Sur cette page, il est possible de modifier les informations du joueur, ou de le supprimer.

#Page Calendrier
La page Calendrier est composé de tout les matchs de la base de donnée.
Il est possible de filtrer par plusieurs critères
Sur cette page, on peut ajouter, supprimer, modifier un match.

En cliquant sur Fiche du match, on accède à la page du match et ses statistique.

#Page Fiche du match
La page Fiche du match est composé de tout les évenements du match et la composition.
Il est possible d'ajouter, supprimer, modifier un évenement et une composition.

--Attention-- : L'ajout de composition prend environ 30sec

#Page Classement
La page Classement est composé de toutes les équipes de la base de donnée.
Il est possible de filtrer par plusieurs critères.
Sur cette page, on peut ajouter, supprimer, modifier une équipe.