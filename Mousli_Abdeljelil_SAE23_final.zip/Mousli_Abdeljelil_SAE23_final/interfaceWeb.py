from logging import raiseExceptions, root
from math import prod
from traceback import print_tb
import cherrypy, os, os.path
from INTERFACE import Tome, TomeAll, Produit, ProduitAll, Enchere, EnchereAll, Present, PresentAll, Magasin, MagasinAll

from mako.template import Template
from mako.lookup import TemplateLookup
from configDB import dbConnect

mylookup = TemplateLookup(directories=['html'], input_encoding='utf-8', module_directory='html/mako_modules')




class INTERFACE(object):    
    ###### Page d'accueil #############
    @cherrypy.expose
    def index(self):
        mytemplate = mylookup.get_template("index.html")
        return mytemplate.render()

    @cherrypy.expose
    def afficher_tome(self):
        mytemplate = mylookup.get_template("tome.html")
        tomes = TomeAll().importTome()
        return mytemplate.render(tomes=tomes)
    

    @cherrypy.expose 
    def afficher_produit(self):
        mytemplate = mylookup.get_template("produit.html")
        produits = ProduitAll().importProduit()
        encheres = EnchereAll().importEnchere()  # Importer les enchères
        return mytemplate.render(produits=produits, encheres=encheres)  # Passer les enchères au template
    


    @cherrypy.expose
    def afficher_magasin(self):
        mytemplate = mylookup.get_template("magasin.html")
        magasins = MagasinAll().importMagasin()
        return mytemplate.render(magasins=magasins)

    
    @cherrypy.expose
    def administration(self):
        mytemplate = mylookup.get_template("administration.html")
        magasins = MagasinAll().importMagasin()
        produits = ProduitAll().importProduit()
        tomes = TomeAll().importTome()
        return mytemplate.render(magasins=magasins,produits=produits,tomes=tomes)

    @cherrypy.expose
    def ajouter_tome(self, date, resume, numero, nbPages, titre, auteur, prix, nbTome, **magasins):
        id = TomeAll().getLastTomeId()
        tome = Tome(id, str(date), resume, numero, nbPages, titre, auteur)
        TomeAll().addTome(tome)
        id_present = PresentAll().getLastPresentId()
        list_magasin = TomeAll().transformDicoKeysIntoList(magasins)
        for id_magasin in list_magasin:
            present = Present(id_present, id, id_magasin, prix, nbTome)
            PresentAll().addPresent(present)
        raise cherrypy.HTTPRedirect("/administration")
    



    @cherrypy.expose
    def ajouter_produit(self, prix_depart, nom, nombre, description):
        id=ProduitAll().getLastProduitId()
        produit=Produit(id, float(prix_depart), nom, nombre , description)
        ProduitAll().addProduit(produit)
        raise cherrypy.HTTPRedirect("/administration")



    @cherrypy.expose
    def ajouter_magasin(self, type_magasin, nom, note):
        id=MagasinAll().getLastMagasinId()
        magasin=Magasin(id, type_magasin, nom, note)
        MagasinAll().addMagasin(magasin)
        raise cherrypy.HTTPRedirect("/administration")
    
    @cherrypy.expose
    def modifier_tome(self , tome_id, date, resume, numero, nbPages, titre, auteur):
        tome = Tome(tome_id, str(date), resume, numero, nbPages, titre, auteur)
        TomeAll().updateTome(tome)
        raise cherrypy.HTTPRedirect("/administration")

    
    @cherrypy.expose
    def supprimer_tome(self, tome_id):
        id = TomeAll().getTomeById(int(tome_id))
        TomeAll().deleteTome(id)
        raise cherrypy.HTTPRedirect("/administration")
    
    
    @cherrypy.expose
    def modifier_produit(self , produit_id, prix_depart, nom, nombre, description):
        produit=Produit(produit_id, float(prix_depart), nom, nombre , description)
        ProduitAll().updateProduit(produit)
        raise cherrypy.HTTPRedirect("/administration")

    @cherrypy.expose
    def supprimer_produit(self, produit_id):
        id = ProduitAll().getProduitById((int(produit_id)))
        ProduitAll().deleteProduit(id)
        raise cherrypy.HTTPRedirect("/administration")
    @cherrypy.expose
    def modifier_magasin(self , id_magasin, type_magasin, nom, note):
        magasin=Magasin(id_magasin, type_magasin, nom, note)
        MagasinAll().updateMagasin(magasin)
        raise cherrypy.HTTPRedirect("/administration")

    @cherrypy.expose
    def supprimer_magasin(self, id_magasin):
        magasin = MagasinAll().getMagasinById(int(id_magasin))
        MagasinAll().deleteMagasin(magasin)
        raise cherrypy.HTTPRedirect("/administration")

    @cherrypy.expose
    def recherche_par_titre(self, titre):
        mytemplate = mylookup.get_template("tome.html")
        tomes = TomeAll().searchByTitle(titre)
        return mytemplate.render(tomes=tomes)
    
    @cherrypy.expose
    def afficher_tome_prixMinMax(self, PrixMin, PrixMax):
        mytemplate = mylookup.get_template("produit.html")
        produits = ProduitAll().triePrixMinMax(PrixMin, PrixMax)
        return mytemplate.render(produits=produits)
    

    @cherrypy.expose
    def trieParPage(self ):
        mytemplate = mylookup.get_template("tome.html")
        tomes=TomeAll().trieParPage()
        return mytemplate.render(tomes=tomes)

    @cherrypy.expose
    def trieParPageinverse(self ):
        mytemplate = mylookup.get_template("tome.html")
        tomes=TomeAll().trieParPageinverse()
        return mytemplate.render(tomes=tomes)

    @cherrypy.expose
    def augmente_prix(self, id_enchere):
        mytemplate = mylookup.get_template("produit.html")
        produits = ProduitAll().importProduit()
        encheres = EnchereAll().importEnchere()
        enchere = EnchereAll().getEnchereById(int(id_enchere))
        EnchereAll().updateEnchere1(enchere)
        return mytemplate.render(produits=produits, encheres=encheres)

    




    
if __name__ == '__main__':
    rootPath = os.path.abspath(os.getcwd())
    conf = {
        '/': {
            'tools.staticdir.root': rootPath,
        },
        '/css': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './css'
        },
        '/image': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './image'
        },
        '/js': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': './js'
        },
    }
    cherrypy.quickstart(INTERFACE(), '/', config=conf)
