from cmath import e
import os
from sqlite3 import Cursor
from unittest import result
import configDB, insertdata
from typing import List



class Tome:

    def __init__(self, id_tome:int, date:str, resume:str, numero:int, page:int, titre:str, auteur:str):
        self.id_tome = id_tome
        self.date = date
        self.resume = resume
        self.numero = numero
        self.page = page
        self.titre = titre
        self.auteur = auteur
        self.magasins = afficher_magasin_parTome(self.id_tome)


    def __str__(self):
        return f"{self.getId_tome()} : {self.getTitre()} : {self.getAuteur()} : {self.getDate()} : {self.getNumero()} : {self.getPage()} : {self.getResume()}"

    def getId_tome(self):
        return self.id_tome

    def getDate(self):
        return self.date

    def getResume(self):
        return self.resume

    def getNumero(self):
        return self.numero

    def getPage(self):
        return self.page

    def getTitre(self):
        return self.titre

    def getAuteur(self):
        return self.auteur


class TomeAll():

    def __init__(self):
        self.db, self.cursor = configDB.serveurConnect("Config.txt")
        self.tomes = self.importTome()

    def importTome(self):
        self.cursor.execute("SELECT * FROM Tome")
        tomes = []
        all = self.cursor.fetchall()
        for tome in all:
            tomes.append(Tome(tome[0], tome[1], tome[2], tome[3], tome[4], tome[5], tome[6]))
        return tomes

    def getTomes(self):
        return self.tomes

    def getTomeById(self, id_tome):
        for tome in self.tomes:
            if tome.getId_tome() == id_tome:
                return tome

    def getLastTomeId(self):
        self.cursor.execute("SELECT MAX(id_tome) FROM Tome")
        id = self.cursor.fetchone()
        return int(id[0]+1)

    def addTome(self, tome):
        self.cursor.execute("INSERT INTO Tome (date, resume, numero, page, titre, auteur) VALUES (%s, %s, %s, %s, %s, %s)", (tome.getDate(), tome.getResume(), tome.getNumero(), tome.getPage(), tome.getTitre(), tome.getAuteur()))
        self.db.commit()

    def deleteTome(self, tome):
        self.cursor.execute("DELETE FROM Tome WHERE id_tome = %s", (tome.getId_tome()))
        self.db.commit()

    def updateTome(self, tome):
        self.cursor.execute("UPDATE Tome SET date = %s, resume = %s, numero = %s, page = %s, titre = %s, auteur = %s WHERE id_tome = %s", (tome.getDate(), tome.getResume(), tome.getNumero(), tome.getPage(), tome.getTitre(), tome.getAuteur(), tome.getId_tome()))
        self.db.commit()

        
    def searchByTitle(self, titre):
        matching_tomes = []
        for tome in self.tomes:
            if tome.getTitre() == titre:
                matching_tomes.append(tome)
        return matching_tomes
    
    def trieParPage(self):
        self.tomes.sort(key=lambda tome: tome.getPage(), reverse=True)
        return self.tomes

    def trieParPageinverse(self):
        self.tomes.sort(key=lambda tome: tome.getPage())
        return self.tomes

    @staticmethod
    def transformDicoKeysIntoList(dico: dict) -> list:
        liste = []
        for id in dico.keys():
            liste.append(int(id))
        return liste



class Produit:

    def __init__(self, id_produit:int, prix_depart:float, nom:str, nombre:int, description:str):
        self.id_produit = id_produit
        self.prix_depart = prix_depart
        self.nom = nom
        self.nombre = nombre
        self.description = description

    def __str__(self):
        return f"{self.getId_produit()} : {self.getPrix_depart()} : {self.getNom()} : {self.getNombre()} : {self.getDescription()}"

    def getId_produit(self):
        return self.id_produit

    def getPrix_depart(self):
        return self.prix_depart

    def getNom(self):
        return self.nom

    def getNombre(self):
        return self.nombre

    def getDescription(self):
        return self.description


class ProduitAll():
    
    def __init__(self):
        self.db, self.cursor = configDB.serveurConnect("Config.txt")
        self.produits = self.importProduit()

    def importProduit(self):
        self.cursor.execute("SELECT * FROM Produit")
        produits = []
        all = self.cursor.fetchall()
        for produit in all:
            produits.append(Produit(produit[0], produit[1], produit[2], produit[3], produit[4]))
        return produits

    def getProduits(self):
        return self.produits

    def getProduitById(self, id_produit):
        for produit in self.produits:
            if produit.getId_produit() == id_produit:
                return produit

    def getLastProduitId(self):
        self.cursor.execute("SELECT MAX(id_produit) FROM Produit")
        id = self.cursor.fetchone()
        return int(id[0]+1)

    def addProduit(self, produit):
        self.cursor.execute("INSERT INTO Produit (prix_depart, nom, nombre, description) VALUES (%s, %s, %s, %s)", (produit.getPrix_depart(), produit.getNom(), produit.getNombre(), produit.getDescription()))
        self.db.commit()


    def deleteProduit(self, produit):
        self.cursor.execute("DELETE FROM Produit WHERE id_produit = %s", (produit.getId_produit()))
        self.db.commit()

    def updateProduit(self, produit):
        self.cursor.execute("UPDATE Produit SET prix_depart = %s, nom = %s, nombre = %s, description = %s WHERE id_produit = %s", (produit.getPrix_depart(), produit.getNom(), produit.getNombre(), produit.getDescription(), produit.getId_produit()))
        self.db.commit()

    def triePrixMinMax(self, prix_min, prix_max):
        produits = []
        for produit in self.produits:
            if float(produit.getPrix_depart()) >= float(prix_min) and float(produit.getPrix_depart()) <= float(prix_max):
                produits.append(produit)
        return produits
    



class Magasin:

    def __init__(self, id_magasin:int, type:str, nom:str, note:int):
        self.id_magasin = id_magasin
        self.type = type
        self.nom = nom
        self.note = note


    def __str__(self):
        return f"{self.getId_magasin()} : {self.getType()} : {self.getNom()} : {self.getNote()}"

    def getId_magasin(self):
        return self.id_magasin

    def getType(self):
        return self.type

    def getNom(self):
        return self.nom

    def getNote(self):
        return self.note


class MagasinAll():
        
    def __init__(self):
        self.db, self.cursor = configDB.serveurConnect("Config.txt")
        self.magasins = self.importMagasin()

    def importMagasin(self):
        self.cursor.execute("SELECT * FROM Magasin")
        magasins = []
        all = self.cursor.fetchall()
        for magasin in all:
            magasins.append(Magasin(magasin[0], magasin[1], magasin[2], magasin[3]))
        return magasins

    def getMagasins(self):
        return self.magasins

    def getMagasinById(self, id_magasin):
        for magasin in self.magasins:
            if magasin.getId_magasin() == id_magasin:
                return magasin

    def getLastMagasinId(self):
        self.cursor.execute("SELECT MAX(id_magasin) FROM Magasin")
        id = self.cursor.fetchone()
        return int(id[0]+1)

    def addMagasin(self, magasin):
        self.cursor.execute("INSERT INTO Magasin (type, nom, note) VALUES (%s, %s, %s)", (magasin.getType(), magasin.getNom(), magasin.getNote()))
        self.db.commit()

    def deleteMagasin(self, magasin):
        self.cursor.execute("DELETE FROM Magasin WHERE id_magasin = %s", (magasin.getId_magasin()))
        self.db.commit()

    def updateMagasin(self, magasin):
        self.cursor.execute("UPDATE Magasin SET type = %s, nom = %s, note = %s WHERE id_magasin = %s", (magasin.getType(), magasin.getNom(), magasin.getNote(), magasin.getId_magasin()))
        self.db.commit()


class Present:

    def __init__(self, id_present:int, id_tome:int, id_magasin:int, prix:float, nombre_tome:int):
        self.id_present = id_present
        self.id_tome = id_tome
        self.id_magasin = id_magasin
        self.prix = prix
        self.nombre_tome = nombre_tome


    def __str__(self):
        return f"{self.getId_present()} : {self.getId_tome()} : {self.getId_magasin()} : {self.getPrix()} : {self.getNombre_tome()}"

    def getId_present(self):
        return self.id_present

    def getId_tome(self):
        return self.id_tome

    def getId_magasin(self):
        return self.id_magasin

    def getPrix(self):
        return self.prix

    def getNombre_tome(self):
        return self.nombre_tome


class PresentAll():
                
    def __init__(self):
        self.db, self.cursor = configDB.serveurConnect("Config.txt")
        self.presents = self.importPresent()

    def importPresent(self):
        self.cursor.execute("SELECT * FROM Present")
        presents = []
        all = self.cursor.fetchall()
        for present in all:
            presents.append(Present(present[0], present[1], present[2], present[3], present[4]))
        return presents

    def getPresents(self):
        return self.presents

    def getPresentById(self, id_present):
        for present in self.presents:
            if present.getId_present() == id_present:
                return present

    def getLastPresentId(self):
        self.cursor.execute("SELECT MAX(id_present) FROM Present")
        id = self.cursor.fetchone()
        return int(id[0]+1)

    def addPresent(self, present):
        self.cursor.execute("INSERT INTO Present (id_tome, id_magasin, prix, nombre_tome) VALUES (%s, %s, %s, %s)", (present.getId_tome(), present.getId_magasin(), present.getPrix(), present.getNombre_tome()))
        self.db.commit()

    def deletePresent(self, present):
        self.cursor.execute("DELETE FROM Present WHERE id_present = %s", (present.getId_present()))
        self.db.commit()

    def updatePresent(self, present):
        self.cursor.execute("UPDATE Present SET id_tome = %s, id_magasin = %s, prix = %s, nombre_tome = %s WHERE id_present = %s", (present.getId_tome(), present.getId_magasin(), present.getPrix(), present.getNombre_tome(), present.getId_present()))
        self.db.commit()


class Enchere:
    
        def __init__(self, id_enchere:int, id_produit:int, prix_client:float):
            self.id_enchere = id_enchere
            self.id_produit = id_produit
            self.prix_client = prix_client


        def __str__(self):
            return f"{self.getId_enchere()} : {self.getId_produit()} : {self.getPrix_client()}"

        def getId_enchere(self):
            return self.id_enchere

        def getId_produit(self):
            return self.id_produit

        def getPrix_client(self):
            return self.prix_client

        def setId_enchere(self, id_enchere):
            self.id_enchere = id_enchere

        def setId_produit(self, id_produit):
            self.id_produit = id_produit

        def setPrix_client(self, prix_client):
            self.prix_client = prix_client


class EnchereAll():
                        
    def __init__(self):
        self.db, self.cursor = configDB.serveurConnect("Config.txt")
        self.encheres = self.importEnchere()

    def importEnchere(self):
        self.cursor.execute("SELECT * FROM Enchere")
        encheres = []
        all = self.cursor.fetchall()
        for enchere in all:
            encheres.append(Enchere(enchere[0], enchere[1], enchere[2]))
        return encheres

    def getEncheres(self):
        return self.encheres

    def getEnchereById(self, id_enchere):
        for enchere in self.encheres:
            if enchere.getId_enchere() == id_enchere:
                return enchere

    def getLastEnchereId(self):
        self.cursor.execute("SELECT MAX(id_enchere) FROM Enchere")
        id = self.cursor.fetchone()
        return int(id[0]+1)

    def addEnchere(self, enchere):
        self.cursor.execute("INSERT INTO Enchere (id_produit, prix_client) VALUES (%s, %s)", (enchere.getId_produit(), enchere.getPrix_client()))
        self.db.commit()

    def deleteEnchere(self, enchere):
        self.cursor.execute("DELETE FROM Enchere WHERE id_enchere = %s", (enchere.getId_enchere()))
        self.db.commit()

    def updateEnchere(self, enchere):
        self.cursor.execute("UPDATE Enchere SET id_produit = %s, prix_client = %s WHERE id_enchere = %s", (enchere.getId_produit(), enchere.getPrix_client(), enchere.getId_enchere()))
        self.db.commit()

    def updateEnchere1(self, enchere):
        self.cursor.execute("UPDATE Enchere SET id_produit = %s, prix_client = %s WHERE id_enchere = %s", (enchere.getId_produit(), enchere.getPrix_client()+1, enchere.getId_enchere()))
        self.db.commit()
    


def if_table_vide(cursor):
    check = True
    while check:
        cursor.execute("SELECT * FROM Tome")
        result = cursor.fetchall()
        if len(result) != 0:
            break

        cursor.execute("SELECT * FROM Produit")
        result = cursor.fetchall()
        if len(result) != 0:
            break

        cursor.execute("SELECT * FROM Magasin")
        result = cursor.fetchall()
        if len(result) != 0:
            break

        cursor.execute("SELECT * FROM Present")
        result = cursor.fetchall()
        if len(result) != 0:
            break

        cursor.execute("SELECT * FROM Enchere")
        result = cursor.fetchall()
        if len(result) != 0:
            break

        return True
    return False


def ajouter_tome():
    id_tome = TomeAll().getLastTomeId()
    date = input("Date de sortie du tome (JJ/MM/AAAA): ")
    résumé = input("Résumé du tome: ")
    numero = input("Numéro du tome: ")
    page = input("Nombre de page du tome: ")
    titre = input("Titre du tome: ")
    auteur = input("Auteur du tome: ")
    tome = Tome(id_tome, date, résumé, numero, page, titre, auteur)
    return tome


def modifier_tome():
    id_tome = int(input("Numéro du tome à modifier: "))
    tome = TomeAll().getTomeById(id_tome)
    date = input("Date de sortie du tome (JJ/MM/AAAA): ")
    résumé = input("Résumé du tome: ")
    numero = input("Numéro du tome: ")
    page = input("Nombre de page du tome: ")
    titre = input("Titre du tome: ")
    auteur = input("Auteur du tome: ")
    tome = Tome(id_tome, date, résumé, numero, page, titre, auteur)
    return tome


def supprimer_tome():
    id_tome = int(input("Numéro du tome à supprimer: "))
    tome = TomeAll().getTomeById(id_tome)
    return tome


def ajouter_produit():
    id_produit = ProduitAll().getLastProduitId()
    prix_depart = input("Prix du produit dérivés: ")
    nom = input("Nom du produit dérivés: ")
    nombre = input("Nombre de produit dérivés disponible dans le magasin: ")
    description = input("Description du produit dérivés: ")
    produit = Produit(id_produit, prix_depart, nom, nombre, description)
    return produit


def modifier_produit():
    id_produit = int(input("Numéro du produit dérivés à modifier: "))
    produit = ProduitAll().getProduitById(id_produit)
    prix_depart = input("Prix du produit dérivés: ")
    nom = input("Nom du produit dérivés: ")
    nombre = input("Nombre de produit dérivés disponible dans le magasin: ")
    description = input("Description du produit dérivés: ")
    produit = Produit(id_produit, prix_depart, nom, nombre, description)
    return produit


def supprimer_produit():
    id_produit = int(input("Numéro du produit dérivés à supprimer: "))
    produit = ProduitAll().getProduitById(id_produit)
    return produit


def ajouter_magasin():
    id_magasin = MagasinAll().getLastMagasinId()
    type = input("Type de magasin: ")
    nom = input("Nom du magasin: ")
    note = input("Note du magasin: ")
    magasin = Magasin(id_magasin, type, nom, note)
    return magasin


def modifier_magasin():
    id_magasin = int(input("Numéro du magasin à modifier: "))
    magasin = MagasinAll().getMagasinById(id_magasin)
    type = input("Type de magasin: ")
    nom = input("Nom du magasin: ")
    note = input("Note du magasin: ")
    magasin = Magasin(id_magasin, type, nom, note)
    return magasin


def supprimer_magasin():
    id_magasin = int(input("Numéro du magasin à supprimer: "))
    magasin = MagasinAll().getMagasinById(id_magasin)
    return magasin


def ajouter_present():
    id_present = PresentAll().getLastPresentId()
    id_tome = input("Numéro du tome: ")
    id_magasin = input("Numéro du magasin: ")
    prix = input("Prix du tome: ")
    nombre_tome = input("Nombre de tome disponible dans le magasin: ")
    present = Present(id_present, id_tome, id_magasin, prix, nombre_tome)
    return present


def modifier_present():
    id_present = int(input("Numéro du présent à modifier: "))
    present = PresentAll().getPresentById(id_present)
    id_tome = input("Numéro du tome: ")
    id_magasin = input("Numéro du magasin: ")
    prix = input("Prix du tome: ")
    nombre_tome = input("Nombre de tome disponible dans le magasin: ")
    present = Present(id_present, id_tome, id_magasin, prix, nombre_tome)
    return present  


def supprimer_present():
    id_present = int(input("Numéro du présent à supprimer: "))
    present = PresentAll().getPresentById(id_present)
    return present


def ajouter_enchere():
    id_enchere = EnchereAll().getLastEnchereId()
    id_produit = input("Numéro du produit: ")
    prix_client = input("Prix proposé par le client: ")
    enchere = Enchere(id_enchere, id_produit, prix_client)
    return enchere


def modifier_enchere():
    id_enchere = int(input("Numéro de l'enchère à modifier: "))
    enchere = EnchereAll().getEnchereById(id_enchere)
    id_produit = input("Numéro du produit: ")
    prix_client = input("Prix proposé par le client: ")
    enchere = Enchere(id_enchere, id_produit, prix_client)
    return enchere


def supprimer_enchere():
    id_enchere = int(input("Numéro de l'enchère à supprimer: "))
    enchere = EnchereAll().getEnchereById(id_enchere)
    return enchere


def afficher_tome():
    tomes = TomeAll().getTomes()
    print("Numéro du tome : Titre du tome : Auteur du tome : Date de sortie du tome : Numéro du tome : Nombre de page du tome : Résumé du tome")
    for tome in tomes:
        print(tome)

def afficher_produit():
    produits = ProduitAll().getProduits()
    print("Numéro du produit : Prix du produit : Nom du produit : Nombre de produit disponible dans le magasin : Description du produit")
    for produit in produits:
        print(produit)

def afficher_magasin():
    magasins = MagasinAll().getMagasins()
    print("Numéro du magasin : Type de magasin : Nom du magasin : Note du magasin")
    for magasin in magasins:
        print(magasin)

def afficher_present():
    presents = PresentAll().getPresents()
    print("Numéro du présent : Numéro du tome : Numéro du magasin : Prix du tome : Nombre de tome disponible dans le magasin")
    for present in presents:
        print(present)

def afficher_enchere():
    encheres = EnchereAll().getEncheres()
    print("Numéro de l'enchère : Numéro du produit : Prix proposé par le client")
    for enchere in encheres:
        print(enchere)

def afficher_magasin_parTome(tome_id):
    db, cursor = configDB.serveurConnect("Config.txt")
    magasins = []
    cursor.execute(f"select Magasin.nom from Tome Join Present using(id_tome) Join Magasin using(id_magasin) where Tome.id_tome = {tome_id};")
    resultat = cursor.fetchall()
    for magasin in resultat:
        magasins.append(str(magasin)[2:-3])
    db.close()
    return magasins



def run():

    while True :
        print("Que souhaitez-vous faire ?")
        print("##### TOMES #####")
        print("1 : Ajouter un tome")
        print("2 : Supprimer un tome")
        print("3 : Modifier un tome")
        print("##### PRODUITS DÉRIVÉS #####")
        print("4 : Ajouter un produit dérivés")
        print("5 : Supprimer un produit dérivés")
        print("6 : Modifier un produit dérivés")
        print("##### MAGASINS #####")
        print("7 : Ajouter un magasin")
        print("8 : Supprimer un magasin")
        print("9 : Modifier un magasin")
        print("##### PRESENT #####")
        print("10 : Ajouter un présent")
        print("11 : Supprimer un présent")
        print("12 : Modifier un présent")
        print("##### ENCHERE #####")
        print("13 : Ajouter une enchère")
        print("14 : Supprimer une enchère")
        print("15 : Modifier une enchère")
        print("##### AFFICHAGE #####")
        print("16 : Afficher les tome")
        print("17 : Afficher les produit dérivés")
        print("18 : Afficher les magasins")
        print("19 : Afficher les présent")
        print("20 : Afficher les enchères")
        print("##### QUITTER #####")
        print("21 : Quitter")

        """print("4 : Afficher les magasins où est disponible un tome")
        print("5 : Afficher les tome par date de sortie")
        print("6 : Afficher les tome par nombre de page")
        print("7 : Afficher les tome par prix")
        print("8 : Afficher les tome par auteur")
        print("9 : Afficher les tome par titre")
        print("10 : Afficher les tome")
        print("11 : Ajouter un produit dérivés")
        print("12 : Supprimer un produit dérivés")
        print("13 : Afficher magasin")
        print ("14 : Afficher nombre")
        print("15 : Afficher prix")
        print("16: Afficher description")
        print("17 : Afficher prix proposé par le client")
        print("18 : Afficher nom")
        print("19 : Afficher les produit dérivés")
        print("20 : Quitter")"""

        choix = input("Votre choix ? ")
        if choix == '1':
            TomeAll().addTome(ajouter_tome()) 
        elif choix == '2':
            TomeAll().deleteTome(supprimer_tome())
        elif choix == '3':
            TomeAll().updateTome(modifier_tome())
        elif choix == '4':
            ProduitAll().addProduit(ajouter_produit())
        elif choix == '5':
            ProduitAll().deleteProduit(supprimer_produit())
        elif choix == '6':
            ProduitAll().updateProduit(modifier_produit())
        elif choix == '7':
            MagasinAll().addMagasin(ajouter_magasin())
        elif choix == '8':
            MagasinAll().deleteMagasin(supprimer_magasin())
        elif choix == '9':
            MagasinAll().updateMagasin(modifier_magasin())
        elif choix == '10':
            PresentAll().addPresent(ajouter_present())
        elif choix == '11':
            PresentAll().deletePresent(supprimer_present())
        elif choix == '12':
            PresentAll().updatePresent(modifier_present())
        elif choix == '13':
            EnchereAll().addEnchere(ajouter_enchere())
        elif choix == '14':
            EnchereAll().deleteEnchere(supprimer_enchere())
        elif choix == '15':
            EnchereAll().updateEnchere(modifier_enchere())
        elif choix == '16':
            afficher_tome()
        elif choix == '17':
            afficher_produit()
        elif choix == '18':
            afficher_magasin()
        elif choix == '19':
            afficher_present()
        elif choix == '20':
            afficher_enchere()
        elif choix == '21':
            break
        else:
            print("Choix invalide !")



if __name__ == '__main__':
    configDB.dbConnect("Config.txt")
    db, cursor = configDB.serveurConnect("Config.txt")
    if if_table_vide(cursor):
        insertdata.ExtractFromCSV("jeu_dessai.csv")
    db.commit()

    run()