import csv
import pymysql

# Lecture du fichier de configuration
config = {}
with open('Config.txt', 'r') as file:
    for line in file:
        key, value = line.strip().split(':')
        config[key] = value

# Connexion à la base de données
db = pymysql.connect(
    host=config['host'],
    user=config['user'],
    password=config['password'],
    database=config['database']
)

# Créer un curseur
cursor = db.cursor(pymysql.cursors.DictCursor)

def ExtractFromCSV(file):
        start_appending_tomes = False
        start_appending_magasins = False
        start_appending_produits = False
        start_appending_presents = False
        start_appending_encheres = False

        with open(file, 'r', encoding='utf-8') as fichier:
            lines = fichier.readlines()
            # Parcourir chaque ligne du fichier CSV
            for line in lines:

                ##Tome##

                if "date, resume, numero, page, titre, auteur" in line:
                    start_appending_tomes = True
                elif start_appending_tomes and line == "\n":
                    start_appending_tomes = False
                elif start_appending_tomes:

                    date, resume, numero, page, titre, auteur = line.split(",")
                    query = "INSERT INTO Tome (date, resume, numero, page, titre, auteur) VALUES (%s, %s, %s, %s, %s, %s)"
                    cursor.execute(query, (str(date).strip(), str(resume).strip(), int(numero), int(page), str(titre).strip(), str(auteur).strip()))
                    db.commit()

                ##Produit##

                elif "prix_depart, nom, nombre, description" in line:
                    start_appending_produits = True
                elif start_appending_produits and line == "\n":
                    start_appending_produits = False
                elif start_appending_produits:
                    prix_depart, nom, nombre, description = line.split(",")
                    query = "INSERT INTO Produit (prix_depart, nom, nombre, description) VALUES (%s, %s, %s, %s)"
                    cursor.execute(query, (float(prix_depart), str(nom).strip(), int(nombre), str(description).strip()))
                    db.commit()

                ##Magasin##

                elif "type, nom, note" in line:
                    start_appending_magasins = True
                elif start_appending_magasins and line == "\n":
                    start_appending_magasins = False
                elif start_appending_magasins:
                    type, nom, note = line.split(",")
                    query = "INSERT INTO Magasin (type, nom, note) VALUES (%s, %s, %s)"
                    cursor.execute(query, (str(type).strip(), str(nom).strip(), float(note)))
                    db.commit()

                ##Present##

                elif "id_tome, id_magasin, prix, nombre_tome" in line:
                    start_appending_presents = True
                elif start_appending_presents and line == "\n":
                    start_appending_presents = False
                elif start_appending_presents:
                    id_tome, id_magasin, prix, nombre_tome = line.split(",")
                    query = "INSERT INTO Present (id_tome, id_magasin, prix, nombre_tome) VALUES (%s, %s, %s, %s)"
                    cursor.execute(query, (int(id_tome), int(id_magasin), float(prix), int(nombre_tome)))
                    db.commit()

                ##Enchere##

                elif "id_produit, prix_client" in line:
                    start_appending_encheres = True
                elif start_appending_encheres and line == "\n":
                    start_appending_encheres = False
                elif start_appending_encheres:
                    id_produit, prix_client = line.split(",")
                    query = "INSERT INTO Enchere (id_produit, prix_client) VALUES (%s, %s)"
                    cursor.execute(query, (int(id_produit), float(prix_client)))
                    db.commit()



