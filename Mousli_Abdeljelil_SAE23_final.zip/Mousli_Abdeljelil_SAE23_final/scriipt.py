from flask import Flask, request, render_template
import sqlite3

app = Flask(__name__)

@app.route('/afficher_tomes', methods=['GET'])
def afficher_tomes():
    # Connexion à la base de données
    conn = sqlite3.connect('ma_base_de_donnees.db')
    cursor = conn.cursor()

    # Exécution de la requête pour récupérer les tomes
    cursor.execute('SELECT * FROM tomes')
    tomes = cursor.fetchall()

    # Fermeture de la connexion à la base de données
    cursor.close()
    conn.close()

    # Rendu du template HTML avec les données des tomes
    return render_template('afficher_tomes.html', tomes=tomes)

@app.route('/supprimer_tome', methods=['POST'])
def supprimer_tome():
    tome_id = request.form['tome_id']

    # Connexion à la base de données
    conn = sqlite3.connect('ma_base_de_donnees.db')
    cursor = conn.cursor()

    # Exécution de la requête pour supprimer le tome
    cursor.execute('DELETE FROM tomes WHERE id = ?', (tome_id,))
    conn.commit()

    # Fermeture de la connexion à la base de données
    cursor.close()
    conn.close()

    return 'Le tome a été supprimé avec succès.'

if __name__ == '__main__':
    app.run()
