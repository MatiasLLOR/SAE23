# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685955708.4920282
_enable_loop = True
_template_filename = 'html/accueil.html'
_template_uri = 'accueil.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html lang="fr">\r\n<head>\r\n    <meta charset="UTF-8">\r\n    <title>One Piece</title>\r\n    <link rel="stylesheet" href="styles.css">\r\n</head>\r\n<body>\r\n    <header>\r\n        <h1>One Piece</h1>\r\n        <img src="one-piece-logo.png" alt="Logo One Piece">\r\n    </header>\r\n\r\n    <nav>\r\n        <ul>\r\n            <li><a href="index">Accueil</a></li>\r\n            <li><a href="tome.html">tome</a></li>\r\n            <li><a href="produit.html">produit</a></li>\r\n            <li><a href="enchere.html">enchere</a></li>\r\n            <li><a href="administration.html">administration</a></li>\r\n        </ul>\r\n    </nav>\r\n\r\n    <main>\r\n        <section>\r\n            <h2>Introduction</h2>\r\n            <p>One Piece est une série de manga et d\'anime populaire créée par Eiichiro Oda. L\'histoire suit Monkey D. Luffy, un jeune pirate qui se lance dans un voyage pour trouver le trésor ultime, connu sous le nom de One Piece, et devenir le Roi des Pirates. En chemin, il rassemble un équipage hétéroclite de pirates et rencontre de puissants ennemis, des îles mystérieuses et le gouvernement mondial.</p>\r\n        </section>\r\n\r\n        <section>\r\n            <h2>Personnages principaux</h2>\r\n            <ul>\r\n                <li><img src="image/luffy.jpg" alt="Luffy"> Monkey D. Luffy - Le capitaine des Chapeaux de Paille et le protagoniste principal.</li>\r\n                <li><img src="image/zoro.jpg" alt="Zoro"> Roronoa Zoro - Un épéiste et le premier membre de l\'équipage de Luffy.</li>\r\n                <li><img src="image/nami.jpg" alt="Nami"> Nami - Une navigatrice douée et voleuse.</li>\r\n                <li><img src="image/usopp.jpg" alt="Usopp"> Usopp - Un tireur d\'élite et un menteur expert.</li>\r\n                <li><img src="image/sanji.jpg" alt="Sanji"> Sanji - Un cuisinier talentueux et artiste martial.</li>\r\n                <li><img src="image/chopper.jpg" alt="Chopper"> Tony Tony Chopper - Un renne qui a mangé le Fruit de l\'Humain-Humain et a acquis la capacité de se transformer en humain.</li>\r\n                <li><img src="image/robin.jpg" alt="Robin"> Nico Robin - Une archéologue au passé sombre.</li>\r\n                <li><img src="image/franky.jpg" alt="Franky"> Franky - Un charpentier cyborg.</li>\r\n                <li><img src="image/brook.jpg" alt="Brook"> Brook - Un musicien et épéiste avec la capacité de revenir d\'entre les morts.</li>\r\n            </ul>\r\n        </section>\r\n\r\n\r\n        <section>\r\n            <h2>Univers</h2>\r\n            <p>L\'univers de One Piece est rempli d\'îles uniques et variées, chacune avec sa propre culture, géographie et habitants. La Grande Route de tous les périls, une route maritime dangereuse et imprévisible, est le principal cadre de la série. Le gouvernement mondial, dirigé par les Marines, maintient le contrôle sur les mers, tandis que des équipages de pirates et des individus puissants appelés "Shichibukai" remettent en question leur autorité.</p>\r\n        </section>\r\n\r\n        <section>\r\n            <h2>Héritage</h2>\r\n            <p>One Piece est devenu l\'une des séries de manga les plus vendues de tous les temps et a connu un succès international avec son adaptation en anime. Elle a captivé le public avec son histoire captivante, ses personnages bien développés et ses thèmes d\'amitié, d\'aventure et de poursuite des rêves. La série a également inspiré de nombreux spin-offs, films, jeux vidéo et produits dérivés.</p>\r\n            <p>Pour plus d\'informations, visitez le <a href="https://www.onepieceofficial.com/" target="_blank">site officiel de One Piece</a>.</p>\r\n        </section>\r\n    </main>\r\n</body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/accueil.html", "uri": "accueil.html", "source_encoding": "utf-8", "line_map": {"16": 0, "21": 1, "27": 21}}
__M_END_METADATA
"""
