# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686108196.0093033
_enable_loop = True
_template_filename = 'html/administration.html'
_template_uri = 'administration.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        tomes = context.get('tomes', UNDEFINED)
        magasins = context.get('magasins', UNDEFINED)
        produits = context.get('produits', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n\r\n<html lang="fr">\r\n    <head>\r\n        <title>One piece</title>\r\n        <meta charset="UTF-8">\r\n        <meta name="viewport" content="width=device-width, initial-scale=1">\r\n        <link rel="stylesheet" href="/css/w3.css">\r\n        <link rel="stylesheet" href="/css/administration.css">\r\n        <link rel="stylesheet" href="/css/font-montserra.css">\r\n        <link rel="stylesheet" href="/css/style.css">\r\n    </head>\r\n\r\n    <body class="w3-black">\r\n\r\n        <!-- Icon Bar (Sidebar - hidden on small screens) -->\r\n        <nav class="w3-sidebar w3-bar-block w3-small w3-hide-small w3-center">\r\n          <!-- Avatar image in top left corner -->\r\n          <a href="index" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n              <p>Accueil</p>\r\n          </a>\r\n          <a href="afficher_tome" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n              <p>Notre selection de tome</p>\r\n          </a>\r\n          <a href="afficher_produit" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n              <p>Notre selection de produit</p>\r\n          </a>\r\n          <a href="afficher_magasin" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n              <p>Nos magasins</p>\r\n          </a>\r\n          <a href="administration" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n              <p>Administration</p>\r\n          </a>\r\n      </nav>\r\n      <!-- Navbar on small screens (Hidden on medium and large screens) -->\r\n      <div class="w3-top w3-hide-large w3-hide-medium" id="myNavbar">\r\n          <div class="w3-bar w3-black w3-opacity w3-hover-opacity-off w3-center w3-small">\r\n              <a href="index" class="w3-bar-item w3-button navbar-smallScreen-width">Accueil</a>\r\n              <a href="afficher_tome" class="w3-bar-item w3-button navbar-smallScreen-width">Notre selection de tome</a>\r\n              <a href="afficher_produit" class="w3-bar-item w3-button navbar-smallScreen-width">Notre selection de produit</a>\r\n              <a href="afficher_magasin" class="w3-bar-item w3-button navbar-smallScreen-width">Nos magasins</a>\r\n              <a href="administration" class="w3-bar-item w3-button navbar-smallScreen-width">Administration</a>\r\n          </div>\r\n      </div>\r\n\r\n        <!-- Page Content -->\r\n        <div class="w3-padding-large" id="main">\r\n            \r\n            <!-- Header/Home -->\r\n            <header class="w3-container w3-padding-32 w3-center w3-black" id="home">\r\n                <h1 class="w3-jumbo"><span class="w3-hide-small"></span>Manga : One piece</h1>\r\n                <h4>Voici l\'histoire de notre manga One piece </p>\r\n                </header>\r\n            <hr class="w3-opacity">\r\n\r\n         <!-- Contenu de la page -->\r\n         <title>Gestion des tomes</title>\r\n        </head>\r\n        <body>\r\n          <h1>Gestion des tomes</h1>\r\n        \r\n          <h2>Ajouter un tome</h2>\r\n            <form action="/ajouter_tome" method="POST">\r\n              <label for="date">Date de sortie:</label>\r\n              <input type="date" name="date" required><br>\r\n            \r\n              <label for="resume">Résumé:</label>\r\n              <textarea name="resume" required></textarea><br>\r\n            \r\n              <label for="numero">Numéro:</label>\r\n              <input type="number" name="numero" required><br>\r\n            \r\n              <label for="nbPages">Nombre de pages:</label>\r\n              <input type="number" name="nbPages" required><br>\r\n            \r\n              <label for="titre">Titre:</label>\r\n              <input type="text" name="titre" required><br>\r\n            \r\n              <label for="auteur">Auteur:</label>\r\n              <input type="text" name="auteur" required><br>\r\n\r\n              <label form="prix">Prix:</label>\r\n              <input type="number" step="0.01" name="prix" required><br>\r\n\r\n              <label form="nbTome">Nombre de Tomes disponible:</label>\r\n              <input type="number" name="nbTome" required><br>\r\n\r\n')
        for magasin in magasins:
            __M_writer('                <label for="')
            __M_writer(str(magasin.id_magasin))
            __M_writer('">')
            __M_writer(str(magasin.nom))
            __M_writer('</label>\r\n                <input type="checkbox" name="')
            __M_writer(str(magasin.id_magasin))
            __M_writer('">\r\n')
        __M_writer('            \r\n              <input type="submit" value="Ajouter">\r\n            </form>\r\n            \r\n            <h2>Modifier un tome</h2>\r\n            <form action="/modifier_tome" method="POST">\r\n                <label for="tome_id">ID du tome à modifier:</label>\r\n                <select name="tome_id" required>\r\n')
        for tome in tomes:
            __M_writer('                    <option value="')
            __M_writer(str(tome.id_tome))
            __M_writer('">')
            __M_writer(str(tome.titre))
            __M_writer('</option>\r\n')
        __M_writer('                </select><br>\r\n            \r\n                <label for="date">Date de sortie:</label>\r\n                <input type="date" name="date" required><br>\r\n            \r\n                <label for="resume">Résumé:</label>\r\n                <textarea name="resume" required></textarea><br>\r\n            \r\n                <label for="numero">Numéro:</label>\r\n                <input type="number" name="numero" required><br>\r\n            \r\n                <label for="nbPages">Nombre de pages:</label>\r\n                <input type="number" name="nbPages" required><br>\r\n            \r\n                <label for="titre">Titre:</label>\r\n                <input type="text" name="titre" required><br>\r\n            \r\n                <label for="auteur">Auteur:</label>\r\n                <input type="text" name="auteur" required><br>\r\n            \r\n                <input type="submit" value="Modifier">\r\n            </form>\r\n            \r\n        \r\n        <h2>Supprimer un tome</h2>\r\n          <form action="/supprimer_tome" method="POST">\r\n            <label for="tome_id">ID du tome à supprimer:</label>\r\n            <select name="tome_id" required>\r\n')
        for tome in tomes:
            __M_writer('              <option value="')
            __M_writer(str(tome.id_tome))
            __M_writer('">')
            __M_writer(str(tome.titre))
            __M_writer('</option>\r\n')
        __M_writer('            </select>\r\n        \r\n            <input type="submit" value="Supprimer">\r\n          </form>\r\n            \r\n             \r\n          \r\n          <h2>Ajouter un produit</h2>\r\n            <form action="/ajouter_produit" method="POST">\r\n              <label for="prix_depart">Prix:</label>\r\n              <input type="number" step="0.01" name="prix_depart" required><br>\r\n            \r\n              <label for="nom">Nom:</label>\r\n              <input type="text" name="nom" required><br>\r\n            \r\n              <label for="nombre">Nombre:</label>\r\n              <input type="number" name="nombre" required><br>\r\n            \r\n              <label for="description">Description:</label>\r\n              <textarea name="description" required></textarea><br>\r\n  \r\n              <input type="submit" value="Ajouter">\r\n            </form>\r\n            <h2>Modifier un produit</h2>\r\n            <form action="/modifier_produit" method="POST">\r\n                <label for="produit_id">ID du produit à modifier:</label>\r\n                <select name="produit_id" required>\r\n')
        for produit in produits:
            __M_writer('                    <option value="')
            __M_writer(str(produit.id_produit))
            __M_writer('">')
            __M_writer(str(produit.nom))
            __M_writer('</option>\r\n')
        __M_writer('                </select><br>\r\n            \r\n              <label for="prix_depart">Prix:</label>\r\n              <input type="number" step="0.01" name="prix_depart" required><br>\r\n            \r\n              <label for="nom">Nom:</label>\r\n              <input type="text" name="nom" required><br>\r\n            \r\n              <label for="nombre">Nombre:</label>\r\n              <input type="number" name="nombre" required><br>\r\n            \r\n              <label for="description">Description:</label>\r\n              <textarea name="description" required></textarea><br>\r\n            \r\n                <input type="submit" value="Modifier">\r\n            </form>\r\n\r\n            <h2>Supprimer un produit</h2>\r\n            <form action="/supprimer_produit" method="POST">\r\n              <label for="produit_id">ID du produit à supprimer:</label>\r\n              <select name="produit_id" required>\r\n')
        for produit in produits:
            __M_writer('                <option value="')
            __M_writer(str(produit.id_produit))
            __M_writer('">')
            __M_writer(str(produit.nom))
            __M_writer('</option>\r\n')
        __M_writer('              </select>\r\n          \r\n              <input type="submit" value="Supprimer">\r\n            </form>\r\n            \r\n\r\n\r\n            <h2>Ajouter un magasin</h2>\r\n            <form action="/ajouter_magasin" method="POST">\r\n              <label for="nom">Nom du magasin:</label>\r\n              <input type="text" name="nom" required><br>\r\n            \r\n              <label for="type_magasin">Type du magasin:</label>\r\n              <input type="text" name="type_magasin" required><br>\r\n            \r\n              <label for="note">Note sur 5:</label>\r\n              <input type="number" name="note" required><br>\r\n  \r\n              <input type="submit" value="Ajouter">\r\n            </form>\r\n\r\n\r\n\r\n            <h2>Modifier un magasin</h2>\r\n            <form action="/modifier_magasin" method="POST">\r\n                <label for="id_magasin">ID du magasin à modifier:</label>\r\n                <select name="id_magasin" required>\r\n')
        for magasin in magasins:
            __M_writer('                    <option value="')
            __M_writer(str(magasin.id_magasin))
            __M_writer('">')
            __M_writer(str(magasin.nom))
            __M_writer('</option>\r\n')
        __M_writer('                </select><br>\r\n\r\n                <label for="nom">Nom du magasin:</label>\r\n                <input type="text" name="nom" required><br>\r\n              \r\n                <label for="type_magasin">Type du magasin:</label>\r\n                <input type="text" name="type_magasin" required><br>\r\n              \r\n                <label for="note">Note sur 5:</label>\r\n                <input type="number" name="note" required><br>\r\n            \r\n                <input type="submit" value="Modifier">\r\n            </form>\r\n\r\n\r\n\r\n            <h2>Supprimer un magasin</h2>\r\n            <form action="/supprimer_magasin" method="POST">\r\n              <label for="id_magasin">ID du magasin à supprimer:</label>\r\n              <select name="id_magasin" required>\r\n')
        for magasin in magasins:
            __M_writer('                <option value="')
            __M_writer(str(magasin.id_magasin))
            __M_writer('">')
            __M_writer(str(magasin.nom))
            __M_writer('</option>\r\n')
        __M_writer('              </select>\r\n          \r\n              <input type="submit" value="Supprimer">\r\n            </form>\r\n\r\n    <!-- End Contenu de la page -->\r\n            \r\n            \r\n                <!-- Footer -->\r\n                <footer class="w3-padding-64 w3-text-grey w3-xlarge">\r\n                    <hr class="w3-opacity">\r\n                        <!-- Navigation -->\r\n                        <div>\r\n                            <h5 class="w3-text-light-grey">Navigation :</h2>\r\n                            <a href="index" class="w3-button navbar-bottom-width text-footer">Accueil</a>\r\n                            <a href="afficher_tome" class="w3-button navbar-bottom-width text-footer">Notre selection de tome</a>\r\n                            <a href="afficher_produit" class="w3-button navbar-bottom-width text-footer">Notre selection de produit</a>\r\n                            <a href="afficher_magasin" class="w3-button navbar-bottom-width text-footer">Nos magasins</a>\r\n                            <a href="administration" class="w3-button navbar-bottom-width text-footer">Administration</a>\r\n                        <!-- End Navigation -->\r\n                        </div>\r\n                    <hr class="w3-opacity">\r\n                    <!-- Lien source : W3School -->\r\n                </div>\r\n                <!-- End footer -->\r\n                </footer>\r\n\r\n                <!-- END PAGE CONTENT -->\r\n                </div>\r\n\r\n                </body>\r\n                </html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/administration.html", "uri": "administration.html", "source_encoding": "utf-8", "line_map": {"16": 0, "24": 1, "25": 88, "26": 89, "27": 89, "28": 89, "29": 89, "30": 89, "31": 90, "32": 90, "33": 92, "34": 100, "35": 101, "36": 101, "37": 101, "38": 101, "39": 101, "40": 103, "41": 131, "42": 132, "43": 132, "44": 132, "45": 132, "46": 132, "47": 134, "48": 161, "49": 162, "50": 162, "51": 162, "52": 162, "53": 162, "54": 164, "55": 185, "56": 186, "57": 186, "58": 186, "59": 186, "60": 186, "61": 188, "62": 215, "63": 216, "64": 216, "65": 216, "66": 216, "67": 216, "68": 218, "69": 238, "70": 239, "71": 239, "72": 239, "73": 239, "74": 239, "75": 241, "81": 75}}
__M_END_METADATA
"""
