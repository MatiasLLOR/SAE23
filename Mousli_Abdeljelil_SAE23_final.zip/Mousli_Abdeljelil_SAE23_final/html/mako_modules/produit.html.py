# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686115923.1595037
_enable_loop = True
_template_filename = 'html/produit.html'
_template_uri = 'produit.html'
_source_encoding = 'utf-8'
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        produits = context.get('produits', UNDEFINED)
        encheres = context.get('encheres', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n\r\n<html lang="fr">\r\n    <head>\r\n        <title>One piece</title>\r\n        <meta charset="UTF-8">\r\n        <meta name="viewport" content="width=device-width, initial-scale=1">\r\n        <link rel="stylesheet" href="/css/w3.css">\r\n        <link rel="stylesheet" href="/css/produit.css">\r\n        <link rel="stylesheet" href="/css/font-montserra.css">\r\n        <link rel="stylesheet" href="/css/style.css">\r\n        <script src="/js/alpine.js"></script>\r\n    </head>\r\n\r\n    <body class="w3-black">\r\n\r\n        <!-- Icon Bar (Sidebar - hidden on small screens) -->\r\n        <nav class="w3-sidebar w3-bar-block w3-small w3-hide-small w3-center">\r\n            <!-- Avatar image in top left corner -->\r\n            <a href="index" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n                <p>Accueil</p>\r\n            </a>\r\n            <a href="afficher_tome" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n                <p>Notre selection de tome</p>\r\n            </a>\r\n            <a href="afficher_produit" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n                <p>Notre selection de produit</p>\r\n            </a>\r\n            <a href="afficher_magasin" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n                <p>Nos magasins</p>\r\n            </a>\r\n            <a href="administration" class="w3-bar-item w3-button w3-padding-large w3-hover-black">\r\n                <p>Administration</p>\r\n            </a>\r\n        </nav>\r\n\r\n       \r\n        <!-- Navbar on small screens (Hidden on medium and large screens) -->\r\n        <div class="w3-top w3-hide-large w3-hide-medium" id="myNavbar">\r\n            <div class="w3-bar w3-black w3-opacity w3-hover-opacity-off w3-center w3-small">\r\n                <a href="index" class="w3-bar-item w3-button navbar-smallScreen-width">Accueil</a>\r\n                <a href="afficher_tome" class="w3-bar-item w3-button navbar-smallScreen-width">Notre selection de tome</a>\r\n                <a href="afficher_produit" class="w3-bar-item w3-button navbar-smallScreen-width">Notre selection de produit</a>\r\n                <a href="afficher_magasin" class="w3-bar-item w3-button navbar-smallScreen-width">Nos magasins</a>\r\n                <a href="administration" class="w3-bar-item w3-button navbar-smallScreen-width">Administration</a>\r\n            </div>\r\n        </div>\r\n\r\n        <!-- Page Content -->\r\n        <div class="w3-padding-large" id="main">\r\n            <hr class="w3-opacity">\r\n            <main>\r\n                <div id="ChoixTri" x-data="{ showRecherche: true }">\r\n                    <a @click="showRecherche = !showRecherche" x-show="showRecherche">Rechercher par prix</a>\r\n                    <a @click="showRecherche = !showRecherche" x-show="!showRecherche">RETOUR</a>\r\n                    <form id="form" x-show="!showRecherche" method="post" action="afficher_tome_prixMinMax">\r\n                        <input type="number" step="0.01" name="PrixMin" placeholder="prix Min">\r\n                        <input type="number" step="0.01" name="PrixMax" placeholder="prix Max">\r\n                        <button type="submit">Rechercher</button>\r\n                    </form>\r\n                </div>\r\n                <h1>Liste des produits</h1>\r\n                <table>\r\n                    <tr>\r\n                        <th>Nom du produit</th>\r\n                        <th>Description du produit</th>\r\n                        <th>Prix de départ du produit</th>\r\n                        <th>Nombre de produit disponible</th>\r\n                        <th>Prix client</th>  <!-- Ajout de la colonne Prix client -->\r\n                    </tr>\r\n')
        for produit in produits:
            __M_writer('                    <tr>\r\n                        <td>')
            __M_writer(str(produit.nom))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(produit.description))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(produit.prix_depart))
            __M_writer('</td>\r\n                        <td>')
            __M_writer(str(produit.nombre))
            __M_writer('</td>\r\n                        <td>\r\n')
            for enchere_item in encheres:
                if enchere_item.id_produit == produit.id_produit:
                    __M_writer('                                <p>')
                    __M_writer(str(enchere_item.prix_client))
                    __M_writer('</p>  <!-- Afficher le prix client de l\'enchère correspondante -->\r\n                                <form action="augmente_prix">\r\n                                    <input type="hidden" name="id_enchere" value="')
                    __M_writer(str(enchere_item.id_enchere))
                    __M_writer('">\r\n                                    <button type="submit">+1</button>\r\n                                </form>\r\n')
            __M_writer('                        </td>\r\n                    </tr>\r\n')
        __M_writer('                </table>\r\n            </main>\r\n\r\n            <footer class="w3-padding-64 w3-text-grey w3-xlarge">\r\n                <hr class="w3-opacity">\r\n                <div>\r\n                    <h5 class="w3-text-light-grey">Navigation :</h2>\r\n                    <a href="index" class="w3-button navbar-bottom-width text-footer">Accueil</a>\r\n                    <a href="afficher_tome" class="w3-button navbar-bottom-width text-footer">Notre selection de tome</a>\r\n                    <a href="afficher_produit" class="w3-button navbar-bottom-width text-footer">Notre selection de produit</a>\r\n                    <a href="afficher_magasin" class="w3-button navbar-bottom-width text-footer">Nos magasins</a>\r\n                    <a href="administration" class="w3-button navbar-bottom-width text-footer">Administration</a>\r\n                </div>\r\n                <hr class="w3-opacity">\r\n            </footer>\r\n        </div>\r\n    </body>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "html/produit.html", "uri": "produit.html", "source_encoding": "utf-8", "line_map": {"16": 0, "23": 1, "24": 71, "25": 72, "26": 73, "27": 73, "28": 74, "29": 74, "30": 75, "31": 75, "32": 76, "33": 76, "34": 78, "35": 79, "36": 80, "37": 80, "38": 80, "39": 82, "40": 82, "41": 87, "42": 90, "48": 42}}
__M_END_METADATA
"""
