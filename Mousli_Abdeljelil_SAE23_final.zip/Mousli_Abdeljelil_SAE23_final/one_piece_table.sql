CREATE DATABASE op;

use op;

CREATE TABLE Magasin (
    id_magasin INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(255),
    nom VARCHAR(255),
    note INT
);

CREATE TABLE Tome (
    id_tome INT AUTO_INCREMENT PRIMARY KEY,
    date VARCHAR(255) NOT NULL,
    resume TEXT NOT NULL,
    numero INT NOT NULL,
    page INT NOT NULL,
    titre VARCHAR(255) NOT NULL,
    auteur VARCHAR(255) NOT NULL
);

CREATE TABLE Present (
    id_present INT AUTO_INCREMENT PRIMARY KEY,
    id_tome INT NOT NULL,
    id_magasin INT NOT NULL,
    prix FLOAT NOT NULL,
    nombre_tome INT NOT NULL
);


CREATE TABLE Produit (
    id_produit INT AUTO_INCREMENT PRIMARY KEY,
    prix_depart DECIMAL(10,2) NOT NULL,
    nom VARCHAR(255) NOT NULL,
    nombre INT NOT NULL,
    description TEXT NOT NULL
);

CREATE TABLE Enchere (
    id_enchere INT AUTO_INCREMENT PRIMARY KEY,
    id_produit INT NOT NULL,
    prix_client FLOAT NOT NULL
);

ALTER TABLE `Present`
ADD CONSTRAINT `fk_present_tome` FOREIGN KEY (`id_tome`) REFERENCES `Tome` (`id_tome`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_present_magasin` FOREIGN KEY (`id_magasin`) REFERENCES `Magasin` (`id_magasin`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `Enchere`
ADD CONSTRAINT `fk_enchere_produit`FOREIGN KEY (`id_produit`) REFERENCES `Produit` (`id_produit`) ON DELETE CASCADE ON UPDATE CASCADE;