Etape 1 : Ouvrir un terminal dans le dossier Mousli_Abdeljelil_SAE23_liv1
Etape 2 : Mettre ses informations dans le fichier Config.txt  
Etape 3 : Executer le fichier python INTERFACE.py
Etape 4 : Vous pouvez gérer la base à votre guise
Etape 5 : lancer le fichier python interfaceWeb.py
Etape 6 : aller sur le lien http://127.0.0.1:8080
Etape 7 : vous pouvez maintenant essayer le site 
Etape 8 : le systeme d'enchere est particulier, il suffit d'appuyer sur le bouton +1 
qui permet de rajouter 1 au prix proposé et pouvoir le prix s'actualiser 
il faut actualiser la page  